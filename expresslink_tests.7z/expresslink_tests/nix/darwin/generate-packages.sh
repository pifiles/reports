#!/usr/bin/env nix-shell
#!nix-shell -i bash -p nixpkgs-fmt
#!nix-shell -p "(import \"${fetchGit \"https://github.com/nix-community/pip2nix\"}/release.nix\" {}).pip2nix.python39"
pip2nix generate -r ../../requirements.txt --output python-packages.nix \
  --no-binary 'pyusb'
nixpkgs-fmt python-packages.nix
