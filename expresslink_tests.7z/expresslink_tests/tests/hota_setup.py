import base64
from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.serialization import Encoding, PrivateFormat, NoEncryption
from datetime import timedelta, datetime
from typing import Literal, overload
from cryptography.hazmat.primitives.asymmetric.types import PRIVATE_KEY_TYPES

SIGNATURE_ALGORITHMS = Literal['RSA', 'ECDSA']
HASH_ALGORITHMS = Literal['SHA1', 'SHA256']


class SignatureInfo():
    signature: bytes
    signingCertificate: str
    hashAlgorithm: str
    signatureAlgorithm: str


@overload
def GenerateSigningDetails(thing_name: str, payload: bytes,
                           signature_algorithm: SIGNATURE_ALGORITHMS,
                           hash_algorithm: HASH_ALGORITHMS,
                           key_width: int) -> SignatureInfo:
    ...


@overload
def GenerateSigningDetails(thing_name: str, payload: bytes,
                           signature_algorithm: str, hash_algorithm: str,
                           key_width: int) -> SignatureInfo:
    ...


def GenerateSigningDetails(thing_name: str, payload: bytes,
                           signature_algorithm: str, hash_algorithm: str,
                           key_width: int) -> SignatureInfo:
    """Generates a single-use private key and hashes the payload
    returns a SignatureInfo struct which can be used to create an OTA job"""
    hasher: hashes.HashAlgorithm
    if hash_algorithm == 'SHA1':
        hasher = hashes.SHA1()
    elif hash_algorithm == 'SHA256':
        hasher = hashes.SHA256()
    else:
        raise ValueError(f'hash_algorithm not in {HASH_ALGORITHMS}')

    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, thing_name)])
    builder = x509.CertificateBuilder(
        issuer_name=name,
        subject_name=name,
        not_valid_before=datetime.now() - timedelta(days=1),
        not_valid_after=datetime.now() + timedelta(days=364),
        serial_number=x509.random_serial_number())
    builder = builder.add_extension(x509.KeyUsage(digital_signature=True,
                                                  content_commitment=False,
                                                  data_encipherment=False,
                                                  key_encipherment=False,
                                                  key_agreement=False,
                                                  key_cert_sign=False,
                                                  crl_sign=False,
                                                  encipher_only=False,
                                                  decipher_only=False),
                                    critical=False)
    builder = builder.add_extension(x509.ExtendedKeyUsage(
        [ExtendedKeyUsageOID.CODE_SIGNING]),
                                    critical=False)

    signature: bytes
    private_key: PRIVATE_KEY_TYPES
    """RSA includes the choice of padding, which is not specified by ACM or OTA Jobs..."""
    if signature_algorithm == 'RSA':
        raise ValueError('RSA is not supported')
    elif signature_algorithm == 'ECDSA':
        curve: ec.EllipticCurve
        if (key_width == 256):
            curve = ec.SECP256R1()
        elif (key_width == 384):
            curve = ec.SECP384R1()
        elif (key_width == 521):
            curve = ec.SECP521R1()
        else:
            raise ValueError(f'unsupported {key_width=}')
        private_key = ec.generate_private_key(curve)
        signature = private_key.sign(payload, ec.ECDSA(hasher))
    else:
        raise ValueError(f'signature_algorithm not in {SIGNATURE_ALGORITHMS}')
    builder = builder.public_key(private_key.public_key())

    info = SignatureInfo()

    info.hashAlgorithm = hash_algorithm
    info.signatureAlgorithm = signature_algorithm.split('-')[0]
    info.signingCertificate = builder.sign(private_key, hasher).public_bytes(
        Encoding.PEM).decode()
    info.signature = base64.b64encode(signature)

    print('Generated single-use private key and signing certificate:',
          private_key.private_bytes(Encoding.PEM,
                                    PrivateFormat.TraditionalOpenSSL,
                                    NoEncryption()).decode(),
          info.signingCertificate,
          sep='\n')

    return info


if __name__ == '__main__':
    payload = b'My message, signed by me.'
    signature = GenerateSigningDetails('thing', payload, 'ECDSA', 'SHA256',
                                       256)
    print(f'{payload.decode()} -> {signature.signature.__repr__()}')
