# Copyright of Amazon Web Services, Inc. (AWS) 2023
#
# This code is licensed under the AWS Intellectual Property License, which can
# be found here: https://aws.amazon.com/legal/aws-ip-license-terms/; provided
# that AWS grants you a limited, royalty-free, revocable, non-exclusive,
# non-sublicensable, non-transferrable license to modify the code for internal
# testing purposes. Your receipt of this code is subject to any non-disclosure
# (or similar) agreement between you and AWS.

from commands import connect_with_retries, cmd
import time
import config_handler as cf
import re
import pytest

# test_section11.py
# Section 11 - Additional Services (time and location commands)


# 11.1.1    TIME?   Request current time information
# ExpressLink modules must provide time information as available from SNTP,
# GPS or cellular network sources. Note that devices can choose to maintain
# internally a time reference even when disconnected or in sleep mode
# depending on implementation specific sw/hw capabilities.
#
# 11.1.1.1  Returns: OK {date YYYY/MM/DD} {time hh:mm:ss.xx} {source}
# If time information is available and recently obtained.
@pytest.mark.slow
def test_11_1_1_1_TimeAvailable() -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))
    # TODO: Add spec change for a "time available" event
    # Wait 30 seconds to ensure NTP syncs
    time.sleep(30)
    r_time = (r'^OK date \d\d\d\d/[01]\d/[0-3]\d '
              r'time [0-2]\d:[0-6]\d:[0-6]\d\.\d\d \S.*\r\n$')
    assert re.match(r_time, cmd("AT+TIME?\r\n")) != None


# 11.1.1.2  Returns: ERR15 TIME NOT AVAILABLE
# If a recent time fix could not be obtained
def test_11_1_1_2_TimeNotAvailable() -> None:
    r_time = r'^(OK .+|ERR15 TIME NOT AVAILABLE)\r\n$'
    assert re.match(r_time, cmd("AT+TIME?\r\n")) != None


# 11.1.2    WHERE?  Request location information
# ExpressLink modules can optionally provide last location information as
# available from GPS, GNSS, cellular network or other triangulation method.
# A time stamp is provided to allow the host determine the currency of the
# information. The implementation of this command is optional.
#
# 11.1.2.1  Returns: OK {date} {time} {lat} {long} {elev} {accuracy} {source}
# If location coordinates could be obtained at date/time
@pytest.mark.skipif(not cf.get('feature_where', bool),
                    reason='AT+WHERE? unavailable')
def test_11_1_2_1_WhereAvailable() -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))
    # Wait 30 seconds to allow location to sync
    time.sleep(30)

    # TODO: Spec change to have a "where enabled" event
    r_where = r'^OK \S+ \S+ \S+ \S+ \S+ \S+ \S.*\r\n$'
    assert re.match(r_where, cmd("AT+WHERE?\r\n")) != None


# 11.1.2.2  Returns: ERR16 LOCATION NOT AVAILABLE
# If a location fix could not be obtained (feature disabled)
@pytest.mark.skipif(cf.get('feature_where', bool),
                    reason='AT+WHERE? available')
def test_11_1_2_2_WhereNotAvailable() -> None:
    assert cmd("AT+WHERE?\r\n") == "ERR16 LOCATION NOT AVAILABLE\r\n"
