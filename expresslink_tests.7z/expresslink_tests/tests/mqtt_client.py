# Copyright of Amazon Web Services, Inc. (AWS) 2023
#
# This code is licensed under the AWS Intellectual Property License, which can
# be found here: https://aws.amazon.com/legal/aws-ip-license-terms/; provided
# that AWS grants you a limited, royalty-free, revocable, non-exclusive,
# non-sublicensable, non-transferrable license to modify the code for internal
# testing purposes. Your receipt of this code is subject to any non-disclosure
# (or similar) agreement between you and AWS.
import paho.mqtt.client as mqtt
from polling import poll, TimeoutException


def subscribe(mqtt_client: mqtt.Client, topic: str) -> bool:
    """Attempts to subscribe to a topic.
       Returns whether the attempt was successful"""
    success: bool | None = None

    def on_subscribe(client, userdata, qos,
                     reasoncodes: list[mqtt.ReasonCodes], props):
        nonlocal success
        for reason in reasoncodes:
            if reason.value != 0:
                success = False
                print(f'MQTT Subnack: {reason}')
                break
        else:
            success = True

    def check_subscribe() -> bool | None:
        mqtt_client.loop(timeout=10)
        return success != None

    mqtt_client.on_subscribe = on_subscribe
    mqtt_client.subscribe(topic=topic)

    try:
        poll(check_subscribe, timeout=120, step=0)
    except TimeoutException:
        pass
    finally:
        mqtt_client.on_subscribe = None

    if success is None:
        success = False
    return success


def wait_for_message(mqtt_client: mqtt.Client, **kwargs) -> tuple[str, bytes]:
    """Returns the next message on any subscribed topic.
       Returns an empty topic string and payload if nothing is received.
       Keyword arguments are passed to poll()"""
    message: tuple[str, bytes] | None = None
    print('Waiting for message to arrive from MQTT', end='')

    def on_message(client: mqtt.Client, userdata, msg: mqtt.MQTTMessage):
        nonlocal message
        print("\n\nWe got a message:\n{}, {!r}".format(msg.topic, msg.payload))
        message = (msg.topic, msg.payload)

    def await_message() -> bool:
        print(end='.', flush=True)
        mqtt_client.loop(timeout=1, max_packets=1)
        return message != None

    mqtt_client.on_message = on_message

    try:
        poll(await_message, **kwargs)
    except TimeoutException:
        pass
    finally:
        mqtt_client.on_message = None

    if message is None:
        message = ('', b'')
    return message


def publish(mqtt_client: mqtt.Client, topic: str, message: str):
    """Publishes a message using the Paho MQTT client"""

    def on_publish(client: mqtt.Client, userdata, message_id: int):
        print(f"Published an outgoing message:\r\n {topic}: {message}")

    mqtt_client.on_publish = on_publish
    mqtt_client.publish(topic, message)
