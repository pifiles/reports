# Copyright of Amazon Web Services, Inc. (AWS) 2023
#
# This code is licensed under the AWS Intellectual Property License, which can
# be found here: https://aws.amazon.com/legal/aws-ip-license-terms/; provided
# that AWS grants you a limited, royalty-free, revocable, non-exclusive,
# non-sublicensable, non-transferrable license to modify the code for internal
# testing purposes. Your receipt of this code is subject to any non-disclosure
# (or similar) agreement between you and AWS.

from mypy_boto3_iot_data import IoTDataPlaneClient
from commands import get_next_event, cmd, connect_with_retries, comms
from polling import poll, TimeoutException
import config_handler as cf
import pytest
import paho.mqtt.client as mqtt
from mqtt_client import subscribe, wait_for_message

# test_section5.py


def _attempt_subscribe(topic_number: int = 1) -> bool:
    """Subscribes to Topic{i} and waits for a SUBACK/SUBNACK"""
    assert cmd(f'AT+SUBSCRIBE{topic_number}\r\n') == 'OK\r\n'
    event = get_next_event(r'^OK \d+ \d+ SUBN?ACK\r\n$')
    if not event:
        pytest.fail('Suback event not generated')
    elif 'SUBACK' not in event:
        return False
    else:
        print('Received SUBNACK')
        return True


# 5         Messaging
# 5.1       Messaging Topic Model
# The messaging system of ExpressLink relies upon a list of topics defined in the configuration dictionary
# (see Table 3). Each topic is assigned an index that can be used to de-reference the assigned string value.
# Index 0 has a special meaning, while all other index values up to a (implementation specific) max index
# can be used by the host to define additional topics. Messaging topics defined in this list are managed
# independently from other topics eventually used by ExpressLink to handle Jobs, OTA and or shadow.


# 5.1.1.1   Topic Index 0 is reserved as a catch all for messages that do not match other existing topics
# (the list of topics must not contain an entry for Topic0). Attempting to send or subscribe to
# topic of index 0 will return ERR7 OUT OF RANGE.
def test_5_1_1_1_TopicZeroOutOfRangeConf() -> None:
    assert cmd('AT+CONF Topic0=myTopic\r\n') == 'ERR7 OUT OF RANGE\r\n'


def test_5_1_1_1_TopicZeroOutOfRangeMqtt() -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SUBSCRIBE0\r\n') == 'ERR7 OUT OF RANGE\r\n'
    assert cmd('AT+SEND0 my message\r\n') == 'ERR7 OUT OF RANGE\r\n'


# 5.1.1.2   Topic Index {MaxTopic} is an implementation dependent value ≥ 16.
def test_5_1_1_2_MaxTopic() -> None:
    max_topic = cf.test_config['device_max_topic'].get(int)
    if not isinstance(max_topic, int):
        pytest.fail('device_max_topic not configured. Must be ≥ 16')
    elif max_topic < 16:
        pytest.fail('device_max_topic must be ≥ 16')


# 5.1.2     Topic Usage Rules
# Topics are defined to be compatible with the MQTT 3.1.1 standard.
# NOTE: All topic rules previously involving the use of TopicRoot prefix have been removed from this
# version (v0.9.2) onward
#
# 5.1.3 is not tested due to its exclusion from the spec.
#
# 5.1.4     SEND{#} message Publish msg on a topic selected from topic list
# Send a message on a topic provided in the configuration dictionary. The configuration parameter QoS
# value (only 0 and 1 are supported) at the time the command is issued determines the applicable Quality
# of Service.
# {#}: index of topic in CONFIG dictionary (1..MaxTopic).
# message: string: message to publish
#
# 5.1.4.1   Response: OK if the message is sent successfully
# Example 1:
# AT+SEND2 Hello World Publish ‘Hello World’ on Topic2
# OK The message will be sent
def test_5_1_4_1_MqttPublish(mqtt_client: mqtt.Client, get_topic_prefix: str):
    assert cmd(f'AT+CONF Topic2={get_topic_prefix}\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert subscribe(mqtt_client, get_topic_prefix)
    assert cmd('AT+SEND2 Hello World\r\n') == 'OK\r\n'
    topic, payload = wait_for_message(mqtt_client, timeout=120, step=0)
    assert topic == get_topic_prefix
    assert payload == b'Hello World'


# 5.1.4.2   Response: ERR6 NO CONNECTION The message cannot be sent as the module is
# currently not connected.
# Example 2:
# AT+SEND1 Hello World Publish Hello World on Topic1
# ERR6 NO CONNECTION A connection has not been established
def test_5_1_4_2_MqttPublishNoConnection(get_topic_prefix: str):
    assert cmd(f'AT+CONF Topic1={get_topic_prefix}\r\n') == 'OK\r\n'
    assert cmd(f'AT+SEND1 Hello World\r\n') == 'ERR6 NO CONNECTION\r\n'


# 5.1.4.3   Response ERR7 OUT OF RANGE
# If the supplied topic index is larger than the maximum allowed topic number the response will be OUT
# OF RANGE.
# Example 3:
# AT+SEND999 Hello World - Publish Hello World on Topic999
# ERR7 OUT OF RANGE Topic 999 is not within the available range of topics for
# this device.
def test_5_1_4_3_MqttPublishOutOfRange() -> None:
    max_topic = cf.get('device_max_topic', int)
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd(
        f'AT+SEND{max_topic + 1} Hello World\r\n') == 'ERR7 OUT OF RANGE\r\n'


# 5.1.4.4   Response ERR8 PARAMETER UNDEFINED
# If the supplied topic index points to a topic entry that is not defined (empty).
# Example 4:
# AT+CONF Topic3={eol} Define Topic3 as empty
# OK
# AT+SEND3 Hello World -- Publish Hello World on Topic3
# ERR8 PARAMETER UNDEFINED The selected topic was undefined
def test_5_1_4_4_MqttPublishParamterUndefined() -> None:
    assert cmd('AT+CONF Topic3=\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SEND3 Hello World\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 5.1.5     GET Request next message pending on any topic
# Retrieve the next message received in the order of arrival.
# NOTE: the response to this command always produces two output lines, an exception to the general
# format defined in 4.6.1
#
# 5.1.5.1   Response: OK1 {separator} {topic} {EOL} {message} {EOL}
# if a message is available on any topic, respond with OK followed by the topic and the message.
# Example:
# AT+GET poll for messages received on any topic
# OK1 data{EOL} a message was received from topic ‘data’ (expect another line)
# Hello World{EOL} the actual message received
def test_5_1_5_1_GetAnyReturnsTopicMessage(get_topic_prefix: str,
                                           iot_client: IoTDataPlaneClient):
    assert connect_with_retries(cf.get('personal_endpoint', str))

    def get_any() -> str:
        response: str = cmd('AT+GET\r\n', print_output=False)
        if response == 'OK\r\n':
            message_received: str = ''
            print(end='.', flush=True)
        else:
            print(end='\n\n')
            print((f'Topic   : {response}').encode('iso_8859_1'))
            assert get_topic_prefix in response
            # AT+GET returns two lines of output
            message_received = cmd('', print_output=False)
            print((f'Message : {message_received}').encode('iso_8859_1'))
        return message_received

    # send a message on 3 different topics.
    # AT+GET receives the message on all topics.
    message_sent: str = 'Hello World!'
    for i in range(1, 4):
        topic: str = f'{get_topic_prefix}/{i}'
        assert cmd(f'AT+CONF Topic{i}={topic}\r\n') == 'OK\r\n'

        try:
            poll(_attempt_subscribe,
                 timeout=30,
                 step=0,
                 kwargs={'topic_number': i})
        except TimeoutException:
            pytest.fail('Unable to subscribe')

        iot_client.publish(topic=topic, payload=message_sent)
        print('Polling AT+GET', end='')
        assert poll(get_any, step=0.01, timeout=120) == f'{message_sent}\r\n'


# 5.1.5.2   Response OK{EOL}
# If no message was received on any topic, respond with OK followed by {EOL}
def test_5_1_5_2_GetAnyReturnsNoMessage() -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+GET\r\n') == 'OK\r\n'


# 5.1.6     GET0 Request next message pending on an unassigned topic
# Retrieve the next message received on a topic that is not in the topic list. This acts as a catch-all option
# and can be necessary in case the host modifies a topic string in the configuration dictionary after a
# subscription, without unsubscribing first. This can also be used in combination with the AWS IoT Device
# Shadow features (see section 10.2.1.3).
# NOTE: the response to this command always produces two output lines, using the response numerical
# suffix (OK#) according to the format described in section 4.6.1
#
# 5.1.6.1   Response: OK1 {separator} {topic} {EOL} {message} {EOL}
# Example:
# AT+GET0 poll for messages received on any unassigned topic
# OK1 data{EOL} a message was received from topic ‘data’ (expect another line)
# Hello World{EOL} the actual message received
def test_5_1_6_1_GetUnassignedMessage(get_topic_prefix: str,
                                      iot_client: IoTDataPlaneClient):
    assert cmd(f'AT+CONF Topic1={get_topic_prefix}\r\n')
    assert connect_with_retries(cf.get('personal_endpoint', str))

    try:
        poll(_attempt_subscribe,
             timeout=30,
             step=0,
             kwargs={'topic_number': 1})
    except TimeoutException:
        pytest.fail('Unable to subscribe')

    # Clear topic after subscribing
    assert cmd(f'AT+CONF Topic1=\r\n')

    message_sent: str = 'Hello World'
    iot_client.publish(topic=get_topic_prefix, payload=message_sent)

    def get_unassigned() -> str:
        response: str = cmd('AT+GET0\r\n', print_output=False)
        if response == 'OK\r\n':
            message_received: str = ''
            print(end='.', flush=True)
        else:
            print(end='\n\n')
            print((f'Topic   : {response}').encode('iso_8859_1'))
            assert f'OK1 {get_topic_prefix}\r\n' == response
            message_received = cmd('', print_output=False)
            print((f'Message : {message_received}').encode('iso_8859_1'))
        return message_received

    assert poll(get_unassigned, step=0.01,
                timeout=120) == f'{message_sent}\r\n'


# 5.1.6.2   Response: OK{EOL}
# If no message was received on any unassigned topic, respond with OK followed by {eol}
def test_5_1_6_2_GetUnassignedNoMessage(get_topic_prefix: str):
    assert cmd(f'AT+CONF Topic1={get_topic_prefix}\r\n')
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+GET0\r\n') == 'OK\r\n'
    # No additional output should be generated
    try:
        bad_response: str = poll(comms.read_device, timeout=5, step=0.01)
        pytest.fail(
            'Received message payload when no message was received\npayload: {!r}'
            .format(bad_response.encode('iso_8859_1')))
    except TimeoutException:
        pass


# 5.1.7     GET{#} Request next message pending on the indicated topic
# Retrieve the next message received on a topic (1..MaxTopic) at the specified index # in the topic list
#
# 5.1.7.1   Response: OK {separator} {message} {EOL}
# if a message is available on the indicated topic, respond with OK followed immediately by the message.
def test_5_1_7_1_GetIndicatedMessage(get_topic_prefix: str,
                                     iot_client: IoTDataPlaneClient):
    assert cmd(f'AT+CONF Topic1={get_topic_prefix}\r\n')
    assert connect_with_retries(cf.get('personal_endpoint', str))

    try:
        poll(_attempt_subscribe, timeout=30, step=0.01)
    except TimeoutException:
        pytest.fail('Unable to subscribe to topic')

    iot_client.publish(topic=get_topic_prefix, payload=get_topic_prefix)

    assert get_next_event(r'^OK 1 1 MSG\r\n$')

    assert cmd('AT+GET1\r\n') == f'OK {get_topic_prefix}\r\n'


# 5.1.7.2   Response: OK{EOL}
# If a message is NOT available matching the requested topic, respond with OK followed by {eol}
def test_5_1_7_2_GetIndicatedNoMessage(get_topic_prefix: str):
    assert cmd(f'AT+CONF Topic1={get_topic_prefix}\r\n')
    assert cmd('AT+GET1\r\n') == f'OK\r\n'


# 5.1.7.3   Response: OK [message]{EOL}
# Even if there is no active connection, a read from the message queue takes place and might return a
# valid message.
def test_5_1_7_3_GetIndicatedMessageAfterDisconnect(
        get_topic_prefix: str, iot_client: IoTDataPlaneClient):
    assert cmd(f'AT+CONF Topic1={get_topic_prefix}\r\n')
    assert connect_with_retries(cf.get('personal_endpoint', str))

    try:
        poll(_attempt_subscribe, timeout=30, step=0.01)
    except TimeoutException:
        pytest.fail('Unable to subscribe to topic')

    iot_client.publish(topic=get_topic_prefix, payload=get_topic_prefix)

    assert get_next_event(r'^OK 1 1 MSG\r\n$')

    assert 'OK' in cmd('AT+DISCONNECT\r\n')

    assert cmd('AT+GET1\r\n') == f'OK {get_topic_prefix}\r\n'


# 5.1.7.4   Response: ERR7 OUT OF RANGE
# If the supplied topic index is greater than the maximum allowed topic number.
def test_5_1_7_4_GetIndicatedOutOfRange() -> None:
    max_topic = cf.get('device_max_topic', int)
    assert cmd(f"AT+GET{ max_topic + 1 }\r\n") == 'ERR7 OUT OF RANGE\r\n'


# 5.1.7.5   Response: ERR8 PARAMETER UNDEFINED
# If the requested topic is not defined (empty).
def test_5_1_7_5_GetIndicatedErrorNoTopic() -> None:
    assert cmd('AT+GET1\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 5.1.7.6   Message queue overflow conditions
# If the host fails to retrieve a message in time (freeing up space otherwise exceeding the buffer capacity)
# an overflow may occur and new messages arriving from the cloud may be lost. The condition will be
# reported as an OVERFLOW event (see Table 4), added to the event queue and accessible to the host
# processor via the EVENT? command. As a result, in case of overflow, the number of message events
# (MSG) in the event queue can exceed the actual number of messages present in the message queue.
#
# Not tested because the message queue size and memory usage per message is vendor-defined.
#
# 5.1.8     SUBSCRIBE# Subscribe to Topic#
# The module will subscribe to the topic and start receiving messages. Incoming messages on the selected
# topic will trigger MSG events (see 8). The messages can be read by executing GET{#} commands.
#
# 5.1.8.1   Returns: OK{EOL}
# The subscription request was sent to the MQTT broker for the topic specified in the
# configuration dictionary as Topic#.
# NOTE: Sending a message to a topic with a subscription will result in a copy being sent back to the
# module from the broker.
def test_5_1_8_1_SubscribeCommand(get_topic_prefix: str):
    assert cmd(f'AT+CONF Topic1={get_topic_prefix}\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SUBSCRIBE1\r\n') == 'OK\r\n'


# 5.1.8.2   Returns: ERR6 NO CONNECTION
# If no connection has been made, return NO CONNECTION.
def test_5_1_8_2_SubscribeNoConnection(get_topic_prefix: str):
    assert cmd(f'AT+CONF Topic1={get_topic_prefix}\r\n') == 'OK\r\n'
    assert cmd('AT+SUBSCRIBE1\r\n') == 'ERR6 NO CONNECTION\r\n'


# 5.1.8.3   Returns: ERR8 PARAMETER UNDEFINED
# If the requested topic is not defined (empty).
def test_5_1_8_2_SubscribeTopicUndefined() -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SUBSCRIBE1\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 5.1.8.4   Returns: ERR7 OUT OF RANGE
# If the supplied index is greater than the maximum allowed topic number.
def test_5_1_8_2_SubscribeTopicOutOfRange() -> None:
    max_topic = cf.get('device_max_topic', int)
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd(f'AT+SUBSCRIBE{max_topic + 1}\r\n') == 'ERR7 OUT OF RANGE\r\n'


# 5.1.8.5   A SUBACK or SUBNACK event (see Table 4) is generated when the request is accepted or
# rejected by the MQTT broker.
# Note: The host should avoid issuing an UNSUBSCRIBE command immediately following a SUBSCRIBE
# command, before the acknowledgment event is received, as this would result in a race condition and
# unpredictable MQTT broker behavior.
def test_5_1_8_5_SubscribeSuback(get_topic_prefix: str):
    assert cmd(f'AT+CONF Topic1={get_topic_prefix}\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    poll(_attempt_subscribe, timeout=30, step=0, kwargs={'topic_number': 1})


# 5.1.8.6   If the topic referred to by a subscription is altered (AT+CONF), before an acknowledgment
# is received, the corresponding event will NOT be generated (see example 2 below).
#
# 5.1.8.6 is not tested as we cannot ensure we change the value before the
# suback is received.


# 5.1.8.7   If a new SUBSCRIBE command is issued for the same topic (before an acknowledgment is
# received), the previous acknowledgment event will NOT be generated.
@pytest.mark.slow
def test_5_1_8_7_SubscribeAgainOneSuback(get_topic_prefix: str):
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd(f'AT+CONF Topic1={get_topic_prefix}\r\n') == 'OK\r\n'
    assert cmd(f'AT+SUBSCRIBE1\r\n') == 'OK\r\n'
    assert cmd(f'AT+SUBSCRIBE1\r\n') == 'OK\r\n'
    assert get_next_event(r'^.*SUBN?ACK\r\n$')
    try:
        if get_next_event(r'^.*SUBN?ACK\r\n$') is not None:
            pytest.fail(
                'Received 2nd subscribe event after duplicate subscribe')
    except TimeoutException:
        pass


# NOTE: When in Staging state (see 4.7.1) restrictive policies apply, including preventing the subscription
# to topics that do not begin with the device ThingName. Attempting subscriptions to such topics may
# result in an immediate connection drop.
# Example 1:
# AT+CONF Topic1=sensor1/state{EOL}
# OK{EOL}
# AT+SUBSCRIBE1 The module will subscribe to the topic sensor1/state
# OK{EOL}
# Later: <SUBACK event> An ACK event confirms that the subscription was successful
# Example 2:
# AT+CONF Topic2=/sensor1/state{EOL}
# OK{EOL}
# AT+SUBSCRIBE2 The module will subscribe to the topic /sensor1/state
# OK{EOL}
# AT+CONF Topic2=/sensor1/data{EOL} The topic is modified
# NOTE: SUBACK and/or SUBNACK events for Topic2 will NOT be generated!


# 5.1.9     UNSUBSCRIBE# Unsubscribe from Topic#
# The device will unsubscribe from the selected topic and stop receiving its messages/event.
# 5.1.9.1   Returns: OK
# A request to unsubscribe to the topic specified in the configuration dictionary as Topic#
# was sent.
# Note: The host should avoid issuing an UNSUBSCRIBE command immediately following a SUBSCRIBE
# command, before the acknowledgment event is received, as this would result in a race condition and
# unpredictable MQTT broker behavior.
def test_5_1_9_1_UnsubcribeCommand(get_topic_prefix: str):
    assert cmd(f'AT+CONF Topic1={get_topic_prefix}\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd("AT+UNSUBSCRIBE1\r\n") == 'OK\r\n'


# 5.1.9.2   Returns: ERR6 NO CONNECTION
# If no connection has been established, return NO CONNECTION.
def test_5_1_9_2_UnsubscribeNoConnection(get_topic_prefix: str):
    assert cmd(f'AT+CONF Topic1={get_topic_prefix}\r\n') == 'OK\r\n'
    assert cmd('AT+UNSUBSCRIBE1\r\n') == 'ERR6 NO CONNECTION\r\n'


# 5.1.9.3   Returns: ERR8 PARAMETER UNDEFINED
# If the requested topic is not defined (empty).
def test_5_1_9_3_UnsubscribeParameterUndefined() -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+UNSUBSCRIBE1\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 5.1.9.4   Returns: ERR7 OUT OF RANGE
# If the supplied topic index is larger than the maximum allowed topic number the response
# will be OUT OF RANGE.
def test_5_1_9_4_UnsubscribeOutOfRange() -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))
    max_topic = cf.get('device_max_topic', int)
    assert cmd(f"AT+UNSUBSCRIBE{max_topic + 1}\r\n") == 'ERR7 OUT OF RANGE\r\n'


# Example 1:
# AT+CONF Topic1=sensor1/state{EOL}
# OK{EOL}
# AT+SUBSCRIBE1{EOL} The module will subscribe to the topic sensor1/state
# OK{EOL}
# ...
# AT+UNSUBSCRIBE1{EOL} The module will unsubscribe from topic sensor1/state
# OK{EOL}
