# Copyright of Amazon Web Services, Inc. (AWS) 2023
#
# This code is licensed under the AWS Intellectual Property License, which can
# be found here: https://aws.amazon.com/legal/aws-ip-license-terms/; provided
# that AWS grants you a limited, royalty-free, revocable, non-exclusive,
# non-sublicensable, non-transferrable license to modify the code for internal
# testing purposes. Your receipt of this code is subject to any non-disclosure
# (or similar) agreement between you and AWS.


def initialize_device():
    """Perform any required initialization for a device."""
    pass


def cleanup():
    """Perform any required cleanup and teardown on program termination"""
    pass


def write_device(input: str):
    """Send the string data in input to the device, encoded in ascii."""
    pass


def read_device() -> str:
    """Read the data that is currently available in the buffer."""
    pass


def flush_comms():
    """Flush the communication channel input/output"""
    pass


def get_event_pin() -> bool:
    """Return the current voltage state of the Event Pin.

    Return 1 if the pin is high voltage/1/on/powered.
    Return 0 if the pin is low voltage/0/off/unpowered.
    """
    pass


def set_wake_pin():
    """Set the Wake Pin to high voltage/1/on/powered."""
    pass


def clear_wake_pin():
    """Set the Wake Pin to low/0/off/unpowered."""
    pass


def set_reset_pin():
    """Set the Reset Pin to high voltage/1/on/powered."""
    pass


def clear_reset_pin():
    """Set the Reset Pin to low voltage/0/off/unpowered."""
    pass
