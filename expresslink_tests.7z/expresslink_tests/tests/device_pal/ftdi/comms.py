# Copyright of Amazon Web Services, Inc. (AWS) 2023
#
# This code is licensed under the AWS Intellectual Property License, which can
# be found here: https://aws.amazon.com/legal/aws-ip-license-terms/; provided
# that AWS grants you a limited, royalty-free, revocable, non-exclusive,
# non-sublicensable, non-transferrable license to modify the code for internal
# testing purposes. Your receipt of this code is subject to any non-disclosure
# (or similar) agreement between you and AWS.

import serial
import config_handler as cf
from pyftdi.gpio import GpioAsyncController as AsyncGpio
from time import sleep

_EVENT_PIN: int = (1 << 1)
_WAKE_PIN: int = (1 << 3)
_RESET_PIN: int = (1 << 5)

_OUTPUT_PINS: int = _WAKE_PIN | _RESET_PIN

__ftdi_gpio: AsyncGpio
__ftdi_serial: serial.Serial


def __set_pin_high(pin: int):
    pins: int = __ftdi_gpio.read() & _OUTPUT_PINS
    __ftdi_gpio.write(pins | pin)


def __set_pin_low(pin: int):
    pins: int = __ftdi_gpio.read() & _OUTPUT_PINS
    __ftdi_gpio.write(pins & (pin ^ 0xFF))


def __get_pin(pin: int) -> bool:
    pins: int = __ftdi_gpio.read()
    return (pins & pin) == pin


def initialize_device():
    """Perform any required initialization for a device."""
    global __ftdi_serial
    global __ftdi_gpio

    __ftdi_serial = serial.Serial(port=cf.get('ftdi_serial_port', str),
                                  baudrate=115200,
                                  timeout=0.01)

    __ftdi_gpio = AsyncGpio()
    __ftdi_gpio.configure(url=cf.get('ftdi_gpio_port', str),
                          direction=_OUTPUT_PINS)


def cleanup():
    """Perform any required cleanup and teardown on program termination"""
    __ftdi_gpio.write(_OUTPUT_PINS ^ 0xFF)
    __ftdi_gpio.set_direction(_OUTPUT_PINS, 0x00)
    __ftdi_gpio.close()
    __ftdi_serial.close()


def write_device(input: str):
    """Send the string data in input to the device, encoded in iso_8859_1."""
    __ftdi_serial.write(input.encode('iso_8859_1', 'replace'))


def read_device() -> str:
    """Read the data that is currently available in the buffer."""
    received = __ftdi_serial.readline()
    return received.decode('iso_8859_1')


def flush_comms():
    __ftdi_serial.reset_input_buffer()
    __ftdi_serial.reset_output_buffer()


def get_event_pin() -> bool:
    """Return the current voltage state of the Event Pin.

    Return 1 if the pin is high voltage/1/on/powered.
    Return 0 if the pin is low voltage/0/off/unpowered.
    """
    return __get_pin(_EVENT_PIN)


def set_wake_pin():
    """Set the Wake Pin to high voltage/1/on/powered."""
    __set_pin_high(_WAKE_PIN)


def clear_wake_pin():
    """Set the Wake Pin to low/0/off/unpowered."""
    __set_pin_low(_WAKE_PIN)


def set_reset_pin():
    """Set the Reset Pin to high voltage/1/on/powered."""
    __set_pin_high(_RESET_PIN)


def clear_reset_pin():
    """Set the Reset Pin to low voltage/0/off/unpowered."""
    __set_pin_low(_RESET_PIN)
