# Copyright of Amazon Web Services, Inc. (AWS) 2023
#
# This code is licensed under the AWS Intellectual Property License, which can
# be found here: https://aws.amazon.com/legal/aws-ip-license-terms/; provided
# that AWS grants you a limited, royalty-free, revocable, non-exclusive,
# non-sublicensable, non-transferrable license to modify the code for internal
# testing purposes. Your receipt of this code is subject to any non-disclosure
# (or similar) agreement between you and AWS.

import serial
import RPi.GPIO as GPIO
from time import sleep

SERIAL_PORT = "/dev/ttyS0"
WAKE_PIN = 22
RESET_PIN = 23
EVENT_PIN = 27

pi_serial = serial.Serial(SERIAL_PORT, 115200, timeout=0.01)


def initialize_device():
    """Perform any required initialization for a device."""
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(WAKE_PIN, GPIO.OUT)
    GPIO.setup(RESET_PIN, GPIO.OUT)
    GPIO.setup(EVENT_PIN, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

    GPIO.output(WAKE_PIN, 1)
    GPIO.output(RESET_PIN, 1)


def cleanup():
    """Perform any required cleanup and teardown on program termination"""
    GPIO.cleanup()
    pi_serial.close()


def write_device(input: str):
    """Send the string data in input to the device, encoded in iso_8859_1."""
    pi_serial.write(input.encode('iso_8859_1', 'replace'))


def read_device() -> str:
    """Read the data that is currently available in the buffer."""
    received = pi_serial.readline()
    return received.decode('iso_8859_1')


def flush_comms():
    pi_serial.reset_input_buffer()
    pi_serial.reset_output_buffer()


def get_event_pin() -> bool:
    """Return the current voltage state of the Event Pin.

    Return 1 if the pin is high voltage/1/on/powered.
    Return 0 if the pin is low voltage/0/off/unpowered.
    """
    # TODO: On Raspberry Pi, issuing a device reset, then waiting for
    # comms.get_event_pin, then calling AT+EVENT? immediately after
    # results in the message getting dropped.
    # A sleep(0.2) in the raspberry_pi/comms.py implementation of get_event_pin
    # helps solve this issue temporarily, but we should
    # figure out why the command gets dropped between "get_event_pin()" and
    # "AT+EVENT?". This can be done by scoping the uart to ensure messages are
    # sent.
    # ESP32 device logs indicate that we aren't receiving anything. The message
    # could be getting dropped in the ESP32's uart buffer, or it could never
    # actually go over the wire in the first place. The scope will tell.
    sleep(2)
    return GPIO.input(EVENT_PIN)


def set_wake_pin():
    """Set the Wake Pin to high voltage/1/on/powered."""
    GPIO.output(WAKE_PIN, 1)


def clear_wake_pin():
    """Set the Wake Pin to low/0/off/unpowered."""
    GPIO.output(WAKE_PIN, 0)


def set_reset_pin():
    """Set the Reset Pin to high voltage/1/on/powered."""
    GPIO.output(RESET_PIN, 1)


def clear_reset_pin():
    """Set the Reset Pin to low voltage/0/off/unpowered."""
    GPIO.output(RESET_PIN, 0)
