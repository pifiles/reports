# Copyright of Amazon Web Services, Inc. (AWS) 2023
#
# This code is licensed under the AWS Intellectual Property License, which can
# be found here: https://aws.amazon.com/legal/aws-ip-license-terms/; provided
# that AWS grants you a limited, royalty-free, revocable, non-exclusive,
# non-sublicensable, non-transferrable license to modify the code for internal
# testing purposes. Your receipt of this code is subject to any non-disclosure
# (or similar) agreement between you and AWS.

from commands import cmd, comms, connect_with_retries, get_next_event
from polling import poll
import config_handler as cf

# test_section8.py
# Section 8 - Event Handling
# Events are asynchronous messages that the ExpressLink module has received
# and queued on one of the subscribed topics or error messages to reflect
# an unexpected change in the module internal state. Events are appended to
# the module event queue (FIFO). The host can poll the event queue
# periodically, or if connected, following an interrupt (rising edge) on
# the EVENT pin.

# 8.1.1.1   The event queue depth is an implementation dependent parameter
# that must be documented by the vendor in the module datasheet.


# 8.1.1.2   The EVENT pin is asserted (HIGH) when the event queue contains
# one or more events. The EVENT pin will be automatically de-asserted as soon
# as the host processor has emptied the event queue.
def test_8_1_1_2_EventPinBehavior() -> None:
    assert comms.get_event_pin() == False
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd("AT+DISCONNECT\r\n") == "OK 0 DISCONNECTED\r\n"
    assert get_next_event(r'^OK 3 0 CONLOST\r\n$') != None
    poll(lambda: cmd("AT+EVENT?\r\n") == "OK\r\n", step=0.1, timeout=120)
    # Race condition: event might enter between last "AT+EVENT?" and pin check.
    assert comms.get_event_pin() == False


# 8.1.1.3   When the event queue is full, and a new event occurs, the oldest
# event is discarded (circular buffer).


# 8.2       Event Handling Commands
# Retrieve (pop) events from the event queue in the order of arrival.
#
# 8.2.1     EVENT?      Request the next event in the queue
#
# 8.2.1.1	Returns: OK {event_identifier} {parameter} {mnemonic [detail]}{EOL}
# When the queue contains one or more events, the module response returns the
# first event in order of arrival (FIFO). See table Table 4 below for the
# predefined event types.
def test_8_2_1_1_EventQueryFormatFull(get_topic_prefix):
    # Generate startup event
    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    # Generate conlost event
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd("AT+DISCONNECT\r\n") == "OK 0 DISCONNECTED\r\n"
    # Check for events in the appropriate order
    first_event = get_next_event(r'^OK (2 0 STARTUP|3 0 CONLOST)\r\n$')
    assert first_event == "OK 2 0 STARTUP\r\n"
    second_event = get_next_event(r'^OK (2 0 STARTUP|3 0 CONLOST)\r\n$')
    assert second_event == "OK 3 0 CONLOST\r\n"


# 8.2.1.2	Returns: OK{EOL}
# If the event queue is empty the OK response is followed immediately by
# the EOL sequence
def test_8_2_1_2_EventQueryFormatEmpty() -> None:
    poll(lambda: cmd("AT+EVENT?\r\n") == "OK\r\n", step=0.1, timeout=120)


# 8.2.1.3	Sleep, reset and factory reset commands automatically clear all
# events pending.
def test_8_2_1_3_EventQueueClearedSleep() -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd("AT+DISCONNECT\r\n") == "OK 0 DISCONNECTED\r\n"
    assert cmd("AT+SLEEP 1\r\n") == "OK 0\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\r\n") == "OK 2 0 STARTUP\r\n"

    def pop_event_no_conlost() -> str:
        event = cmd("AT+EVENT?\r\n")
        assert event != "OK 3 0 CONLOST\r\n"
        return event

    poll(lambda: pop_event_no_conlost() == "OK\r\n", step=0.1, timeout=120)


def test_8_2_1_3_EventQueueClearedReset() -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd("AT+DISCONNECT\r\n") == "OK 0 DISCONNECTED\r\n"
    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\r\n") == "OK 2 0 STARTUP\r\n"

    def pop_event_no_conlost() -> str:
        event = cmd("AT+EVENT?\r\n")
        assert event != "OK 3 0 CONLOST\r\n"
        return event

    poll(lambda: pop_event_no_conlost() == "OK\r\n", step=0.1, timeout=120)


def test_8_2_1_3_EventQueueClearedFactoryReset() -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd("AT+DISCONNECT\r\n") == "OK 0 DISCONNECTED\r\n"
    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\r\n") == "OK 2 0 STARTUP\r\n"

    def pop_event_no_conlost() -> str:
        event = cmd("AT+EVENT?\r\n")
        assert event != "OK 3 0 CONLOST\r\n"
        return event

    poll(lambda: pop_event_no_conlost() == "OK\r\n", step=0.1, timeout=120)


# Table 4 - ExpressLink event codes
# The following table contains the definition of common event identifiers and
# error codes meant to be implemented by all ExpressLink modules and to
# be considered reserved


# 1 {Topic Index} MSG
# A message was received on topic #
def test_8_table4_EventMsg(get_topic_prefix, iot_client):
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd(f"AT+CONF Topic1={get_topic_prefix}\r\n") == "OK\r\n"
    assert cmd("AT+SUBSCRIBE1\r\n") == "OK\r\n"
    assert get_next_event(r'^OK 8 1 SUBACK\r\n$') != None
    iot_client.publish(topic=get_topic_prefix,
                       payload=f'Message: {get_topic_prefix}')
    assert get_next_event(r'^OK 1 1 MSG\r\n$') != None


# 2 0 STARTUP
# The module has entered the active state
def test_8_table4_EventStartup() -> None:
    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\r\n") == "OK 2 0 STARTUP\r\n"


# 3 0 CONLOST
# Connection lost
def test_8_table4_EventConlost() -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd("AT+DISCONNECT\r\n") == "OK 0 DISCONNECTED\r\n"
    assert get_next_event(r'^OK 3 0 CONLOST\r\n$') != None


# 4 0 OVERRUN
# Receive buffer Overrun (topic in detail)
# OVERRUN tested in test_section5.py

# 5 0 OTA
# OTA event (see OTA? for detail)
# OTA events tested in test_section9.py


# 6 {Connection Hint} CONNECT
# A connection was established or failed
def test_8_table4_EventConnect() -> None:
    endpoint = cf.get('personal_endpoint', str)
    assert cmd(f"AT+CONF Endpoint={endpoint}\r\n") == "OK\r\n"
    assert cmd("AT+CONNECT!\r\n") == "OK\r\n"
    assert get_next_event(r'^OK 6 \d CONNECT\r\n$') != None


# 7 0 CONFMODE
# CONFMODE exit with success
# Untested, CONFMODE is vendor-specific


# 8 {Topic Index} SUBACK
# A Subscription was accepted
def test_8_table4_EventSuback(get_topic_prefix):
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd(f"AT+CONF Topic1={get_topic_prefix}\r\n") == "OK\r\n"
    assert cmd("AT+SUBSCRIBE1\r\n") == "OK\r\n"
    assert get_next_event(r'^OK 8 1 SUBACK\r\n$') != None


# 9 {Topic Index} SUBNACK
# A Subscription was accepted
# Untested, cannot produce on demand

# 20-27 Shadow Events
# Shadow events tested in test_section10.py
