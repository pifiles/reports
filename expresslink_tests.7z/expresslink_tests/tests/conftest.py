# Copyright of Amazon Web Services, Inc. (AWS) 2023
#
# This code is licensed under the AWS Intellectual Property License, which can
# be found here: https://aws.amazon.com/legal/aws-ip-license-terms/; provided
# that AWS grants you a limited, royalty-free, revocable, non-exclusive,
# non-sublicensable, non-transferrable license to modify the code for internal
# testing purposes. Your receipt of this code is subject to any non-disclosure
# (or similar) agreement between you and AWS.

from typing import Literal
from mypy_boto3_iot import IoTClient
from utils import _hex_to_uuid
import pytest
from commands import cmd, comms
from polling import poll
import config_handler as cf
from datetime import datetime
import boto3
from mypy_boto3_iot_data import IoTDataPlaneClient
import paho.mqtt.client as mqtt
from eltest import DeviceLib
from pathlib import Path
import os
import asyncio
import threading
import struct

from bluez_peripheral.util import get_message_bus
from bluez_peripheral.gatt.characteristic import (
    CharacteristicFlags,
    characteristic,
)
from bluez_peripheral.gatt.service import Service
from bluez_peripheral.util import Adapter
from bluez_peripheral.advert import Advertisement
from bluez_peripheral.agent import NoIoAgent
from bluez_peripheral.gatt.characteristic import CharacteristicReadOptions, CharacteristicWriteOptions

_ROOT_CA_PATH = os.path.join(Path(__file__).parent.parent, "AmazonRootCA1.pem")


class TestService(Service):
    """A test service for Bluetooth Low Energy (BLE)"""

    def __init__(self) -> None:
        self.last_ops = None
        self.write_notify_char_val: bytes = None
        self.write_only_char_val: bytes = None
        super().__init__(_hex_to_uuid(cf.get('peer_service_read_uuid', int)))

    @characteristic(_hex_to_uuid(cf.get('peer_characteristic_read_uuid', int)),
                    CharacteristicFlags.READ)
    def read_only_char(self, opts: CharacteristicReadOptions) -> bytes:
        self.last_ops = opts
        val = struct.pack("<f", 1.0)
        return val

    @characteristic(_hex_to_uuid(cf.get('peer_characteristic_write_uuid',
                                        int)), CharacteristicFlags.WRITE)
    def write_only_char(self, _) -> None:
        pass

    @write_only_char.setter
    def write_only_char(self, val: bytes,
                        opts: CharacteristicWriteOptions) -> None:
        self.last_ops = opts
        self.write_only_char_val = val
        print(f"\nServer: Wrote {val.hex()} to the characteristic")

    @characteristic(
        _hex_to_uuid(cf.get('peer_characteristic_subscribe_uuid', int)),
        CharacteristicFlags.NOTIFY | CharacteristicFlags.WRITE)
    def write_notify_char(self, val: bytes, opts) -> None:
        self.last_opts = opts
        self.write_notify_char_val = val

    def update_value(self, value: float) -> None:
        # Bluetooth data is little endian.
        new_val = struct.pack("<f", value)
        self.write_notify_char.changed(new_val)

    async def stop(self) -> None:
        await self.bus.wait_for_disconnect()
        print("\nServer: Stopped the test service")


class TestServer:
    """A server for running a BLE test service"""

    def __init__(self) -> None:
        self.bus = None
        self.service = None
        self.event = threading.Event()

    async def setup(self) -> None:
        self.bus = await get_message_bus()
        self.service = TestService()
        await self.service.register(self.bus)

    async def start(self) -> None:
        await self.setup()

        # An agent to handle pairing
        agent = NoIoAgent()
        await agent.register(self.bus)

        adapter = await Adapter.get_first(self.bus)

        # Start an advert that will last for 300 seconds.
        advert = Advertisement(
            "TestService",
            [_hex_to_uuid(cf.get('peer_service_read_uuid', int))], 0x0340, 300)
        await advert.register(self.bus, adapter)
        print("\nServer: Advertising a BLE service...")
        while not self.event.is_set():
            self.service.update_value(2.0)
            # Handle dbus requests.
            await asyncio.sleep(1)

    def stop(self) -> None:
        self.event.set()
        print("\nServer: Stopping the BLE service...")


class CustomMarker:
    Behavior = Literal['skip', 'run']

    name: str
    switch_behavior: Behavior
    description: str

    def __init__(self, name: str, behavior: Behavior,
                 description: str) -> None:
        self.name = name
        self.switch_behavior = behavior
        self.description = description

    @property
    def switch(self) -> str:
        """Command-line switch for controlling custom marker"""
        return f"--{self.switch_behavior}-{self.name}"

    def requires_switch(self) -> bool:
        return self.switch_behavior == 'run'


MARKERS = [
    CustomMarker('slow', 'skip',
                 'Test takes significant time (over 10 seconds)'),
    CustomMarker('prod', 'skip',
                 'Test is only required for production devices'),
    CustomMarker('destructive', 'run', 'Test may irreparably modify device')
]


def pytest_configure(config: pytest.Config) -> None:
    for marker in MARKERS:
        config.addinivalue_line("markers",
                                f"{marker.name}: {marker.description}")


def pytest_addoption(parser):
    for marker in MARKERS:
        print(marker.switch)
        parser.addoption(
            marker.switch,
            action="store_true",
            default=False,
            help=f"{marker.switch_behavior.capitalize()} {marker.name} tests")


def pytest_collection_modifyitems(config, items) -> None:
    skip_tests: dict = {}
    for marker in MARKERS:
        if marker.requires_switch() != config.getoption(marker.switch):
            reason = "Add {!r} to run" if marker.requires_switch(
            ) else "Skipped by {!r}"
            skip_tests[marker.name] = pytest.mark.skip(
                reason=reason.format(marker.switch))

    for item in items:
        key = next((key for key in item.keywords if key in skip_tests), None)
        if key is not None:
            item.add_marker(skip_tests[key])


def pytest_json_modifyreport(json_report: pytest.TestReport) -> None:
    json_report['expresslink_info'] = pytest.expresslink_info  # type: ignore
    try:
        del json_report['collectors']  # type: ignore
    except Exception:
        pass


@pytest.fixture(autouse=True)
def setup_device(request: pytest.FixtureRequest) -> None:
    """Initializes, factory resets, and configure device"""
    DeviceLib().reset_device()
    config_commands = cf.get('config_commands', list)
    for command in config_commands:
        assert "OK" in cmd(f"{command}\r\n")
    test_name = request.node.originalname  # type: ignore
    print(f"\033[96mExecuting test: \033[92m{test_name}\033[0m")


@pytest.fixture()
def get_topic_prefix(request: pytest.FixtureRequest) -> str:
    """Generates and returns a unique MQTT topic"""
    test_name = request.node.originalname  # type: ignore
    topic_prefix = test_name + datetime.now().isoformat()
    return topic_prefix


@pytest.fixture()
def iot_services_client(request: pytest.FixtureRequest) -> IoTClient:
    return boto3.client('iot')


@pytest.fixture()
def iot_client(request: pytest.FixtureRequest) -> IoTDataPlaneClient:
    """Authenticates with AWS IoT console and returns a data-plane client
       https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/iot-data.html"""
    return boto3.client('iot-data')


@pytest.fixture()
def mqtt_client(request: pytest.FixtureRequest) -> mqtt.Client:
    """Authenticates with AWS IoT MQTT endpoint and returns an MQTT client
       https://pypi.org/project/paho-mqtt/"""
    client = mqtt.Client(protocol=mqtt.MQTTv5, client_id="testclient-")
    assert mqtt.ssl
    client.tls_set(ca_certs=_ROOT_CA_PATH,
                   certfile="credentials/tests-certificate.crt",
                   keyfile="credentials/tests-private.key",
                   tls_version=mqtt.ssl.PROTOCOL_TLS_CLIENT)

    endpoint = cf.get("personal_endpoint", str)
    print(f"Attempting to connect to: {endpoint}")

    done = False

    def on_connect(client, userdata, flags, reason, props):
        nonlocal done
        done = True

    def check_connect() -> bool:
        client.loop(timeout=60)
        return done

    client.on_connect = on_connect
    client.connect(host=endpoint, port=8883, keepalive=60)
    poll(check_connect, timeout=120, step=0)
    client.on_connect = None

    return client


@pytest.fixture()
def staging_mqtt_client(request: pytest.FixtureRequest) -> mqtt.Client:
    """Authenticates with AWS IoT MQTT endpoint and returns an MQTT client
       https://pypi.org/project/paho-mqtt/"""
    client = mqtt.Client(protocol=mqtt.MQTTv5, client_id="testclient-")
    client.tls_set(ca_certs=_ROOT_CA_PATH,
                   certfile=cf.test_config["claim_certificate_path"].get(str),
                   keyfile=cf.test_config["claim_private_key_path"].get(str),
                   tls_version=mqtt.ssl.PROTOCOL_TLS_CLIENT)

    endpoint: str = pytest.expresslink_info["staging_endpoint"]
    print(f"Attempting to connect to: {endpoint}")

    done = False

    def on_connect(client, userdata, flags, reason, props):
        nonlocal done
        done = True

    def check_connect() -> bool:
        client.loop(timeout=60)
        return done

    client.on_connect = on_connect
    client.connect(host=endpoint, port=8883, keepalive=60)
    poll(check_connect, timeout=120, step=0)
    client.on_connect = None

    return client


@pytest.fixture()
def get_shadow_prefix(request: pytest.FixtureRequest) -> str:
    # type: ignore
    return f'$aws/things/{pytest.expresslink_info["thing_name"]}/shadow'


@pytest.fixture(scope="session", autouse=True)
def get_ble_server() -> None:
    test_server = TestServer()

    def ble_server_run(loop):
        asyncio.set_event_loop(loop)
        loop.run_until_complete(test_server.start())
        loop.close()

    loop = asyncio.new_event_loop()
    server_thread = threading.Thread(target=ble_server_run,
                                     args=(loop, ),
                                     daemon=True)
    server_thread.start()
    yield
    test_server.stop()
    server_thread.join()
