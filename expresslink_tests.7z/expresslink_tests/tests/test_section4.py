# Copyright of Amazon Web Services, Inc. (AWS) 2023
#
# This code is licensed under the AWS Intellectual Property License, which can
# be found here: https://aws.amazon.com/legal/aws-ip-license-terms/; provided
# that AWS grants you a limited, royalty-free, revocable, non-exclusive,
# non-sublicensable, non-transferrable license to modify the code for internal
# testing purposes. Your receipt of this code is subject to any non-disclosure
# (or similar) agreement between you and AWS.

from commands import cmd, comms, connect_with_retries, get_next_event, get_next_event_match
from polling import poll, TimeoutException
import config_handler as cf
import re
import pytest
import random
import time
import paho.mqtt.client as mqtt
from tests.mqtt_client import subscribe, wait_for_message

# test_section6.py
# Section 4 - ExpressLink Commands
# 4.1.1.1 These are commands that are sent to/from the UART. The default UART configuration
# shall be 115200, 8, N, 1 (baud rate: 115,200; data bits: 8; parity: none; stop bits: 1). There
# is no hardware or software flow control for UART communications.
# 4.1.1.2 Baud rate will NOT be configurable.
# 4.1.1.3 No Local Echo is provided.

# 4.2       ExpressLink Commands Format

# 4.2.1 {command}
#
# A short alphabetical character string (including ‘_’, ‘!’, and ‘?’) matching one of the commands listed in
# the following sections. (i.e., CONNECT, TIME?, FACTORY_RESET )
#
# Note: Commands are not case sensitive.
# Although, in these tests, uppercase is always used for consistency.


# 4.2.1.1 Return ERR3 COMMAND NOT FOUND if the command is unknown
def test_4_2_1_1_CommandNotFound() -> None:
    unknown_command: str = 'A' * 32
    assert cmd(f'AT+{unknown_command}\r\n') == 'ERR3 COMMAND NOT FOUND\r\n'


# 4.2.2     [#] Optional numerical suffix (first parameter)
# An optional decimal (0..N) suffix (multiple digits allowed) is used by a selected commands (i.e., SEND) as
# a first numerical parameter
#
# 4.2.2.1   Return ERR4 PARAMETER ERROR if a numerical suffix was provided but the command did
# not expect it (i.e., CONNECT5), or if a numerical suffix is missing but required (i.e.,
# SUBSCRIBE).
def test_4_2_2_1_NumericSuffixParameterError() -> None:
    unexpected_suffix: str = 'CONNECT5'
    assert cmd(f'AT+{unexpected_suffix}\r\n') == 'ERR4 PARAMETER ERROR\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    missing_suffix: str = 'SUBSCRIBE'
    assert cmd(f'AT+{missing_suffix}\r\n') == 'ERR4 PARAMETER ERROR\r\n'


# 4.2.2.2   Return ERR7 OUT OF RANGE if the numeric suffix is out of the valid range for the
# command. (i.e., GET100 when MaxTopic is 16)
def test_4_2_2_2_NumericSuffixOutOfRange() -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))
    too_large_index: str = 'SUBSCRIBE999'
    assert cmd(f"AT+{too_large_index}\r\n") == "ERR7 OUT OF RANGE\r\n"


# 4.2.4     {separator}
# A single ascii space character (0x20)
#
# 4.2.4.1   Return ERR2 PARSE ERROR if ANY character other than 0x20 is present after the numerical
# suffix or ‘?’ in the command string.
def test_4_2_4_1_AllowsOnlySpaceAfterSuffix() -> None:
    numeric_suffix: str = 'SUBSCRIBE1'
    query_suffix: str = 'CONF?'
    parameter = 'About'

    def test_separators(command: str, parameter: str = ''):
        reserved_chars: set[str] = {'\r', '\n', ' ', '!', '?', '_'}
        for byte in range(256):
            char: str = chr(byte)
            if (char not in reserved_chars and not char.isnumeric()
                    and not char.isalpha()):
                assert cmd(f'AT+{command}{char} {parameter}\r\n'
                           ) == 'ERR2 PARSE ERROR\r\n'

    test_separators(query_suffix, parameter)
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+CONF Topic1=topic\r\n') == "OK\r\n"
    test_separators(numeric_suffix)


# 4.2.5     [parameter] optional parameter
# An (escaped) ASCII string with the data required for the command.
#
# 4.2.5.1   Return ERR4 PARAMETER ERROR if the command is unable to process the parameter
# supplied.
def test_4_2_5_1_ProcessParameterError() -> None:
    text_parameter = 'Five'
    assert cmd(f'AT+SLEEP {text_parameter}\r\n') == 'ERR4 PARAMETER ERROR\r\n'


# 4.2.6     {EOL}
# The ASCII line feed character (0x0a) OR the ASCII carriage return character (0x0d).
def test_4_2_6_LineFeedOrCarriageReturn() -> None:
    assert cmd("AT\r") == "OK\r\n"
    assert cmd("AT\n") == "OK\r\n"


# 4.2.7     Parameter String Note
# The parameter string includes all bytes from the separator to the EOL, not including either the separator
# or the EOL. All character values (0 - 0xFF) are valid in the parameter string, allowing for binary payloads,
# provided proper escaping is performed as detailed in 4.3.
def test_4_2_7_BinaryParametersAllowed(get_topic_prefix: str,
                                       mqtt_client: mqtt.Client) -> None:
    assert cmd(f'AT+CONF Topic1={get_topic_prefix}\r\n')
    assert subscribe(mqtt_client, topic=get_topic_prefix)
    binary = b'\xFF \x00'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SEND1 \xFF \x00\r\n') == 'OK\r\n'
    topic, payload = wait_for_message(mqtt_client, timeout=120, step=0.01)
    assert payload == binary


# 4.3   Delimiters and Escaping
# The format described in the previous section and the specific choice of delimiters are intended to
# remove entirely the need for quotes surrounding parameters and others delimiters between successive
# parameter. As a further benefit, this removes the need for most escaping sequences with the exclusion
# of the ascii characters EOL (0x0a) and backslash.
#
# 4.3.1     EOL in the parameter string (input escaping)
# If a line feed character (0x0a) or a carriage return character (0x0d) are required in the parameter string
# they will be replaced by the backslash escaped sequence as follows:
#
# 4.3.1.1   Line feed will be escaped as: 0x5C 0x41 or ‘\A’
def test_4_3_1_1_EscapeLineFeedInput() -> None:
    line_feed_value = 'mytopic\\Atwo'
    assert cmd(f'AT+CONF Topic1={line_feed_value}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF? Topic1\r\n') == f'OK {line_feed_value}\r\n'


# 4.3.1.2   Carriage return will be escaped as: 0x5C 0x44 or ‘\D
def test_4_3_1_2_EscapeCarriageReturnInput() -> None:
    carriage_return_value = 'mytopic\\Atwo'
    assert cmd(f'AT+CONF Topic1={carriage_return_value}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF? Topic1\r\n') == f'OK {carriage_return_value}\r\n'


# 4.3.2     Backslash ('\') in the parameter string
# Backslash (0x5C, ‘\’) in the parameter string will be replaced by the escape sequence: 0x5C, 0x5C or ‘\\’
def test_4_3_2_EscapeCarriageReturnInput() -> None:
    backslash_value = 'mytopic\\\\two'
    assert cmd(f'AT+CONF Topic1={backslash_value}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF? Topic1\r\n') == f'OK {backslash_value}\r\n'


# 4.3.2.1   All other combinations of the escape sequence are illegal and will return ERR5 INVALID
# ESCAPE
def test_4_3_2_1_EscapeInvalid() -> None:
    allowed_escapes: set[str] = {'A', 'D', '\\'}

    def assert_bad_escape(bad_escape: str):
        if bad_escape not in allowed_escapes:
            assert cmd(f'AT+CONF Topic1=myTopic\\{bad_escape}\r\n'
                       ) == 'ERR5 INVALID ESCAPE\r\n'

    assert_bad_escape('')

    for byte in range(256):
        assert_bad_escape(chr(byte))


# 4.4   Maximum Values
#
# 4.4.1     Maximum bytes in the formatted command string
# The formatted command string as received by the ExpressLink can be up to 9K byte in length.
# AT+[ up to 9K bytes ]{EOL}
def test_4_4_1_MaxCommandStringLength() -> None:
    long_string = 'A' * 9000
    assert cmd(f'AT+{long_string}\r\n') == 'ERR2 PARSE ERROR\r\n'


# 4.4.2     Maximum Command Word Size
# The command word portion of the command string can be up to 32 bytes long.
def test_4_4_2_MaxCommandWordLength() -> None:
    long_command = 'A' * 33
    assert cmd(f'AT+{long_command}\r\n') == 'ERR2 PARSE ERROR\r\n'


# 4.5       Data processing
#
# 4.5.1     Data Entry
# The data entry for a command begins with the 'AT+' and ends with the EOL. It is not permitted to begin
# executing a command before receiving the EOL.
@pytest.mark.slow
def test_4_5_1_ExecutionBeforeEOL() -> None:
    comms.write_device('AT+CONF? Topic1')

    # check if device processes command before EOL
    try:
        bad_response: str = poll(comms.read_device, step=0.1, timeout=30)
        pytest.fail(
            'ExpressLink responded illegally without an EOL.\nResponse: {!r}'.
            format(bad_response.encode('iso_8859_1')))
    except TimeoutException:
        pass

    # add EOL and await response to confirm execution
    assert cmd('\r\n') == 'OK \r\n'


# 4.5.2     Data Overflow
# If the data buffer overflows during the data entry phase of command execution, the ExpressLink module
# will continue to accept but discard the incoming data until the next EOL arrives.
#
# 4.5.2.1   The command response will be ERR1 OVERFLOW and the entire message will be discarded.
def test_4_5_2_1_DataOverflow() -> None:
    too_long_string = 'A' * 9001
    assert cmd(f'AT+{too_long_string}\r\n') == 'ERR1 OVERFLOW\r\n'

    # seeded to ensure consistent test string
    random.seed(1)
    too_long_random_sample: str = ''
    deny_list: set[int] = {ord('\r'), ord('\n'), ord(' ')}
    while len(too_long_random_sample) < 10000:
        byte: int = random.randint(0, 255)
        if byte not in deny_list:
            too_long_random_sample += chr(byte)
    assert cmd(f'AT+{too_long_random_sample}AT+CONF? Topic1\r\n'
               ) == 'ERR1 OVERFLOW\r\n'

    # AT+CONF? command should have been discarded and not processed
    try:
        bad_response: str = poll(comms.read_device, step=0.1, timeout=20)
        pytest.fail('Device responded illegally\nResponse: "{!r}"'.format(
            bad_response.encode('iso_8859_1')))
    except TimeoutException:
        pass

    # error is recoverable, commands continue to be processed
    assert cmd('AT\r\n') == 'OK\r\n'


# 4.5.3     Data arriving after EOL
# Any data that arrives after the first EOL character and before the next 'AT' sequence will be ignored and
# discarded. Note how this includes the case of multiple EOL characters which will be similarly ignored and
# discarded.
def test_4_5_3_DataArrivingAfterEOL() -> None:
    # spurious characters preceding a command are ignored
    assert cmd('abcdefAT\n') == 'OK\r\n'

    # carriage return followed by line feed
    assert cmd('AT\r\n') == 'OK\r\n'

    # line feed followed by carriage return
    assert cmd('AT\n\r') == 'OK\r\n'

    # multiple carriage returns
    assert cmd('AT\r\r') == 'OK\r\n'


# 4.6   Command Responses and Error Codes
# All commands will respond, according to the response format described in section 4.6.1, when the
# command has been completed. In some cases, this can take a significant amount of time, but under no
# circumstances longer than the response timeout defined in section 0.
#
# 4.6.1     The general response formats
# OK[#] | ERR{#}{separator}[detail]{EOL}
# Where:
# - OK[#] Indicates the command was valid and executed correctly, the optional
# numerical suffix [#] indicates the number of additional output lines. No additional line to be
# expected if omitted.
# - ERR{#} Indicates the command was invalid or an error occurred while executing it. The
# required numerical suffix is the error codes as defined in Table 1
# - {separator} Is a single ascii space character (0x20)
# - [detail] Is an optional ascii string containing the command response or error description
# - {EOL} Is composed of a carriage return (0x0d) followed by a newline character (0x0a)
#
# 4.6.2    Response Timeout - Maximum is 120 seconds
# Datasheet of timeouts is made by vendor, unable to test anything here
#
# 4.6.3     AT Communication Test
# By sending only the ‘AT’ (attention) command, the host can verify the presence and readiness of the
# module command parser
def test_4_6_3_ATCommunicationTest() -> None:
    assert cmd('AT\r\n') == 'OK\r\n'


# 4.7       Power and Connection Control
# 4.7.1     CONNECT? Request the connection status
# Requests the current status of the connection to the AWS cloud and the device onboarding state (see 0).
# The connection status indicates the completion of the entire sequence of actions required for the
# module to connect and authenticate with the AWS cloud. The onboarding state is determined by
# comparing the current Endpoint configuration parameter (string) against the module default Endpoint
# (staging account) string which is hardcoded as the factory reset value for the parameter (see Table 2,
# Endpoint entry).
# Returns: OK {status} {onboarded} [CONNECTED/DISCONNECTED] [STAGING/CUSTOMER]

# 4.7.1.1   OK 1 0 CONNECTED STAGING device connected to staging account
# Not tested due to JITP


# 4.7.1.2   OK 0 0 DISCONNECTED STAGING device not connected (staging account)
def test_4_7_1_2_DisconnectedStaging() -> None:
    assert cmd('AT+CONNECT?\r\n') == 'OK 0 0 DISCONNECTED STAGING\r\n'


# 4.7.1.3   OK 1 1 CONNECTED CUSTOMER device connected and onboarded (customer account)
def test_4_7_1_3_ConnectedOnboarded() -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+CONNECT?\r\n') == 'OK 1 1 CONNECTED CUSTOMER\r\n'


# 4.7.1.4   OK 0 1 DISCONNECTED CUSTOMER device not connected (customer account)
def test_4_7_1_4_DisconnectedOnboarded() -> None:
    assert cmd('AT+CONF Endpoint=test\r\n') == 'OK\r\n'
    assert cmd('AT+CONNECT?\r\n') == 'OK 0 1 DISCONNECTED CUSTOMER\r\n'


# 4.7.2     CONNECT Establish a connection to an IoT Core Endpoint
# Request a connection to an AWS cloud account, bringing an active device into a higher power
# consumption mode where it is able to communicate with the AWS IoT Core endpoint.
# Note: This command is blocking. The connection process can require a long amount of time during
# which no further communication is possible with the module until one of the following responses is
# returned to the host. (For a non-blocking option, see the asynchronous CONNECT! command in 4.7.8).
#
# 4.7.2.1   Returns: OK 1 CONNECTED
# The module has successfully connected to AWS IoT Core. Note the connection process can require a
# significantly long time during which no further commands can be processed.
def test_4_7_2_1_SuccessfulConnection() -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))


# 4.7.2.2   Returns: ERR14 {#hint} UNABLE TO CONNECT [detail]
# The module is unable to connect, additional clues are provided (mandatory) by the {#hint} numerical
# code and optional [detail] field. Hint numerical codes indicate the state of advancement of the
# connection process when the failure occurred so that meaningful debugging tips can be provided in the
# module documentation (datasheet, FAQ).
def test_4_7_2_2_FailedConnection() -> None:
    bad_endpoint: str = 'notavalidendpoint.orvaliddomain'
    assert cmd(f'AT+CONF Endpoint={bad_endpoint}\r\n') == 'OK\r\n'
    assert re.match(r'^ERR14 [1-6](?:\.[0.9]+)? UNABLE TO CONNECT.*\r\n$',
                    cmd('AT+CONNECT\r\n'))


# 4.7.2.3   if the ExpressLink module is already connected, issuing a CONNECT command will return
# immediately with a success response (OK 1 CONNECTED).
def test_4_7_2_3_AlreadyConnected() -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+CONNECT\r\n') == 'OK 1 CONNECTED\r\n'


# 4.7.2.4   In case of connection failure, the ExpressLink module will keep a timestamp of the event.
# This will be used to ensure that a subsequent (repeated) connection request will comply
# with the correct backoff timing limits.
#
# This test only verifies that a repeated connection can fail due to imposed backoff
def test_4_7_2_4_BackoffAfterFailure() -> None:
    bad_endpoint: str = 'notavalidendpoint.orvaliddomain'
    assert cmd(f'AT+CONF Endpoint={bad_endpoint}\r\n') == 'OK\r\n'

    for i in range(20):
        if cmd(
                'AT+CONNECT\r\n'
        ) == 'ERR14 1 UNABLE TO CONNECT Backoff algorithm imposed delay\r\n':
            print(f'Successfully backed off after attempt {i}')
            break
    else:
        pytest.fail('Device did not successfully backoff after 20 attempts')


# 4.7.3     DISCONNECT Leave the connected state and enter the active state
# This command allows the host to prepare for a transition to low power (via the SLEEP command) or to
# update the connection parameters before reconnecting again (via a new CONNECT command) for
# changes to take effect.
#
# Returns:
# 4.7.3.1   OK 0 DISCONNECTED
# Note that if already disconnected, the command will return immediately with a success value (OK 0
# DISCONNECTED).
def test_4_7_3_1_AlreadyDisconnected() -> None:
    assert cmd('AT+DISCONNECT\r\n') == 'OK 0 DISCONNECTED\r\n'
    assert cmd('AT+DISCONNECT\r\n') == 'OK 0 DISCONNECTED\r\n'


# 4.7.4     SLEEP{#} [duration] Request to enter a low power mode
# This command forces the module to enter a low power mode. ExpressLink module manufacturers can
# implement specific low power modes with increasing values (#) corresponding to deeper sleep states (as
# capable) in order to provide the lowest power consumption and longest possible battery life. The
# manufacturer will document the power consumption figures achievable in such modes in the module
# datasheet.
#
# Section 4.7.4 is untested because the behavior of AT+SLEEP with higher values will necessarily
# be vendor-dependent and/or hardware-dependent behavior
#
# 4.7.4.1   The duration parameter, if present, indicates the number of seconds before the module
# will awake automatically.
def test_4_7_4_1_SleepDuration() -> None:
    seconds_to_sleep: int = 10
    print(f'Sleeping device for {seconds_to_sleep} seconds')
    assert re.match(r'^OK 0.*\r\n$', cmd(f'AT+SLEEP0 {seconds_to_sleep}\r\n'))
    start: float = time.perf_counter()
    poll(comms.get_event_pin, step=0.01, timeout=seconds_to_sleep * 2)
    stop: float = time.perf_counter()
    assert cmd('AT+EVENT?\r\n') == 'OK 2 0 STARTUP\r\n'
    assert cmd('AT\r\n') == 'OK\r\n'
    seconds_slept: float = stop - start
    print(f'Woke up after {seconds_slept} seconds')

    tolerance: float = 2.0
    error: float = seconds_slept - seconds_to_sleep
    if error > tolerance:
        pytest.fail('Device took too long to wake up')
    elif error < -tolerance:
        pytest.fail('Device woke up too quickly')


# 4.7.4.2   If the duration is absent, the module will remain in low power mode until:
def _verify_indefinite_sleep() -> None:
    """Verifies that device remains in low-power mode"""
    assert re.match(r'^OK 0.*\r\n$', cmd('AT+SLEEP0 40\r\n'))

    def event_available() -> bool:
        available: bool = comms.get_event_pin()
        print(end='.', flush=True)
        return available

    print('Verifying sleep is indefinite', end='')
    try:
        poll(event_available, step=1, timeout=30)
        pytest.fail('Device woke up from indefinite sleep')
    except TimeoutException:
        pass
    print('\n')


# 1.        A hardware Reset is generated by the host lowering the RST pin
def test_4_7_4_2_1_SleepInterruptedResetPin() -> None:

    _verify_indefinite_sleep()

    comms.clear_reset_pin()
    time.sleep(1)
    comms.set_reset_pin()

    start = time.perf_counter()
    poll(comms.get_event_pin, step=0.01, timeout=120)
    stop = time.perf_counter()

    comms.flush_comms()

    assert cmd('AT+EVENT?\r\n') == 'OK 2 0 STARTUP\r\n'
    assert cmd('AT\r\n') == 'OK\r\n'
    print(f'Woke up after {stop - start} seconds')


# 2.        A wakeup event is generated by the host lowering the WAKE pin
def test_4_7_4_2_2_SleepInterruptedWakePin() -> None:
    _verify_indefinite_sleep()

    comms.clear_wake_pin()

    start = time.perf_counter()
    poll(comms.get_event_pin, step=0.01, timeout=120)
    stop = time.perf_counter()

    assert cmd('AT+EVENT?\r\n') == 'OK 2 0 STARTUP\r\n'
    assert cmd('AT\r\n') == 'OK\r\n'
    print(f'Woke up after {stop - start} seconds')


# 3.        A new AT command is sent by the host using the serial interface (this might not be possible in
# case of advanced (deep) sleep modes, see 4.7.4.4)
def test_4_7_4_2_3_SleepInterruptedCommand() -> None:
    _verify_indefinite_sleep()

    start = time.perf_counter()
    response = cmd('AT\r\n')
    stop = time.perf_counter()

    assert response == 'OK\r\n'
    print(f'Woke up after {stop - start} seconds')


# 4.7.4.3   A SLEEP command without a numerical suffix will default to mode 0.
# Mode 0 is the default low power mode where the ExpressLink module reduces its power consumption
# as much as possible while still maintaining the serial interface active and preserving the contents of all
# configuration parameters
def test_4_7_4_3_DefaultSleep() -> None:
    topic: str = 'myTopic'
    assert cmd(f'AT+CONF Topic1={topic}\r\n') == 'OK\r\n'
    assert re.match(r'^OK 0.*\r\n$', cmd('AT+SLEEP0\r\n'))
    time.sleep(1)
    # Serial still active and Topic1 remains configured
    assert cmd('AT+CONF? Topic1\r\n') == f'OK {topic}\r\n'


# 4.7.4.4   Before entering SLEEP mode, the device will empty the event queue
# Advanced low power modes can disable the serial command interface. In these cases, in absence of the
# sleep duration parameter, the only way to awake the device would be to apply an external reset or wake
# signal. Deep sleep states might cause loss of part or all volatile (RAM) information including
# configuration parameters that are not maintained in non-volatile memory (i.e. Topics). The host
# processor will have to reconfigure such parameters as required by the application.
def test_4_7_4_4_SleepClearsEventQueue() -> None:
    # test setup consumes the first startup event, so performs two passess
    for i in range(2):
        assert re.match(r'^OK 0.*\r\n$', cmd('AT+SLEEP0\r\n'))
        # event queue should be cleared after sleep, on both passes
        if comms.get_event_pin():
            pytest.fail('Event queue was not cleared after AT+SLEEP')
        # wake device before next pass, which adds the startup event
        assert cmd('AT\r\n') == 'OK\r\n'

    # After sleeping multiple times, only one startup event should be present
    assert cmd('AT+EVENT?\r\n') == 'OK 2 0 STARTUP\r\n'
    assert cmd('AT+EVENT?\r\n') == 'OK\r\n'


# 4.7.4.5   Returns: OK {mode} [{detail}]
# The device is ready and will proceed to the low power mode selected immediately after sending the
# reply (and flushing the serial port output). {mode} is the sleep mode activated
def test_4_7_4_5_SleepFormat() -> None:
    # A numerical value is expected for {duration}
    assert cmd('AT+SLEEP SOME TEXT\r\n') == 'ERR4 PARAMETER ERROR\r\n'

    # A numerical value is expected for {mode}
    assert cmd('AT+SLEEP9A\r\n') == 'ERR2 PARSE ERROR\r\n'

    assert re.match(r'^OK 0.*\r\n$', cmd('AT+SLEEP0 1\r\n'))
    assert poll(comms.get_event_pin, step=0.01, timeout=120)


# 4.7.4.6   Returns: ERR18 ACTIVE CONNECTION
# The device cannot transition to a low power mode because there is an active cloud connection. Use the
# DISCONNECT command first to terminate the connection.
def test_4_7_4_6_NoSleepDuringConnection() -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SLEEP\r\n') == 'ERR18 ACTIVE CONNECTION\r\n'
    cmd('AT+DISCONNECT\r\n')
    assert re.match(r'^OK 0.*\r\n$', cmd('AT+SLEEP0 1\r\n'))
    poll(comms.get_event_pin, timeout=5, step=0.01)


# 4.7.4.7   Sleep mode fall back.
# In case the host is requesting a SLEEP mode higher than any implemented on the specific ExpressLink
# model, the module will fall back to the nearest/highest mode available (i.e. SLEEP9, might fall back to
# SLEEP3 if mode 3 is the highest available or simply SLEEP if no advanced modes are available). The actual
# sleep mode activated will be reported in the response.
def test_4_7_4_7_SleepModeFallback() -> None:
    max_sleep = cf.get("device_max_sleep_mode", int)
    response: str = cmd('AT+SLEEP999\r\n')
    assert re.match(f'^OK {max_sleep}.*\r\n$', response)
    # Lowering WAKE pin generates a wakeup event
    comms.clear_wake_pin()
    assert poll(comms.get_event_pin, timeout=120, step=0.01)


# 4.7.4.8   Upon returning to the active state, a STARTUP event is generated (see chapter 8) and
# added to the event queue.
def test_4_7_4_8_SleepEndStartupEvent() -> None:
    assert re.match(r'^OK 0.*\r\n$', cmd('AT+SLEEP0\r\n'))
    time.sleep(0.5)
    comms.clear_wake_pin()
    assert get_next_event(r'^.*STARTUP.*\r\n')


# 4.7.5     CONFMODE [parameter] Activate modal credential entry
# ExpressLink modules requiring additional user credentials can be set by the host to enter CONFMODE
# (see Figure 2) in order to enable or repurpose an interface to receive additional connection credentials
# from user input.
#
# Example 1: An ExpressLink Wi-Fi module could use this command to enter a SoftAP mode temporarily
# assuming the role of an Access Point and serving an HTML form allowing the user to enter the local Wi-Fi
# router credentials via a mobile device web browser. The optional parameter could be used to provide a
# customized unique SSID based on the device UID.
#
# Example 2: If a Bluetooth interface is available, the ExpressLink module could receive the credentials via
# a serial interface (SPP profile) or, for BLE modules, this could be performed via a dedicated (GATT)
# service using a custom mobile application.
#
# Note: CONFMODE is not rqeuired for board qualification.
#
# 4.7.5.1   Returns: OK CONFMODE ENABLED
# The device has entered CONFMODE and is ready to receive user inpu
@pytest.mark.skipif(not cf.get('feature_confmode', bool),
                    reason='CONFMODE unavailable')
def test_4_7_5_1_ConfmodeEnabled() -> None:
    assert cmd('AT+CONFMODE\r\n') == 'OK CONFMODE ENABLED\r\n'


# 4.7.5.2   Returns: ERR17 MODE NOT AVAILABLE
# This ExpressLink model/version does not support CONFMODE
@pytest.mark.skipif(cf.get('feature_confmode', bool),
                    reason='CONFMODE available')
def test_4_7_5_2_ConfmodeDisabled() -> None:
    assert cmd('AT+CONFMODE\r\n') == 'ERR17 MODE NOT AVAILABLE\r\n'


# 4.7.5.3   Returns: ERR18 ACTIVE CONNECTION
# The device cannot enter CONFMODE because currently connected or an asynchronous connection
# attempt is in progress ( see 4.7.8). The host must disconnect first
@pytest.mark.skipif(not cf.get('feature_confmode', bool),
                    reason='CONFMODE unavailable')
def test_4_7_5_3_ConfmodeWhileConnectedFails() -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+CONFMODE\r\n') == 'ERR18 ACTIVE CONNECTION\r\n'


# 4.7.5.4   While in CONFMODE an ExpressLink module can still process all commands that do not
# require an active connection (i.e., AT+CONF? Version).
@pytest.mark.skipif(not cf.get('feature_confmode', bool),
                    reason='CONFMODE unavailable')
def test_4_7_5_3_ConfmodeAllowsOfflineCommands() -> None:
    assert cmd('AT+CONFMODE\r\n') == 'OK CONFMODE ENABLED\r\n'
    assert cmd('AT+CONF? Topic1\r\n') == 'OK \r\n'


# 4.7.5.5   Commands that require an active connection will return ERR6 NO CONNECTION.
# Attempting to issue a CONNECT command while in CONFMODE will result in an ERR14
# UNABLE TO CONNECT.
@pytest.mark.skipif(not cf.get('feature_confmode', bool),
                    reason='CONFMODE unavailable')
def test_4_7_5_5_ConfmodeDisallowsConnect() -> None:
    assert cmd('AT+CONFMODE\r\n') == 'OK CONFMODE ENABLED\r\n'
    assert cmd('AT+CONNECT\r\n') == 'ERR25 NOT ALLOWED\r\n'
    cmd('AT+CONF Topic1=myTopic\r\n')
    assert cmd('AT+SEND1 myMessage\r\n') == 'ERR6 NO CONNECTION\r\n'


# 4.7.5.6   The host may issue a RESET command at any time to abort CONFMODE
@pytest.mark.skipif(not cf.get('feature_confmode', bool),
                    reason='CONFMODE unavailable')
def test_4_7_5_6_ConfmodeResetAbort() -> None:
    assert cmd('AT+CONFMODE\r\n') == 'OK CONFMODE ENABLED\r\n'
    assert cmd('AT+RESET\r\n') == 'OK\r\n'
    poll(comms.get_event_pin, step=0.01, timeout=120)
    assert connect_with_retries(cf.get('personal_endpoint', str))


# 4.7.5.7   A CONFMODE notification event (see Table 4) will be provided to the host upon
# completion of the new credentials’ entry. Only then the host will be able to issue a new
# CONNECT command to attempt to establish a connection using the newly entered
# credentials.
#
# This section is not tested because
# updating credentials in CONFMODE is vendor-specified behavior.


# 4.7.6     RESET Request a full reset of the ExpressLink internal state
# This command disconnects the device (if connected) and resets all internal state. Non-persistent
# configuration parameters (see Table 3) are reinitialized, all subscriptions are terminated, and the
# message queues is emptied.
def test_4_7_6_ResetNonPersistentConfig() -> None:
    custom_name: str = 'myCustomName'
    cmd(f'AT+CONF CustomName={custom_name}\r\n')
    cmd('AT+CONF Topic1=myTopic\r\n')
    cmd('AT+CONF QoS=1\r\n')

    comms.clear_reset_pin()
    time.sleep(1)
    comms.set_reset_pin()
    assert poll(comms.get_event_pin, timeout=120, step=0.01)
    comms.flush_comms()

    assert cmd('AT+CONF? CustomName\r\n') == f'OK {custom_name}\r\n'
    assert cmd('AT+CONF? Topic1\r\n') == 'OK \r\n'
    assert cmd('AT+CONF? QoS\r\n') == 'OK 0\r\n'


# 4.7.6.1   Returns: OK
def test_4_7_6_1_ResetCommand() -> None:
    assert cmd('AT+RESET\r\n') == 'OK\r\n'
    assert poll(comms.get_event_pin, timeout=120, step=0.01)


# 4.7.6.2   A STARTUP event is added to the event queue when the process is completed.
def test_4_7_6_2_ResetStartupEvent() -> None:
    assert cmd('AT+RESET\r\n') == 'OK\r\n'
    assert poll(comms.get_event_pin, timeout=120, step=0.01)
    assert cmd('AT+EVENT?\r\n') == 'OK 2 0 STARTUP\r\n'


# 4.7.7     FACTORY_RESET Request a factory reset of the module
# This command performs a full factory reset of the ExpressLink module, including re-initializing all non-
# persistent configuration parameters (see Table 3), selected persistent parameters (as indicated in
# Table 2 Factory Reset column) and the message queues is emptied.
def test_4_7_7_FactoryResetPersistentStorage() -> None:
    custom_name: str = 'myCustomName'
    cmd(f'AT+CONF CustomName={custom_name}\r\n')
    cmd('AT+CONF Topic1=myTopic\r\n')
    cmd('AT+CONF QoS=1\r\n')

    assert cmd('AT+FACTORY_RESET\r\n') == 'OK\r\n'
    assert poll(comms.get_event_pin, timeout=120, step=0.01)

    assert cmd('AT+CONF? CustomName\r\n') == 'OK \r\n'
    assert cmd('AT+CONF? Topic1\r\n') == 'OK \r\n'
    assert cmd('AT+CONF? QoS\r\n') == 'OK 0\r\n'


# 4.7.7.1   Returns: OK
def test_4_7_7_1_FactoryResetCommand() -> None:
    assert cmd('AT+FACTORY_RESET\r\n') == 'OK\r\n'
    assert poll(comms.get_event_pin, timeout=120, step=0.01)


# 4.7.7.2   A STARTUP event is added to the event queue when the process is completed.
def test_4_7_7_2_FactoryResetStartupEvent() -> None:
    assert cmd('AT+FACTORY_RESET\r\n') == 'OK\r\n'
    assert poll(comms.get_event_pin, timeout=120, step=0.01)
    assert cmd('AT+EVENT?\r\n') == 'OK 2 0 STARTUP\r\n'


# 4.7.8     CONNECT! Non-blocking request to connect to IoT Core
# Request a connection to the AWS cloud, bringing an active device into a higher power consumption
# mode where it is able to communicate with the AWS IoT Core endpoint.
# Note: This command is non-blocking. The connection process can require a large amount of time during
# which other power and connection control commands will be rejected until the connection is established
# and a CONNECT event is issued.
# (For a blocking option, see the synchronous CONNECT command in 4.7.2).
#
# 4.7.8.1   Returns: OK{EOL}
# The module has accepted the request and initiated the connection process to AWS IoT Core. Note that
# the connection process can require a significantly long time.
def test_4_7_8_1_ConnectNonBlockingCommand() -> None:
    assert cmd('AT+CONNECT!\r\n') == 'OK\r\n'


_connect_event_regex = re.compile(r'^OK (\d+) (\d+) CONNECT\r\n$')


def _get_connect_event_hint() -> int:
    event = get_next_event_match(_connect_event_regex)
    if event is None:
        pytest.fail('Did not receive a CONNECT event')
    else:
        groups = event.groups()
        event_code, hint_code = int(groups[0]), int(groups[1])
        # Table 4: CONNECT event is code 6
        assert event_code == 6
        return hint_code


# 4.7.8.2   A CONNECT event (see Table 4) is generated when the process is completed or terminated
# with error. A hint code is provided as the event parameter (with the same interpretation
# provided in 4.7.2.2 for the CONNECT ERR14 response). In case of success, the hint-code
# will be 0.
def test_4_7_8_2_ConnectNonBlockingEvent() -> None:
    assert cmd(
        f'AT+CONF Endpoint={cf.get("personal_endpoint", str)}\r\n') == 'OK\r\n'

    def async_connect_with_retries() -> bool:
        assert cmd('AT+CONNECT!\r\n') == 'OK\r\n'
        # Commands may be processed during CONNECT!
        assert cmd('AT\r\n') == 'OK\r\n'
        assert cmd('AT+CONF? Topic1\r\n') == 'OK \r\n'
        hint_code: int = _get_connect_event_hint()
        if hint_code != 0:
            print(f'Failed to connect with hint code {hint_code}')
        return hint_code == 0

    try:
        assert poll(async_connect_with_retries, timeout=30, step=0.01)
    except TimeoutException:
        pytest.fail('Failed to connect with retries')


def test_4_7_8_2_ConnectNonBlockingHintCode() -> None:
    bad_endpoint: str = 'notavalidendpoint.orvaliddomain'
    assert cmd(f'AT+CONF Endpoint={bad_endpoint}\r\n') == 'OK\r\n'
    assert cmd('AT+CONNECT!\r\n') == 'OK\r\n'
    hint_code = _get_connect_event_hint()
    if hint_code == 0:
        pytest.fail('Connect succeeded with invalid endpoint')


# 4.7.8.3   If the ExpressLink module is already connected, issuing a CONNECT! command will produce
# immediately a CONNECT event with a successful hint code (0).
def test_4_7_8_3_ConnectNonBlockingAlreadyConnected() -> None:
    endpoint = cf.test_config["personal_endpoint"].get(str)
    assert endpoint
    assert cmd(f'AT+CONF Endpoint={endpoint}\r\n') == 'OK\r\n'

    def get_time_to_connect() -> float:
        start: float = time.perf_counter()
        assert cmd('AT+CONNECT!\r\n') == 'OK\r\n'
        assert _get_connect_event_hint() == 0
        duration_seconds: float = time.perf_counter() - start
        print(f'Connect succeeded in {duration_seconds} seconds', end='\n\n')
        return duration_seconds

    # get baseline connect time
    connect_time: float = get_time_to_connect()
    # subsequent connect attempts should succeed faster than the first (already connected)
    for i in range(4):
        assert get_time_to_connect() <= connect_time


# 4.7.8.4   In case of connection failure, the ExpressLink module will keep a timestamp of the event.
# This will be used to ensure that a subsequent (repeated) connection request will comply
# with the correct backoff timing limits. Should the request from the host be repeated too
# close to the previous attempt (shorter interval than prescribed minimum backoff time) the
# ExpressLink module will return with a CONNECT event with the Backoff hint code. Delays
# will increase according to the backoff algorithm until a successful connection is
# established.
def test_4_7_8_4_ConnectNonBlockingBackOff() -> None:
    bad_endpoint: str = 'notavalidendpoint.orvaliddomain'
    assert cmd(f'AT+CONF Endpoint={bad_endpoint}\r\n') == 'OK\r\n'

    for i in range(20):
        assert cmd('AT+CONNECT!\r\n') == 'OK\r\n'
        hint_code = _get_connect_event_hint()
        assert hint_code != 0
        if hint_code == 1:
            print(f'Successfully backed off on attempt {i}')
            break
    else:
        pytest.fail(
            'Did not issue a hint code 1 for imposed backoff when failing to connect'
        )


# 4.7.8.5   Returns: ERR25 NOT ALLOWED{EOL}
# If the device is in CONFMODE or a CONNECT! command is already in progress
@pytest.mark.skipif(not cf.get('feature_confmode', bool),
                    reason='confmode testing disabled')
def test_4_7_8_5_ConnectNonBlockingFailConfmode() -> None:
    assert cmd('AT+CONFMODE\r\n') == 'OK CONFMODE ENABLED\r\n'
    assert cmd('AT+CONNECT!\r\n') == 'ERR25 NOT ALLOWED\r\n'
