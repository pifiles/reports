# Copyright of Amazon Web Services, Inc. (AWS) 2023
#
# This code is licensed under the AWS Intellectual Property License, which can
# be found here: https://aws.amazon.com/legal/aws-ip-license-terms/; provided
# that AWS grants you a limited, royalty-free, revocable, non-exclusive,
# non-sublicensable, non-transferrable license to modify the code for internal
# testing purposes. Your receipt of this code is subject to any non-disclosure
# (or similar) agreement between you and AWS.
import itertools
import time
from typing import Iterator, Literal, TypedDict

import yaml
from commands import *
from utils import _hex_to_mac, _hex_to_uuid
import config_handler as cf
import re
import pytest
import json
import struct

from bleak import BleakClient, BleakScanner

# 13 Bluetooth Low Energy (BLE)
# ExpressLink modules can take advantage of additional (local) connectivity capabilities,
# optionally available on selected SoCs. Bluetooth Low Energy (BLE), is one prominent
# example of such capabilities used to communicate with accessories and other modules
# or gateways over a local (personal) area network. BLE interfaces can be configured by
# means of profiles, describing a collection of attributes used to transfer individual
# pieces of information between two devices. Devices can assume one of two roles: 1/ Central
# – BLE device which initiates an outgoing connection request to an advertising
#   peripheral device and 2/ Peripheral
# - the BLE device which accepts an incoming connection request after advertising its
# presence and capabilities.A host processor can access BLE features of a capable ExpressLink
# module through the set of commands described in this chapter. Additionally, a new set of
# events has been made available to support asynchronous communication with the host (see BLE
# specific extensions to Table 4) and new configuration parameters have been added to the ExpressLink
# configuration dictionary (see Table 3).
# In particular, BLE devices adopting a central role require the host to initialize one or more
# BLECentral# parameters in order to describe the (peripheral) devices they wish to connect to.
# The numerical suffix # is an integer between 1 and MaxBLECentral - a value dependent on the
# module capabilities. (Manufacturers of ExpressLink modules are required to publish the MaxBLECentral
# value in the module datasheet).
# BLECentral configuration parameters use JSON notation and expect the following keys:
#     • peer (mac string) – mac address of a target peripheral device (i.e., "a4:c1:38:12:56:5d").
#     • filterDups (1/0) – filters duplicate broadcast by the same device.
#     • customFilters (JSON object) – additional vendor-defined filtering options (must be
#       documented by the vendor on the module datasheet).
# BLE devices adopting a peripheral role require the host to initialize the BLEPeripheral (single)
# configuration parameter in order to describe the devices connection requirements.
# BLEPeripheral configuration parameters use JSON notation and expect the following keys:
#     • appearance (string) – 4 digit hex to represent the type of device. (See Bluetooth Specification pg 28).
#     • customConfig (JSON object) - additional vendor-defined customization options
#       (must be documented by the vendor on the module datasheet).
# Both Central and Peripheral devices require the host to initialize one or more BLEGATT# parameter in order
# to describe individual characteristics they wish to publish/access. The numerical suffix # is an integer between
# 1 and MaxBLEGATT - a value dependent on the module capabilities. (Manufacturers of ExpressLink modules
# are required to publish the MaxBLEGATT value in the module datasheet).
# BLEGATT# configuration parameters use JSON notation and expect the following keys:
#     • service (UUID string) – the UUID of a BLE service.
#     • chr (UUID string) – the UUID of a BLE characteristic.
#     • write (1/0) – optional
#     • read (1/0) – optional
#     • indicate (1/0) – optional
#     • notify (1/0) – optional
# UUID strings can be in short form 4 hex-digits (i.e., “20AD”) for short 16-bit service and characteristics,
# or long form 128-bit for custom service and characteristics identifiers (i.e., “00000000-0000-1000-8000-00805F9B34FB”).
# Long form UUIDs separators (“-“) can be omitted. The default value for optional keys is 0.
# Furthermore, the maximum value that can be read/write/store is 31 bytes.
# Example 1: Two service composed of one characteristic each
# AT+CONF BLEGATT1={“service”: "1809", “char”: "2A1C" }
#        	Thermometer service, Temperature characteristic.
# AT+CONF BLEGATT2={“service”: "180F", “char”: "2A19" }
#  	Battery Level service and level(%) characteristic.

# Since BLEGATT# configuration parameters describe only one characteristic each, multiple parameters are
# required to describe a complex service composed of a number of characteristics.
# Example 2: A service composed of two characteristics.
# AT+CONF BLEGATT1={“service”: "180D", “char”: "2A37" }
# 	Heart rate service, heart rate measurement characteristic.
# AT+CONF BLEGATT2={“service”: "180D", “char”: "2A38" }
# 	Heart rate service, body sensor location characteristic.

GapConfig = TypedDict('GapConfig', {
    'peer': str,
    'filterDups': Literal[0, 1]
},
                      total=False)

PeripheralConfig = TypedDict('PeripheralConfig', {'appearance': str})

GattConfig = TypedDict('GattConfig', {
    'service': str,
    'chr': str,
    'read': Literal[0, 1],
    'write': Literal[0, 1],
    'notify': Literal[0, 1],
    'indicate': Literal[0, 1],
},
                       total=False)

DiscoveryResponse = TypedDict('DiscoveryResponse', {
    'peer': str,
    'connectable': Literal[0, 1],
    'scannable': Literal[0, 1],
    'rssi': int,
    'advertisedData': str
},
                              total=False)


def _get_gap_config() -> GapConfig:
    return GapConfig(peer=_hex_to_mac(cf.get('known_peer_address', int)))


LOCAL_SERVICE_ID = _hex_to_uuid(0x32ef0001_0fdf_4589_89ca_ed89ecf678d7)
LOCAL_CHAR_ID = _hex_to_uuid(0x32ef0002_0fdf_4589_89ca_ed89ecf678d7)


# 13.1.1 BLE INIT [CENTRAL | PERIPHERAL] 	     Initializing the device role
# Initialize the BLE interface to operate in the selected (GAP) role. Note how the this version of the ExpressLink
# specification allows a device to be configured as Central or Peripheral but not both. Once a BLE interface is
# initialized, the only way to terminate/change mode of operation is to use the RESET command. However, doing
# so will disconnect the device (if connected) and will reset all internal state. Non-persistent configuration
# parameters (see Table 3) will be reinitialized, all subscriptions will be terminated, and the message queues
# will also be emptied.
# For Central Mode:
# Issuing the INIT CENTRAL command does not require (yet) any of the BLE configurations parameters to be set.
# One or more BLECentral# and BLEGATT # configuration parameters will be required later, before issuing an actual
# connection request (see BLE CONNECT command). BLECentral# and BLEGATT# parameters are used in central mode to
# act as filters to identify suitable connection target devices.
# For Peripheral Mode
# Issuing the INIT PERIPHERAL command requires the BLEPeripheral and one (or more) BLEGATT# configuration
# parameters to be set. BLEGATT keys do not need to be set in numerical order. All BLE parameters found
# (initialized) in the configuration dictionary will be used to define the peripheral’s GATT service.
# After initialization, the host may not change the BLEGATT# service composition (characteristics) without first
# resetting the device. The host can instead update or retrieve the latest characteristic values using the
# appropriate SET/GET commands (see BLE SET and BLE GET commands).
#
# 13.1.1.1 Returns: OK{EOL}
# If the command was accepted and the central/peripheral role requested is set.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_1_1_1_bleInitCentral() -> None:
    """Intializes BLE for central flow"""
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'\


@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_1_1_1_bleInitPeripheral() -> None:
    """Intializes BLE for peripheral flow"""
    config = GattConfig(chr=LOCAL_CHAR_ID,
                        service=LOCAL_SERVICE_ID,
                        indicate=1,
                        write=1,
                        read=1,
                        notify=1)
    apperance = PeripheralConfig(appearance="0340")
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd(
        f'AT+CONF BLEPeripheral={json.dumps(apperance)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'


# 13.1.1.2 Returns: ERR4 PARAMETER ERROR{EOL}
# If the role parameter was not CENTRAL or PERIPHERAL.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_1_1_2_bleInitBadParam() -> None:
    badCommands = [
        'BLE INIT',
        'BLE INIT ',
        'BLE INIT FOO',
        'BLE INIT CENTRAL1',
        'BLE INIT PERIPHERAL1',
        'BLE1 INIT CENTRAL',
        'BLE1 INIT PERIPHERAL',
    ]
    assert (all(
        cmd(f'AT+{badCommand}\r\n') == 'ERR4 PARAMETER ERROR\r\n'
        for badCommand in badCommands))


# 13.1.1.3 Returns: ERR28 CONFIGURATION ERROR{EOL}
# If the peripheral role was selected and the configuration dictionary does not contain the
# BLEPeripheral and at least one BLEGATT# parameter.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_1_1_3_bleInitMissingConfig() -> None:
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'ERR28 CONFIGURATION ERROR\r\n'


# 13.1.1.4 Returns: ERR25 NOT ALLOWED{EOL}
# If the BLE role was already initialized.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_1_1_4_bleInitAlreadyCentral() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'ERR25 NOT ALLOWED\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'ERR25 NOT ALLOWED\r\n'


@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_1_1_4_bleInitAlreadyPeripheral() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'ERR25 NOT ALLOWED\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'ERR25 NOT ALLOWED\r\n'


# 13.1.1.5 Returns: ERR27 BLE ERROR{EOL}
# Failed to initialize the BLE Stack.
# Not tested
#
# 13.1.1.6 filterDups is 0 by default
# Not tested


# 13.2 BLE CENTRAL Role Commands
#
# 13.2.1 BLE# DISCOVER {duration}|CANCEL 	     [CENTRAL] Scanning and Advertisement
# BLE capable devices can communicate with accessories without establishing permanent connections
# by means of a scanning and advertising protocol. This protocol is commonly used for characteristics
# whose value is required infrequently (i.e., device battery level, or ambient temperature sensors).
#
# The ExpressLink module scans for advertisements from peripherals that match criteria defined in the
# corresponding configuration string BLECentral#. This is an asynchronous command. It returns an immediate
# response to confirm the process has started (or an error prevented it). During the scanning time, any
# advertised data received will be queued. The scanning process will stop after a set amount of time
# (30 s defatult), optionally configured by the duration parameter, and a BLE DISCOVER COMPLETE event
# (see Table 4) will be produced. Queued data can then be retrieved used the BLE GET DISCOVERY command (see 13.2.10.2).
# The CANCEL parameter is used to terminate an ongoing scanning process.
# 13.2.1.1 Scans for all the nearby devices if BLECentral# is set to {} (JSON empty object).
# Not testable without multiple controlled BLE peripheral devices in the test environment.
#
# 13.2.1.2 If the command is issued while a scanning process is in progress
# any queued data is discarded and a new scanning process is started.
@pytest.mark.slow
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_1_2_bleDiscoverClearScan() -> None:
    # filter to a single device, discard duplicates
    config = _get_gap_config()
    assert cmd(f'AT+CONF BLECentral1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'

    # Start multiple discovers, but don't allow previous discovers to finish
    for _ in range(100):
        assert cmd('AT+BLE1 DISCOVER\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 DISCOVER 1\r\n')

    # Only one discover operation should complete
    print("Waiting for DISCOVER COMPLETE event")
    assert get_next_event(r'^OK \d+ \d+ BLE DISCOVER COMPLETE\r\n',
                          print_dots=False,
                          timeout=10)
    print("Waiting for DISCOVER COMPLETE event")
    assert get_next_event(r'^OK \d+ \d+ BLE DISCOVER COMPLETE\r\n',
                          print_dots=False,
                          timeout=10) is None


# 13.2.1.3 If {duration} is provided, only devices found within {duration} seconds will be captured.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_1_3_bleDiscoverDuration() -> None:
    # Filter to a single address and filter duplicates to ensure
    # backing memory for GET DISCOVER messages does not overrun.
    config = _get_gap_config()
    config['filterDups'] = 1
    assert cmd(f'AT+CONF BLECentral1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    expectedDuration = 5
    assert cmd(f'AT+BLE1 DISCOVER {expectedDuration}\r\n') == 'OK\r\n'
    t1 = time.time()
    print('Waiting for DISCOVER COMPLETE event')
    assert get_next_event(r'^OK \d+ \d+ BLE DISCOVER COMPLETE\r\n',
                          print_dots=False,
                          timeout=expectedDuration * 3)
    t2 = time.time()
    assert (t2 - t1) == pytest.approx(
        expected=expectedDuration,
        abs=2), 'Discover request took longer/shorter than expected'


# 13.2.1.4 Enqueues event BLE DISCOVER COMPLETE event on successful Discover complete or cancellation (see Table 4).
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_1_4_bleDiscoverCompleteEvent() -> None:
    assert cmd('AT+CONF BLECentral1={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 DISCOVER 3\r\n') == 'OK\r\n'
    print('Waiting for discover complete event')
    assert get_next_event('OK 41 0 BLE DISCOVER COMPLETE\r\n',
                          print_dots=False,
                          timeout=6)


# 13.2.1.5 Enqueues event BLE DISCOVER ERROR when the discovery fails for any reason.
# Hint-Codes can be defined by the vendor to provide additional insight on the reason for the failure.
# (Hint Codes must be documented in the module datasheet).
# Not tested
#
# 13.2.1.6	Discover process will stop if message queue gets full
# Not tested
#
# 13.2.1.7 Returns: OK{EOL}
# If the command was accepted and the scanning sequence started.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_1_7_bleDiscoverOk() -> None:
    assert cmd('AT+CONF BLECentral1={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 DISCOVER\r\n') == 'OK\r\n'


# 13.2.1.8 Returns: OK{EOL}
# IF CANCEL parameter is given and the cancellation request was successfully submitted.
# Cancel will terminate any scanning activity in progress regardless of the # index given.
# However, a suffix index is required for the command to execute.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_1_8_bleDiscoverCancel() -> None:
    assert cmd('AT+CONF BLECentral1={}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLECentral2={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 DISCOVER\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 DISCOVER CANCEL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 DISCOVER\r\n') == 'OK\r\n'
    assert cmd('AT+BLE2 DISCOVER CANCEL\r\n') == 'OK\r\n'


# 13.2.1.9 Returns: ERR4 PARAMETER ERROR{EOL}
# If parameter is 0 seconds.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_1_9_bleDiscoverRequiresDuration() -> None:
    assert cmd('AT+CONF BLECentral1={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 DISCOVER \r\n') == 'ERR4 PARAMETER ERROR\r\n'
    assert cmd('AT+BLE1 DISCOVER 0\r\n') == 'ERR4 PARAMETER ERROR\r\n'


# 13.2.1.10 Returns: ERR4 PARAMETER ERROR{EOL}
# If the numerical suffix # is omitted.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_1_10_bleDiscoverRequiresConnectionIndex() -> None:
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE DISCOVER\r\n') == 'ERR4 PARAMETER ERROR\r\n'


# 13.2.1.11 Returns: ERR7 OUT OF RANGE{EOL}
# If the numerical suffix # is out of bounds (0 or greater than MaxBLECentral).
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_1_11_bleDiscoverOutOfRange() -> None:
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE0 DISCOVER\r\n') == 'ERR7 OUT OF RANGE\r\n'
    assert cmd('AT+BLE512 DISCOVER\r\n') == 'ERR7 OUT OF RANGE\r\n'


# 13.2.1.12 Returns: ERR8 PARAMETER UNDEFINED{EOL}
# If the numerical suffix # points to an empty BLECentral# string.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_1_12_bleDiscoverRequiresConfig() -> None:
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 DISCOVER\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'
    assert cmd('AT+BLE1 DISCOVER 1\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 13.2.1.13 Returns: ERR25 NOT ALLOWED{EOL}
# if the Central role was not initialized.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_1_13_bleDiscoverNotCentral() -> None:
    assert cmd('AT+CONF BLECentral1={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 DISCOVER\r\n') == 'ERR25 NOT ALLOWED\r\n'
    assert cmd('AT+BLE1 DISCOVER 30\r\n') == 'ERR25 NOT ALLOWED\r\n'
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 DISCOVER\r\n') == 'ERR25 NOT ALLOWED\r\n'
    assert cmd('AT+BLE1 DISCOVER 30\r\n') == 'ERR25 NOT ALLOWED\r\n'


# 13.2.2 BLE GET DISCOVER   	[CENTRAL] Retrieve the collected advertising information
# Retrieve the advertising information collected during the last discovery process.
# Advertising information is stored in memory shared with MQTT messages.
# Collected information is also cleared when a new discovery is started.
# Hence, GET DISCOVER only fetches information for the devices that match
# the filter defined when the last DISCOVER command was issued.


# Collected Information is fetched from the queue and returned as a record containing the following space-separated fields:
# OK <peer> <connectable> <scannable> <rssi> <advertisedData>{EOL}
#    mac    0/1           0/1         int    hex string
def _retrieve_discovery() -> Iterator[DiscoveryResponse]:
    while True:
        response = cmd('AT+BLE GET DISCOVER\r\n')
        if response == 'OK\r\n':
            return
        match = re.match(
            r'^OK ([a-zA-Z0-9\:]{12,17}) ([01]) ([01]) (-?\d+) ([a-zA-Z0-9]*)\r\n$',
            response)
        assert match
        addr, connectable, scannable, rssi, advertisedData = match.groups()
        yield DiscoveryResponse(
            peer=str(addr),
            rssi=int(rssi),
            # allowed values are validated by regex pattern
            connectable=int(connectable),  # type: ignore
            scannable=int(scannable),  # type: ignore
            advertisedData=advertisedData)


def _validate_discovery(response: DiscoveryResponse) -> None:
    assert response.get('peer') is not None

    assert response.get('rssi') is not None

    connectable = response.get('connectable')
    assert connectable == 0 or connectable == 1

    scannable = response.get('scannable')
    assert scannable == 0 or scannable == 1

    assert response.get('advertisedData') is not None
    assert len(response['advertisedData']) % 2 == 0


# 13.2.2.1 Returns: OK{EOL}
# No new advertising information was collected.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_2_1_bleGetDiscoverEmpty() -> None:
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE GET DISCOVER\r\n') == 'OK\r\n'


# 13.2.2.2 Returns: OK{space}{collected information}{EOL}
# Discovered information was collected and is presented in a multi-line format
# the # suffix indicates the number of additional lines to follow containing all collected data
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_2_2_bleDiscoverResponse() -> None:
    config = _get_gap_config()
    config['filterDups'] = 1
    # filter to a single device, discard duplicates
    assert cmd(f'AT+CONF BLECentral1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 DISCOVER 5\r\n') == 'OK\r\n'
    assert get_next_event(r'OK \d+ \d+ BLE DISCOVER COMPLETE\r\n',
                          print_dots=False,
                          timeout=10)
    for response in _retrieve_discovery():
        _validate_discovery(response)


# 13.2.2.3 Returns: ERR25 NOT ALLOWED{EOL}
# BLE Central role was not Initialized
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_2_3_bleGetDiscoverNotCentral() -> None:
    assert cmd('AT+BLE GET DISCOVER\r\n') == 'ERR25 NOT ALLOWED\r\n'
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE GET DISCOVER\r\n') == 'ERR25 NOT ALLOWED\r\n'


# 13.2.3 BLE# CONNECT				  [CENTRAL] Connect to a peripheral
# In some use cases, instead of just reading sensor data provided in the advertisement message, the host may want
# to inspect what type of services and characteristics a peripheral expose. To do this the ExpressLink module needs
# to establish first a direct connection to the BLE peripheral device (using the BLE GAP protocol).

# Using the BLE{#} CONNECT command, the ExpressLink module attempts to connect to a peripheral based on a specific
# configuration defined in the BLECentral# parameter.


def _ble_connect_with_retries() -> Optional[str]:

    def returnsOk(response: str) -> bool:
        return response == 'OK\r\n'

    try:
        return poll(cmd,
                    args=('AT+BLE1 CONNECT\r\n', True, 60),
                    step=0,
                    check_success=returnsOk,
                    timeout=120)
    except TimeoutException:
        return None


# 13.2.3.1 Returns: OK{EOL}
# if the command was accepted and the connection request was successful
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_3_1_bleConnect() -> None:
    config: GapConfig = _get_gap_config()
    assert cmd(f'AT+CONF BLECentral1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert _ble_connect_with_retries() == 'OK\r\n'


# 13.2.3.2 Returns: ERR7 OUT OF RANGE{EOL}
# The numerical suffix is out of bounds (0 or greater than MaxBLECentral index).
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_2_bleConnectOutOfRange() -> None:
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE0 CONNECT\r\n') == 'ERR7 OUT OF RANGE\r\n'
    assert cmd('AT+BLE255 CONNECT\r\n') == 'ERR7 OUT OF RANGE\r\n'


# 13.2.3.3 Returns: ERR28 CONFIGURATION ERROR{EOL}
# The numerical suffix points to a {}, or is missing a “peer” key.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_3_3_bleConnectNotDescribed() -> None:
    assert cmd('AT+CONF BLECentral1={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 CONNECT\r\n',
               timeout=60) == 'ERR28 CONFIGURATION ERROR\r\n'
    config = GapConfig(filterDups=1)
    assert cmd(f'AT+CONF BLECentral1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 CONNECT\r\n',
               timeout=60) == 'ERR28 CONFIGURATION ERROR\r\n'


# 13.2.3.4 Returns: ERR8 PARAMETER UNDEFINED{EOL}
# The numerical suffix points to an empty BLECentral# string
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_3_4_bleConnectNotConfigured() -> None:
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 CONNECT\r\n',
               timeout=60) == 'ERR8 PARAMETER UNDEFINED\r\n'


# 13.2.3.5 Returns: ERR25 NOT ALLOWED{EOL}
# if already connected to a device.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_3_5_bleConnectAlready() -> None:
    config = _get_gap_config()
    assert cmd(f'AT+CONF BLECentral1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert cmd('AT+BLE1 CONNECT\r\n', timeout=60) == 'ERR25 NOT ALLOWED\r\n'


# 13.2.3.6 Returns: ERR25 NOT ALLOWED{EOL}
# if BLE INIT is not set to CENTRAL mode.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_3_6_bleConnectNotCentral() -> None:
    gapConfig = _get_gap_config()
    assert cmd(f'AT+CONF BLECentral1={json.dumps(gapConfig)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 CONNECT\r\n', timeout=60) == 'ERR25 NOT ALLOWED\r\n'
    gattConfig = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(gattConfig)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 CONNECT\r\n', timeout=60) == 'ERR25 NOT ALLOWED\r\n'


# 13.2.3.7 Returns: ERR14 UNABLE TO CONNECT{EOL}
# Will discover for 30 sec before timing out and returning error.
@pytest.mark.slow
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_3_7_bleConnectTimeout() -> None:
    config = GapConfig(peer=_hex_to_mac(0x00_11_22_33_DC_BA))
    assert cmd(f'AT+CONF BLECentral1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    t1 = time.time()
    assert cmd('AT+BLE1 CONNECT\r\n',
               timeout=60) == 'ERR14 UNABLE TO CONNECT\r\n'
    t2 = time.time()
    assert (t2 - t1) == pytest.approx(30, abs=5)


# 13.2.4 BLE# CONNECT?				[CENTRAL] Connection status query
# This query command allows the host device to check if the status of the given connection is still active.
# This command can also work as confirmation of successful connection after the AT+CONNECT command.
#
# 13.2.4.1 Returns: ERR4 PARAMETER ERROR{EOL}
# When missing a numerical suffix # index.


# 13.2.4.2 Returns: OK 1 CONNECTED{EOL}
# When connected to a Peripheral
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_4_2_centralConnectQueryConnected() -> None:
    assert cmd(
        f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert cmd('AT+BLE1 CONNECT?\r\n') == 'OK 1 CONNECTED\r\n'


# 13.2.4.3 Returns: OK 0 DISCONNECTED{EOL}
# When disconnected from a Peripheral
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_4_3_centralConnectQueryDisconnected() -> None:
    assert cmd('AT+CONF BLECentral1={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 CONNECT?\r\n') == 'OK 0 DISCONNECTED\r\n'


# 13.2.4.4 Returns: ERR7 OUT OF RANGE{EOL}
# The numerical suffix is out of bounds (0 or greater than MaxBLECentral index).
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_4_4_centralConnectQueryBadIndex() -> None:
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE0 CONNECT?\r\n') == 'ERR7 OUT OF RANGE\r\n'
    assert cmd('AT+BLE512 CONNECT?\r\n') == 'ERR7 OUT OF RANGE\r\n'


# 13.2.4.5 Returns: ERR25 NOT ALLOWED{EOL}
# When the module role was not initialized as Central
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_4_5_connectQueryIndexAsPeripheral() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 CONNECT?\r\n') == 'ERR25 NOT ALLOWED\r\n'


# 13.2.5 BLE# DISCONNECT		[CENTRAL] Connection termination request
# Terminate a BLE device connection.
#
# 13.2.5.1 Disconnects from the given index’s connection.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_5_1_centralDisconnectDisconnects() -> None:
    assert cmd(
        f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert cmd('AT+BLE1 DISCONNECT\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 CONNECT?\r\n') == 'OK 0 DISCONNECTED\r\n'


# 13.2.5.2 Returns: OK{EOL}
# On successful termination of connection or if there is no connection to terminate.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_5_2_centralDisconnectOk() -> None:
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 DISCONNECT\r\n') == 'OK\r\n'


# 13.2.5.3 Returns: ERR7 OUT OF RANGE{EOL}
# The numerical suffix is out of bounds (0 or greater than MaxBLECentral index).
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_5_3_centralDisconnectBadIndex() -> None:
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE0 DISCONNECT\r\n') == 'ERR7 OUT OF RANGE\r\n'
    assert cmd('AT+BLE512 DISCONNECT\r\n') == 'ERR7 OUT OF RANGE\r\n'


# 13.2.5.4 Returns: ERR27 BLE ERROR{EOL}
# If command fails to terminate the connection.
# Not tested
#
# 13.2.5.5 Returns: ERR25 NOT ALLOWED{EOL}
# If BLE INIT is not set to CENTRAL mode
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_5_5_centralDisconnectNotCentral() -> None:
    assert cmd(
        f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 DISCONNECT\r\n') == 'ERR25 NOT ALLOWED\r\n'


# 13.2.6 BLE# READ#		   	[CENTRAL] Synchronous Read of a Characteristic
# The READ command allows the host to request the value of a characteristic when connected to a peripheral.
# The BLE (first) numerical suffix # identifies the connected device by the corresponding BLECentral#
# parameter. The READ (second) numerical suffix #, identifies the characteristics by the corresponding
# BLEGATT# parameter. The maximum value that can be read from a characteristic is 31 bytes
#
# 13.2.6.1 Returns: OK{space}{value}{EOL}
# On successful read, returns the characteristic value as a hex string.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_6_1_bleReadHexPayload() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_read_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_read_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    match = re.match(r'^OK ([a-zA-Z0-9]{0,1024})\r\n$',
                     cmd('AT+BLE1 READ1\r\n'))
    assert match
    payload, = match.groups()
    assert len(payload) % 2 == 0
    output = struct.unpack('<f', bytes.fromhex(payload))[0]
    assert output == 1.0


# 13.2.6.2 Returns: OK{space}{EOL}
# On successful read, when the characteristic value is an empty string.
# Not tested
#
# 13.2.6.3 Returns: ERR8 PARAMETER UNDEFINED{EOL}
# When a BLECentral# configuration is not set.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_6_3_bleReadCentralUndefined() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    gattConfig = GattConfig(service=LOCAL_SERVICE_ID, chr=LOCAL_CHAR_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(gattConfig)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert cmd('AT+BLE2 READ1\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 13.2.6.4 Returns: ERR8 PARAMETER UNDEFINED{EOL}
# When a BLEGATT# configuration is not set.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_6_3_bleReadGattUndefined() -> None:
    assert cmd(
        f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert cmd('AT+BLE1 READ1\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 13.2.6.5 Returns: ERR7 OUT OF RANGE{EOL}
# When the first numerical suffix is out of bounds (0 or greater than MaxBLECentral).
#
# 13.2.6.6 Returns: ERR7 OUT OF RANGE{EOL}
# When the second numerical suffix is out of bounds (0 or greater than MaxBLEGATT).
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_6_6_bleReadOutOfRange() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_read_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_read_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert all([
        cmd(f'AT+BLE{central} READ{gatt}\r\n') == 'ERR7 OUT OF RANGE\r\n'
        for (gatt, central) in itertools.product([1, 0, 512], repeat=2)
        if (gatt != 1) or (central != 1)
    ])


# 13.2.6.7 Returns: ERR6 NO CONNECTION{EOL}
# When not connected to a peripheral device.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_6_7_bleReadNoConnection() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_read_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_read_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 READ1\r\n') == 'ERR6 NO CONNECTION\r\n'


# 13.2.6.8 Returns: ERR27 BLE ERROR{EOL}
# When the read request fails.
# Not tested
#
# 13.2.6.9 Returns: ERR25 NOT ALLOWED{EOL}
# If BLE INIT is not set to CENTRAL mode
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_6_9_bleReadNotCentral() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_read_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_read_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'

    assert cmd('AT+BLE1 READ1\r\n') == 'ERR25 NOT ALLOWED\r\n'

    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 READ1\r\n') == 'ERR25 NOT ALLOWED\r\n'


# 13.2.7 BLE# WRITE# <value>			 [CENTRAL] Write to a characteristic
# The WRITE command allows the host to update the value of (writable) characteristics
# of a connected peripheral device. The BLE (first) numerical suffix #
# identifies the connected device by the corresponding BLECentral# parameter.
# The WRITE (second) numerical suffix #, identifies the characteristics
# by the corresponding BLEGATT# parameter. The maximum supported value for write operations is 31 bytes.
#
# 13.2.7.1 Returns: OK{EOL}
# On successful update of the peripheral characteristic.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_7_1_bleWrite() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_write_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_write_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n')
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert cmd('AT+BLE1 WRITE1 ABCDEF01\r\n') == 'OK\r\n'


# 13.2.7.2 Returns: ERR4 PARAMETER ERROR{EOL}
# Must always take valid byte array encoded in hex as a valid parameter
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_7_2_bleWriteNotHex() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_write_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_write_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n')
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert cmd('AT+BLE1 WRITE1\r\n') == 'ERR4 PARAMETER ERROR\r\n'
    assert cmd('AT+BLE1 WRITE1 foo\r\n') == 'ERR4 PARAMETER ERROR\r\n'
    assert cmd('AT+BLE1 WRITE1 foobar\r\n') == 'ERR4 PARAMETER ERROR\r\n'
    assert cmd('AT+BLE1 WRITE1 ABC\r\n') == 'ERR4 PARAMETER ERROR\r\n'


# 13.2.7.3 Returns: ERR8 PARAMETER UNDEFINED{EOL}
# A BLEGATT# configuration was not set.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_7_3_bleWriteCentralConfigUndefined() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_write_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_write_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n')
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert cmd('AT+BLE2 WRITE1 ABDCEF01\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 13.2.7.4 Returns: ERR7 OUT OF RANGE{EOL}
# The BLE Central numerical suffix is out of bounds (0 or greater than MaxBLECentral).
# 13.2.7.5 Returns: ERR7 OUT OF RANGE{EOL}
# The BLEGATT numerical suffix is out of bounds (0 or greater than MaxBLEGATT).
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_7_bleWriteOutOfRange() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_write_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_write_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert all([
        cmd(f'AT+BLE{central} WRITE{gatt} ABCDEF01\r\n') ==
        'ERR7 OUT OF RANGE\r\n'
        for (gatt, central) in itertools.product([1, 0, 512], repeat=2)
        if (gatt != 1) or (central != 1)
    ])


# 13.2.7.6 Returns: ERR6 NO CONNECTION{EOL}
# When not connected to a peripheral device.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_7_6_bleWriteGattNoConnection() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_write_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_write_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 WRITE1 ABCEDF01\r\n') == 'ERR6 NO CONNECTION\r\n'


# 13.2.7.7 Returns: ERR25 NOT ALLOWED{EOL}
# The device was not initialized as a Central.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_7_7_bleWriteGattNotCentral() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_write_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_write_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 WRITE1 ABCEDF01\r\n') == 'ERR25 NOT ALLOWED\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 WRITE1 ABCEDF01\r\n') == 'ERR25 NOT ALLOWED\r\n'


# 13.2.7.8 Returns: ERR27 BLE ERROR{EOL}
# When it failed to update the characteristic.
# Not tested

# 13.2.8 BLE# SUBSCRIBE#		[Central] Subscribe to a connected peripheral
# The host can subscribe to receive notifications (see events Table 4) when connected to a peripheral
# and the selected characteristic is updated (must be configured as notify or indicate). The BLE
# (first) numerical suffix # identifies the connected device by the corresponding BLECentral# parameter.
# The SUBSCRIBE (second) numerical suffix #, identifies the characteristics by the corresponding BLEGATT# parameter.


# 13.2.8.1 Returns: OK{EOL}
# On successful subscription.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_8_1_bleSubscribeOk() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_subscribe_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_subscribe_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert cmd('AT+BLE1 SUBSCRIBE1\r\n') == 'OK\r\n'


# 13.2.8.2 Returns: ERR8 PARAMETER UNDEFINED{EOL}
# A BLEGATT# configuration was not set.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_8_2_bleSubscribeParameterUndefined() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert cmd('AT+BLE1 SUBSCRIBE1\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 13.2.8.3 Returns: ERR7 OUT OF RANGE{EOL}
# The numerical suffix is out of bounds (0 or greater than MaxBLECentral).
# 13.2.8.4 Returns: ERR7 OUT OF RANGE{EOL}
# The numerical suffix is out of bounds (0 or greater than MaxBLEGatt).
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_8_bleSubscribeOutofRange() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_subscribe_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_subscribe_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert all([
        cmd(f'AT+BLE{central} SUBSCRIBE{gatt}\r\n') == 'ERR7 OUT OF RANGE\r\n'
        for (gatt, central) in itertools.product([1, 0, 512], repeat=2)
        if (gatt != 1) or (central != 1)
    ])


# 13.2.8.5 Returns: ERR6 NO CONNECTION{EOL}
# When not connected to a peripheral device
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_8_5_bleSubscribeNoConnection() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_subscribe_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_subscribe_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 SUBSCRIBE1\r\n') == 'ERR6 NO CONNECTION\r\n'


# 13.2.8.6 Returns: ERR25 NOT ALLOWED{EOL}
# The command can only be executed when initialized as a Central
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_8_6_bleSubscribeNotAllowed() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_subscribe_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_subscribe_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 SUBSCRIBE1\r\n') == 'ERR25 NOT ALLOWED\r\n'


# 13.2.8.7 Returns: ERR27 BLE ERROR{EOL}
# When command fails to successfully subscribe to the indexed characteristics.
# Not tested

# ExpressLink will support a limited number of subscriptions (minimum 2).
# The max number of supported subscriptions must be documented by the vendor in the module datasheet.


@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_bleSubscribeEvent() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_subscribe_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_subscribe_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert cmd('AT+BLE1 SUBSCRIBE1\r\n') == 'OK\r\n'
    print('Waiting for subscription event')
    match = get_next_event_match(r'^OK (\d+) (\d+) SUBSCRIPTION RECEIVED\r\n$',
                                 print_dots=False)
    assert match
    id, parameter = (int(group) for group in match.groups())
    assert id == 47 and parameter == 101


# 13.2.9 BLE# GET SUBSCRIBE[#]	                            [Central] Get information on Subscriptions
# After receiving the event on subscriptions, the host can retrieve additional detail about the notification.
# The first BLE numerical suffix # identifies the connected device by the corresponding BLECentral# parameter.
# The SUBSCRIBE (second) numerical suffix #, identifies the characteristics by the corresponding BLEGATT#
# parameter.  The second numerical index is optional, in which case the most recent subscription detail will
# be retrieved.
# 13.2.9.1 Returns: OK{EOL}
# No notification detail record was found.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_9_1_bleGetSubscribeOkEmpty() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_subscribe_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_subscribe_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert cmd('AT+BLE1 GET SUBSCRIBE1\r\n') == 'OK\r\n'


# 13.2.9.2 Returns: OK {BLEGATT#} [N/I] [detail]{EOL}
# A notification detail record was found.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_9_2_bleGetSubscribeWithPayloadIndexMissing() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_subscribe_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_subscribe_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert cmd('AT+BLE1 SUBSCRIBE1\r\n') == 'OK\r\n'

    get_next_event_match(r"^OK (\d+) (\d+) SUBSCRIPTION RECEIVED\r\n$")

    pattern = re.compile(r'^OK (\d+) [NI] ([a-fA-F0-9]*)\r\n$')
    match = pattern.match(cmd('AT+BLE1 GET SUBSCRIBE\r\n'))
    assert match
    index, payload = match.groups()
    assert int(index) == 1
    assert len(payload) % 2 == 0
    output = struct.unpack('<f', bytes.fromhex(payload))[0]
    assert output == 2.0


@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_9_2_bleGetSubscribeWithPayloadWithIndex() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_subscribe_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_subscribe_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert cmd('AT+BLE1 SUBSCRIBE1\r\n') == 'OK\r\n'

    get_next_event_match(r"^OK (\d+) (\d+) SUBSCRIPTION RECEIVED\r\n$")

    pattern = re.compile(r'^OK (\d+) [NI] ([A-Fa-f0-9]*)\r\n$')
    match = pattern.match(cmd('AT+BLE1 GET SUBSCRIBE1\r\n'))
    assert match
    index, payload = match.groups()
    assert int(index) == 1
    assert len(payload) % 2 == 0
    output = struct.unpack('<f', bytes.fromhex(payload))[0]
    assert output == 2.0


# 13.2.9.3 Returns: ERR7 OUT OF RANGE{EOL}
# The numerical suffix is out of bounds (0 or greater than MaxBLECentral).
# 13.2.9.4 Returns: ERR7 OUT OF RANGE{EOL}
# The numerical suffix is out of bounds (0 or greater than MaxBLEGatt).
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_9_bleGetSubscribeOutOfRange() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_subscribe_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_subscribe_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert all([
        cmd(f'AT+BLE{central} GET SUBSCRIBE{gatt}\r\n') ==
        'ERR7 OUT OF RANGE\r\n'
        for (gatt, central) in itertools.product([1, 0, 512], repeat=2)
        if (gatt != 1) or (central != 1)
    ])
    assert cmd('AT+BLE0 GET SUBSCRIBE\r\n') == 'ERR7 OUT OF RANGE\r\n'
    assert cmd('AT+BLE512 GET SUBSCRIBE\r\n') == 'ERR7 OUT OF RANGE\r\n'


# 13.2.9.5 Returns: ERR8 PARAMETER UNDEFINED{EOL}
# A BLECentral# configuration was not set.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_9_5_bleGetSubscribeMissingConfig() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_subscribe_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_subscribe_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert cmd('AT+BLE2 GET SUBSCRIBE1\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 13.2.9.6 Returns: ERR25 NOT ALLOWED{EOL}
# if the device is not Initialized in central role.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_9_6_bleUnsubscribeNotAllowed() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_subscribe_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_subscribe_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'

    assert cmd('AT+BLE1 GET SUBSCRIBE1\r\n') == 'ERR25 NOT ALLOWED\r\n'

    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 GET SUBSCRIBE1\r\n') == 'ERR25 NOT ALLOWED\r\n'


# 13.2.10 BLE# UNSUBSCRIBE# 			[Central]Unsubscribe to characteristics
# Terminate notify/indicate subscription to a peripheral device characteristic.
# 13.2.10.1 Returns: OK{EOL}
# On successful subscription termination to the peripheral characteristic.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_10_1_bleUnsubscribeOk() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_subscribe_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_subscribe_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 SUBSCRIBE1\r\n') == 'OK\r\n'
    """This operation may result in a disconnect when testing with a RuuviTag.
       This results in ERR27 BLE ERROR on ESP32 reference"""
    assert cmd('AT+BLE1 UNSUBSCRIBE1\r\n') == 'OK\r\n'


# 13.2.10.2 Returns: ERR8 PARAMETER UNDEFINED{EOL}
# A BLECentral# configuration was not set.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_10_2_bleUnsubscribeMissingCentralConfig() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert cmd('AT+BLE1 UNSUBSCRIBE1\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 13.2.10.3 Returns: ERR8 PARAMETER UNDEFINED{EOL}
# A BLEGATT# configuration was not set.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_10_3_bleUnsubscribeMissingGattConfig() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_subscribe_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_subscribe_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert cmd('AT+BLE2 UNSUBSCRIBE1\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 13.2.10.4 Returns: ERR7 OUT OF RANGE{EOL}
# The BLECentral numerical suffix is out of bounds (0 or greater than MaxBLECentral).
# 13.2.10.5 Returns: ERR7 OUT OF RANGE{EOL}
# The BLEGATT numerical suffix is out of bounds (0 or greater than MaxBLEGATT).
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_10_bleUnsubscribeOutOfRange() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_subscribe_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_subscribe_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    _ble_connect_with_retries()
    assert all([
        cmd(f'AT+BLE{central} UNSUBSCRIBE{gatt}\r\n') ==
        'ERR7 OUT OF RANGE\r\n'
        for (gatt, central) in itertools.product([1, 0, 512], repeat=2)
        if (gatt != 1) or (central != 1)
    ])


# 13.2.10.6 Returns: ERR6 NO CONNECTION{EOL}
# When not connected to a peripheral device.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_10_6_bleUnsubscribeNoConnection() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_subscribe_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_subscribe_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 UNSUBSCRIBE1\r\n') == 'ERR6 NO CONNECTION\r\n'


# 13.2.10.7 Returns: ERR25 NOT ALLOWED{EOL}
# The command can only be executed when initialized as a Central.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_2_10_7_bleUnsubscribeNotAllowed() -> None:
    assert cmd(f'AT+CONF BLECentral1={json.dumps(_get_gap_config())}\r\n')
    config = GattConfig(
        chr=_hex_to_uuid(cf.get('peer_characteristic_subscribe_uuid', int)),
        service=_hex_to_uuid(cf.get('peer_service_subscribe_uuid', int)))
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 UNSUBSCRIBE1\r\n') == 'ERR25 NOT ALLOWED\r\n'


# 13.2.10.8 Returns: ERR27 BLE ERROR{EOL}
# When command fails to successfully subscribe to the selected characteristic.
# Not tested


# 13.3 BLE PERIPHERAL Role
# When initialized as a peripheral device, ExpressLink modules wait for connections initiated by central devices.
# Only one central device at a time can connect to a module initialized as peripheral.
#
# 13.3.1 BLE CONNECT?				[PERIPHERAL] Connection status query
# Request the current peripheral device connection status.
# 13.3.1.1 Returns: OK 0 NOT CONNECTED{EOL}
# When not connected to a central device.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_1_1_peripheralConnectQueryDisconnected() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE CONNECT?\r\n') == 'OK 0 DISCONNECTED\r\n'


# 13.3.1.2 Returns: OK 1 CONNECTED{EOL}
# When connected to a central device.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
@pytest.mark.asyncio
async def test_13_3_1_2_peripheralConnectQueryConnected() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    dname = cf.get('peer_name', str)
    assert cmd(f'AT+CONF CustomName={dname}\r\n') == 'OK\r\n'
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE ADVERTISE\r\n') == 'OK\r\n'
    print('Connecting to a central device...')
    device = await BleakScanner.find_device_by_name(dname, timeout=60)
    assert device, f'{dname} not found'
    async with BleakClient(device, timeout=60) as client:
        print("Connected: {0}".format(client.is_connected))
        get_next_event(r'OK \d+ \d+ BLE CONNECTED\r\n', print_dots=False)
        assert cmd('AT+BLE CONNECT?\r\n') == 'OK 1 CONNECTED\r\n'


# 13.3.1.3 Returns: OK 2 ADVERTISING{EOL}
# When advertising is in progress.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_1_3_peripheralConnectQueryAdvertising() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE ADVERTISE\r\n') == 'OK\r\n'
    assert cmd('AT+BLE CONNECT?\r\n') == 'OK 2 ADVERTISING\r\n'


# 13.3.1.4 Returns: ERR25 NOT ALLOWED{EOL}
# When the module role was not initialized as Peripheral
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_1_4_peripheralConnectQueryNotPeripheral() -> None:
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE CONNECT?\r\n') == 'ERR25 NOT ALLOWED\r\n'


# 13.3.2 BLE DISCONNECT		[PERIPHERAL] Connection termination request
# Terminate the current connection, if one was established by a central device.
# 13.3.2.1 Returns: OK{EOL}
# On successful termination of connection or if there was no connection to terminate
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
@pytest.mark.asyncio
async def test_13_3_2_1_peripheralDisconnect() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    dname = cf.get('peer_name', str)
    assert cmd(f'AT+CONF CustomName={dname}\r\n') == 'OK\r\n'
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE ADVERTISE\r\n') == 'OK\r\n'
    print('Connecting to a central device...')
    device = await BleakScanner.find_device_by_name(dname, timeout=60)
    assert device, f'{dname} not found'

    succeeded: bool = False
    try:
        async with BleakClient(
                device,
                disconnected_callback=(
                    lambda client: print(f'disconnect: {client}')),
                timeout=60) as client:
            print("Connected: {0}".format(client.is_connected))
            assert client.is_connected
            get_next_event(r'OK \d+ \d+ BLE CONNECTED\r\n', print_dots=False)
            assert cmd('AT+BLE DISCONNECT\r\n') == 'OK\r\n'
            get_next_event(r'OK \d+ \d+ BLE CON.*LOST\r\n', print_dots=False)
            assert cmd('AT+BLE CONNECT?\r\n') == 'OK 0 DISCONNECTED\r\n'
            succeeded = True
    except EOFError:
        # NOTE: bleak linux backend appears to be raising this exception
        # after leaving the async with block
        assert succeeded


@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_2_1_peripheralDisconnectAlready() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE DISCONNECT\r\n') == 'OK\r\n'


# 13.3.2.2 Returns: ERR25 NOT ALLOWED{EOL}
# When the module role was not initialized as Peripheral
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_2_2_peripheralDisconnectNotPeripheral() -> None:
    assert cmd('AT+BLE DISCONNECT\r\n') == 'ERR25 NOT ALLOWED\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE DISCONNECT\r\n') == 'ERR25 NOT ALLOWED\r\n'


# 13.3.2.3 Returns: ERR27 BLE ERROR{EOL}
# If command fails to terminate the connection
#
# Not tested due to no required failure conditions


# 13.3.3 BLE ADVERTISE {CANCEL} 	           [Peripheral] Advertises to nearby devices
# Start the advertising process making the module a connectable, scannable device. The process will continue until connected or cancelled by AT+BLE ADVERTISE CANCEL.
#
# 13.3.3.1 Returns: OK{EOL}
# When successful starting the Advertising process
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_3_1_bleAdvertise() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE ADVERTISE\r\n') == 'OK\r\n'


# 13.3.3.2 Returns: OK{EOL}
# On success, canceling Advertising or if not currently advertising.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_3_2_bleAdvertiseCancel() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE ADVERTISE CANCEL\r\n') == 'OK\r\n'

    assert cmd('AT+BLE ADVERTISE\r\n') == 'OK\r\n'
    assert cmd('AT+BLE ADVERTISE CANCEL\r\n') == 'OK\r\n'


@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
@pytest.mark.asyncio
async def test_13_3_3_2_bleAdvertiseCancelConnected() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    dname = cf.get('peer_name', str)
    assert cmd(f'AT+CONF CustomName={dname}\r\n') == 'OK\r\n'
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE ADVERTISE\r\n') == 'OK\r\n'
    print('Connecting to a central device...')
    device = await BleakScanner.find_device_by_name(dname, timeout=60)
    assert device, f'{dname} not found'
    async with BleakClient(device, timeout=60) as client:
        print("Connected: {0}".format(client.is_connected))
        get_next_event(r"OK \d+ \d+ BLE CONNECTED\r\n", print_dots=False)
        assert cmd('AT+BLE ADVERTISE CANCEL\r\n') == 'OK\r\n'
        assert cmd('AT+BLE CONNECT?\r\n') == 'OK 1 CONNECTED\r\n'


# 13.3.3.3 Returns: ERR4 PARAMETER ERROR{EOL}
# When initialized as peripheral and is provided with #
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_3_3_bleAdvertiseIndex() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE1 ADVERTISE\r\n') == 'ERR4 PARAMETER ERROR\r\n'


# 13.3.3.4 Returns: ERR27 BLE ERROR{EOL}
# When fails to start the Advertising process
# Not tested
#
# 13.3.3.5 Returns: ERR27 BLE ERROR{EOL}
# If fails to terminate Advertising process with CANCEL parameter
# Not tested


# 13.3.3.6 Returns: ERR25 NOT ALLOWED{EOL}
# If BLE INIT is not set to PERIPHERAL mode.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_3_6_bleAdvertiseNotPeripheral() -> None:
    assert cmd('AT+BLE ADVERTISE\r\n') == 'ERR25 NOT ALLOWED\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n')
    assert cmd('AT+BLE ADVERTISE\r\n') == 'ERR25 NOT ALLOWED\r\n'


# 13.3.4 BLE GET#		    [Peripheral] Synchronous Read of a Local Characteristic
# The BLE GET command allows the host to perform a synchronous read on a local peripheral characteristic’s value.
# The maximum value that can be retrieved from the local characteristic is 31 bytes.


# 13.3.4.1 Returns: OK{space}{value}{EOL}
# The GET request was successful, the characteristic value is returned as a hex string.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_4_1_bleGetHasValue() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'

    assert cmd('AT+BLE SET1 AB\r\n') == 'OK\r\n'
    assert cmd('AT+BLE GET1\r\n') == 'OK AB\r\n'


# 13.3.4.2 Returns: OK{space}{EOL}
# On successful get read with empty characteristic value.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_4_2_bleGetEmpty() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE GET1\r\n') == 'OK \r\n'


# 13.3.4.3 Returns: ERR8 PARAMETER UNDEFINED{EOL}
# A BLEGATT# configuration was not set.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_4_3_bleGetNoConfig() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE GET2\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_4_bleGetNoIndex() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE GET\r\n') == 'ERR4 PARAMETER ERROR\r\n'


# 13.3.4.4 Returns: ERR7 OUT OF RANGE{EOL}
# The BLEGATT# numerical suffix is out of bounds (0 or greater than MaxBLEGATT).
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_4_4_bleGetOutOfRange() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE GET0\r\n') == 'ERR7 OUT OF RANGE\r\n'
    assert cmd('AT+BLE GET512\r\n') == 'ERR7 OUT OF RANGE\r\n'


# 13.3.4.5 Returns: ERR25 NOT ALLOWED{EOL}
# The characteristic can be only be read when the peripheral is initialized
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_4_5_bleGetNotPeripheral() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE GET1\r\n') == 'ERR25 NOT ALLOWED\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE GET1\r\n') == 'ERR25 NOT ALLOWED\r\n'


# 13.3.4.6 Returns: ERR27 BLE ERROR{EOL}
# When command fails to successfully read from a characteristics
# Not tested

# 13.3.5 BLE SET# {payload}			[Peripheral] Write to a local characteristic
# The BLE SET command allows the host to perform a synchronous write to a local peripheral characteristic’s value.
# The maximum value that can be written to the local characteristic is 31 bytes.


# 13.3.5.1 Returns: OK{EOL}
# On successful write to the local characteristic.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_5_1_bleSetOk() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'

    assert cmd('AT+BLE SET1 AB\r\n') == 'OK\r\n'
    assert cmd('AT+BLE GET1\r\n') == 'OK AB\r\n'

    assert cmd('AT+BLE SET1 \r\n') == 'OK\r\n'
    assert cmd('AT+BLE GET1\r\n') == 'OK \r\n'


# 13.3.5.2 Returns: ERR4 PARAMETER ERROR{EOL}
# If the payload is not valid hex array
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_5_2_bleSetByteHexArray() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'

    assert cmd('AT+BLE SET1 hello world\r\n') == 'ERR4 PARAMETER ERROR\r\n'
    assert cmd('AT+BLE GET1\r\n') == 'OK \r\n'

    assert cmd(f'AT+BLE SET1 {"A" * 5}\r\n') == 'ERR4 PARAMETER ERROR\r\n'
    assert cmd('AT+BLE GET1\r\n') == 'OK \r\n'


# 13.3.5.3 Returns: ERR8 PARAMETER UNDEFINED{EOL}
# BLEGATT# configuration is not set.
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_5_3_bleSetNotConfigured() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE SET2 \r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 13.3.5.4 Returns: ERR7 OUT OF RANGE{EOL}
# The numerical suffix is out of bounds (0 or greater than MaxBLEGATT).
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_5_4_bleSetNotConfigured() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+CONF BLEPeripheral={}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE INIT PERIPHERAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE SET0 \r\n') == 'ERR7 OUT OF RANGE\r\n'
    assert cmd('AT+BLE SET512 \r\n') == 'ERR7 OUT OF RANGE\r\n'


# 13.3.5.5 Returns: ERR25 NOT ALLOWED{EOL}
# The command can only be executed when initialized as a Peripheral
@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_3_5_5_bleSetNotConfigured() -> None:
    config = GattConfig(chr=LOCAL_CHAR_ID, service=LOCAL_SERVICE_ID)
    assert cmd(f'AT+CONF BLEGATT1={json.dumps(config)}\r\n') == 'OK\r\n'
    assert cmd('AT+BLE SET1 \r\n') == 'ERR25 NOT ALLOWED\r\n'
    assert cmd('AT+BLE INIT CENTRAL\r\n') == 'OK\r\n'
    assert cmd('AT+BLE SET1 \r\n') == 'ERR25 NOT ALLOWED\r\n'


# 13.3.5.6 Returns: ERR27 BLE ERROR{EOL}
# When command fails to set values to local characteristics
# Not tested


@pytest.mark.skipif(not cf.get('feature_ble', bool), reason='BLE unavailable')
def test_13_ble_conf_invalidJson() -> None:
    """Setting CONF variable to JSON with bad keys or invalid JSON is an error"""
    bad_key = json.dumps({'hello': 'aaaaa'})
    not_json = "hello";
    initial_value = cmd(f'AT+CONF? BLECentral1\r\n')
    assert cmd(f'AT+CONF BLECentral1={bad_key}\r\n'
               ) == 'ERR4 PARAMETER ERROR\r\n'
    assert cmd(f'AT+CONF BLECentral1={not_json}\r\n'
               ) == 'ERR4 PARAMETER ERROR\r\n'
    assert cmd(f'AT+CONF? BLECentral1\r\n') == initial_value
    initial_value = cmd(f'AT+CONF? BLEGATT1\r\n')
    assert cmd(f'AT+CONF BLEGATT1={bad_key}\r\n'
               ) == 'ERR4 PARAMETER ERROR\r\n'
    assert cmd(f'AT+CONF BLEGATT1={not_json}\r\n'
               ) == 'ERR4 PARAMETER ERROR\r\n'
    assert cmd(f'AT+CONF? BLEGATT1\r\n') == initial_value
    initial_value = cmd(f'AT+CONF? BLEPeripheral\r\n')
    assert cmd(f'AT+CONF BLEPeripheral={bad_key}\r\n'
               ) == 'ERR4 PARAMETER ERROR\r\n'
    assert cmd(f'AT+CONF BLEPeripheral={not_json}\r\n'
               ) == 'ERR4 PARAMETER ERROR\r\n'
    assert cmd(f'AT+CONF? BLEPeripheral\r\n') == initial_value
