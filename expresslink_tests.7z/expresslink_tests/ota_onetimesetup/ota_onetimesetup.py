#!/usr/bin/env python3

# Copyright of Amazon Web Services, Inc. (AWS) 2023
#
# This code is licensed under the AWS Intellectual Property License, which can
# be found here: https://aws.amazon.com/legal/aws-ip-license-terms/; provided
# that AWS grants you a limited, royalty-free, revocable, non-exclusive,
# non-sublicensable, non-transferrable license to modify the code for internal
# testing purposes. Your receipt of this code is subject to any non-disclosure
# (or similar) agreement between you and AWS.

import boto3
import argparse
import os
import os.path
import json
import yaml
from typing import TypedDict, get_args
from mypy_boto3_iam import IAMClient

from mypy_boto3_s3 import S3Client, S3ServiceResource
from mypy_boto3_s3.literals import BucketLocationConstraintType

s3: S3Client = boto3.client('s3')
s3r: S3ServiceResource = boto3.resource('s3')
iam: IAMClient = boto3.client('iam')

AccountDir = os.path.relpath('ota_account_details')
AccountDetailsPath = os.path.join(AccountDir, f'ota_info{os.extsep}yaml')


######BOTO3 STEPS
# DONE: Import cert/key into AWS Certificate Manager (ACM)
# Create the S3 bucket
# Create the firmware update service role
def createOtaInfrastructure(bucket_name: str,
                            aws_region: BucketLocationConstraintType,
                            update_service_role_name: str,
                            custom_policy_name: str):

    class OtaInfo(TypedDict):
        s3_bucket_name: str
        service_role_arn: str

    ota_info: OtaInfo = {
        's3_bucket_name': 'Unsucessfully Created/Retrieved',
        'service_role_arn': 'Unsuccessfully Created/Retrieved',
    }

    # create bucket if it doesn't already exist
    buckets = s3.list_buckets()['Buckets']
    bucketExists = any(
        (bucket for bucket in buckets if bucket['Name'] == bucket_name))
    if not bucketExists:
        s3.create_bucket(
            ACL='private',
            CreateBucketConfiguration={'LocationConstraint': aws_region},
            Bucket=bucket_name)

    versioning = s3r.BucketVersioning(bucket_name)
    versioning.enable()

    ota_info['s3_bucket_name'] = bucket_name

    # create firmware update service role
    try:
        get_role_response = iam.get_role(RoleName=update_service_role_name)
        ota_info['service_role_arn'] = get_role_response['Role']['Arn']
    except iam.exceptions.NoSuchEntityException:
        policy_doc = {
            "Version":
            "2012-10-17",
            "Statement": [{
                "Sid": "",
                "Effect": "Allow",
                "Principal": {
                    "Service": ["iot.amazonaws.com"]
                },
                "Action": ["sts:AssumeRole"]
            }]
        }
        create_role_response = iam.create_role(
            RoleName=update_service_role_name,
            AssumeRolePolicyDocument=json.dumps(policy_doc))
        ota_info['service_role_arn'] = create_role_response['Role']['Arn']
        iam.attach_role_policy(
            RoleName=update_service_role_name,
            PolicyArn='arn:aws:iam::aws:policy/service-role/AWSIoTRuleActions')
        iam.attach_role_policy(
            RoleName=update_service_role_name,
            PolicyArn='arn:aws:iam::aws:policy/service-role/AWSIoTLogging')
        iam.attach_role_policy(
            RoleName=update_service_role_name,
            PolicyArn=
            'arn:aws:iam::aws:policy/service-role/AWSIoTThingsRegistration')
        iam.attach_role_policy(
            RoleName=update_service_role_name,
            PolicyArn=
            'arn:aws:iam::aws:policy/service-role/AmazonFreeRTOSOTAUpdate')
        policy = {
            "Version":
            "2012-10-17",
            "Statement": [{
                "Effect": "Allow",
                "Action": ["iam:GetRole", "iam:PassRole"],
                "Resource": create_role_response['Role']['Arn']
            }, {
                "Effect":
                "Allow",
                "Action":
                ["s3:GetObjectVersion", "s3:GetObject", "s3:PutObject"],
                "Resource": [f"arn:aws:s3:::{bucket_name}/*"]
            }]
        }
        response = iam.create_policy(PolicyName=custom_policy_name,
                                     PolicyDocument=json.dumps(policy))
        iam.attach_role_policy(RoleName=update_service_role_name,
                               PolicyArn=response['Policy']['Arn'])
    # Get arn
    return ota_info


###### SCRIPT OUTPUT
# Output the code signing certificate for use as the OTAcertificate on the device
# Output some sort of config containing all of the things that we auto-generated on their behalf
if __name__ == "__main__":
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument(
        "-b",
        "--bucket_name",
        type=str,
        required=True,
        help="Name of the S3 bucket to create/retrieve on AWS S3",
    )
    arg_parser.add_argument("-r",
                            "--aws_region",
                            type=str,
                            required=True,
                            choices=get_args(BucketLocationConstraintType),
                            help="AWS Region to locate S3 bucket to.")
    arg_parser.add_argument(
        "-u",
        "--update_service_role_name",
        type=str,
        required=True,
        help="Name of service role to create/retrieve to perform OTA.",
    )
    arg_parser.add_argument(
        "-p",
        "--custom_policy_name",
        type=str,
        required=True,
        help="""Name of policy to create and attach to service role.
                This may fail if a policy of the same name already exists.""",
    )
    args = arg_parser.parse_args()
    try:
        os.mkdir(AccountDir)
    except FileExistsError:
        pass
    ota_info = createOtaInfrastructure(args.bucket_name, args.aws_region,
                                       args.update_service_role_name,
                                       args.custom_policy_name)
    with open(AccountDetailsPath, 'wt') as file:
        print(yaml.dump(ota_info, indent=4))
        file.write(yaml.dump(ota_info, indent=4))

# [Manual step] Load the OTAcertificate into the device. We use DEMOCONF, real devices should do this "real"
# [Manual step] Acquire the image that we need in order to issue the update (image must have a greater version number)

# Prerequisites complete, now it's all about uploading that image, making the job, and running the commands to update. One-time setup is complete at this point.
