# ExpressLink Tests Python - Prerelease

The ExpressLink test suite refactored in Python, using pytest.

This is the development branch of the qualification tests. For developing a new
module intended for a released spec version, see the latest bundle corresponding
to that spec revision.

## Testing on a Raspberry Pi

All setup instructions should be run on a Raspberry Pi 4 with a
[64 bit Raspberry Pi OS image installed](https://www.raspberrypi.com/software/).
Additionally, you will need to use the GUI to configure your Raspberry Pi.

- On your Pi, navigate to Preferences → Raspberry Pi Configuration → Interfaces
- Enable the Serial Port
- Disable the "Serial Console"

Then, execute the remainder of the setup guide on your Raspberry Pi.

See: ExpressLink Spec Section 13 for GPIO pin layouts and a testing guide.

Make sure to install Linux bluetooth stack

```bash
sudo apt install bluez
```

## Testing elsewhere

In addition to Raspberry Pi testing, examples are provided for testing the
reference `linuxsim` and a reference ESP32 platform using an FT4232H `ftdi` over
USB. The `tests/device_pal`` directory houses abstractions for communicating
with an ExpressLink Module.

Testers are free to modify existing or add their own device_pal layer in order
to test their ExpressLink module from a laptop or other hardware. A new comms
layer can be included by changing the `platform` configuration to the
subdirectory containing the `comms.py`.

`comms.py` contains setup and cleanup functions to manage UART sessions with the
ExpressLink module and open and close GPIO ports. write_device and read_device
implement a simple UART interface. GPIO pin functions exist in order to exercise
the pins, and are important for the majority of tests which read the event queue
using the event pin.

Custom configuration variables may be added to the test configuration file in
order to retrieve platform-specific device information.

## Setting up python packages

Create a python venv and load it as follows:

```bash
python3.10 -m venv venv
. ./venv/bin/activate
pip install -r requirements.txt
```

If on an RPi, additionally run:

```bash
pip install -r requirements_pi.txt
```

Alternatively, run `nix develop`.

## Configuring AWS Credentials for boto3

The ExpressLink Python Tests require access to a testing AWS account. The
ExpressLink under test should be able to connect to this testing AWS account.

Additionally, in the test account, create a
[new IAM user with Administrator permissions by following this guide](https://docs.aws.amazon.com/streams/latest/dev/setting-up.html#Create+an+IAM+User).
Afterwards, use
[this guide to get an Access Key and a Secret Access Key for your Administrator IAM user](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_access-keys.html#Using_CreateAccessKey).
Lastly, follow the
[boto3 guide to configuring credentials](https://boto3.amazonaws.com/v1/documentation/api/latest/guide/credentials.html).

If you have the AWS CLI installed, you can use the command `aws configure` to
configure boto3.

NOTE: Administrator permissions are a temporary measure only required for this
pre-release version. A later version of the ExpressLink Python Tests will
specify a minimal IAM Role with limited account access.

### Configuring Tests for Device OTA and Host OTA

If a test environment does not already exist for OTA, a python script is
available to create resources necessary for OTA using boto3. Run the following
commands from the project root directory to setup OTA on AWS IoT:

```
cd ota_onetimesetup
./ota_onetimesetup.py --help
```

Follow the help message to configure the required command-line arguments. After
running the script successfully, account details are written to
`ota_onetimesetup/ota_account_details`.

> Note: The setup script will not recreate existing resources. The script can be
> used to retrieve existing OTA account details from AWS if they were setup
> previously.

The script requires the use of an administrator role in order to create a
service role & attach policies and create an S3 bucket to store test OTA images.
The script also retrieves information about each item.

After retrieving the details, the YAML in the account details directory can be
copied into the test configuration file.

### Preparing an OTA binary

In order to perform module OTA, the test configuration still requires an OTA
binary and a base64-encoded signature. The binary must be a built firmware image
with a version number greater than the firmware loaded on the device. The
signature should be signed using a production key and `ota_certificate_path`
should point to a production OTA signing certificate.

Here is an example of using OpenSSL to sign a firmware image and base64 encode
it:

```bash
openssl dgst -sha256 -sign private_key.pem firmware_image.bin |
python -m base64 | tr -d \\n > firmware_image.base64
```

The image can be verified locally:

```bash
python -m base64 -d firmware_image.base64 > firmware_image.sig
openssl dgst -sha256 -verify public_key.pem -keyform pem -signature firmware_image.sig firmware_image.bin
```

## Running Tests

```bash
# Running eltest.py with no arguments
./eltest.py

# Running against another platform:
./eltest.py --platform linuxsim
```

After each test, a JSON test report is saved in `./eltest_report.json`.

### Test Configuration

When running the ExpressLink tests without any arguments, the values in
`eltest_config.yaml` are used for test configuration. **You should configure
`eltest_config.yaml` prior to running the tests, as the default config will not
work.** We recommend making a copy of `eltest_config.yaml` to configure, as
future updates to the ExpressLink Python Tests may change config keys.

The tests can be configured in a variety of ways:

```bash
# Default test run (uses eltest_config.yaml)
./eltest.py

# Change config file using a relative path
./eltest.py --config ../relative_elconfig.yaml

# Change config file using an absolute path
./eltest.py --config /home/myfolder/absolute_elconfig.yaml

# Override individual YAML config keys from the command line
./eltest.py --platform linuxsim --linuxsim_binary_path /home/myfolder/linuxsim_binary

# Override a list YAML config key by repeating the override argument
./eltest.py --config_commands 'AT+CONF SSID=example_ssid' --config_commands 'AT+CONF Passphrase=example_passphrase'
```

### Modifying test behavior with pytest

The ExpressLink tests use `pytest` to run tests. Arguments will be passed to
pytest from the command line, allowing you to modify test behavior. For a more
comprehensive guide to test parameters with `pytest`, read the
[pytest documentation](https://docs.pytest.org/en/7.1.x/how-to/output.html).

```bash
# To see all test output as the tests are executing:
./eltest.py -s

# To see both successful and failing tests in the test summary:
./eltest.py -raxP

# To filter the tests to a specific test or group of tests:
./eltest.py -k 'test_misc_removed_democonf'
./eltest.py -k 'test_6'
./eltest.py -k 'test_8 or test_11'
```
