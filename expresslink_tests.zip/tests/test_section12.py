# Copyright of Amazon Web Services, Inc. (AWS) 2023
#
# This code is licensed under the AWS Intellectual Property License, which can
# be found here: https://aws.amazon.com/legal/aws-ip-license-terms/; provided
# that AWS grants you a limited, royalty-free, revocable, non-exclusive,
# non-sublicensable, non-transferrable license to modify the code for internal
# testing purposes. Your receipt of this code is subject to any non-disclosure
# (or similar) agreement between you and AWS.
from commands import *
import config_handler as cf
import re
import pytest
import paho.mqtt.client as mqtt
from mqtt_client import subscribe, wait_for_message, publish
import json
from time import sleep
from cryptography import x509
from datetime import timedelta

# 12        Provisioning
# All ExpressLink modules will be equipped with a pre-provisioned hardware root of trust (on chip or
# external secure element, secure enclave, TPM, iSIM...). This will provide the necessary unique identifier
# (UID) of the module, a key pair (public, private) and will hold a certificate, signed by a CA shared with
# AWS as part of ExpressLink program. This certificate will be used to transfer the module public key to
# the AWS endpoint upon activation.
# Untestable

# 12.1      ExpressLink Modules Activation
# Upon first use, or following a complete Factory Reset, each ExpressLink module will be ready to establish
# a connection according to the model specific connectivity capabilities (i.e., Wi-Fi, Cellular...). In case of
# Wi-Fi modules, this will be possible only after the end-user has provided the module with the proper Wi-
# Fi credentials for a local compatible Wi-Fi Access Point (router) (see CONFMODE in section 4.7.5).
# Tested in Section 6 (CONF dictionary) and Section 5 (MQTT)


# 12.1.1    ExpressLink Staging Account Authentication
# Each ExpressLink module will be ready to establish a connection with a default AWS IoT ExpressLink
# staging account. The connection will be mutually authenticated using the ExpressLink birth certificate
# (and an AWS server certificate) and upgraded to a secure socket connection (Mutual TLS).
def test_12_1_1_StagingAccountConnection():
    assert connect_with_retries()
    assert cmd("AT+CONNECT?\r\n") == "OK 1 0 CONNECTED STAGING\r\n"


# 12.1.2    ExpressLink Staging Account Endpoint
# Each ExpressLink manufacturing partner will be assigned by AWS during the qualification process a
# dedicated staging account and the associated unique AWS endpoint (URL).
#
# 12.1.2.1  The assigned staging account endpoint will be set as the “factory default” for the Endpoint
# configuration parameter (see Table 2).
def test_12_1_2_StagingAccountEndpoint():
    assert re.match(r'^OK .+\r\n$', cmd("AT+CONF? Endpoint\r\n"))
    assert cmd("AT+CONNECT?\r\n") == "OK 0 0 DISCONNECTED STAGING\r\n"


# 12.1.3    ExpressLink Birth Certificate
# Each ExpressLink device must be provided with a X.509 certificate that conforms to the following
# specification:


def _GetCertificatePem(key: str) -> str:
    match = re.match(r'^OK(\d+) pem\r\n$', cmd(f'AT+CONF? {key} pem\r\n'))
    assert match, 'Unexpected response format'
    lineCount = int(match.groups()[0])
    if lineCount == 0:
        return ''

    response: str = ''

    def checkResponse(part: str) -> bool:
        nonlocal response
        nonlocal lineCount
        response += part
        print(end=part, flush=True)
        lineCount -= part.count('\n')
        return lineCount <= 0

    try:
        poll(comms.read_device,
             check_success=checkResponse,
             timeout=120,
             step=0)
    except TimeoutException:
        pytest.fail('Too few lines received')

    assert lineCount == 0, 'Too many lines received'

    return response


# 12.1.3.1  The Serial Number must contain the device Unique ID, a unique nonsequential 128-bit or
# larger number also used as the ExpressLink module ThingName configuration.
# TODO: Spec to use Common Name instead of Serial Number
#
# 12.1.3.2  The certificate signature will be provided by a Certificate Authority that must be registered
# by the vendor with AWS IoT Core for the exclusive use of the vendor ExpressLink modules.
#
# 12.1.3.3  The expiration date will be set to no less than 10 years from the device certificate issue.


def test_12_1_3_BirthCertificateCommonNameIsThingName():
    certificate = _GetCertificatePem('Certificate')
    cert = x509.load_pem_x509_certificate(certificate.encode())
    common_name = cert.subject.get_attributes_for_oid(
        x509.oid.NameOID.COMMON_NAME)[0].value

    Thing_name = cmd("AT+CONF? ThingName\r\n")

    assert common_name == Thing_name[3:-2]


@pytest.mark.prod
def test_12_1_3_BirthCertificateExpiry() -> None:
    certificate = _GetCertificatePem('Certificate')
    cert = x509.load_pem_x509_certificate(certificate.encode())

    if cert.not_valid_after is not None:
        valid_lifetime = cert.not_valid_after - cert.not_valid_before

        assert valid_lifetime > timedelta(days=365 * 10)


# 12.1.4    ExpressLink staging account device registration
# Through the staging account endpoint, the ExpressLink module will proceed to login to the AWS IoT
# Core MQTT broker. If successful, an automated process (JITP or similar) will create a Thing (and
# associated policies) using an ExpressLink template and append it to the staging account registry.
# Tested - test_12_1_1_StagingAccountConnection


# 12.1.5     ExpressLink MQTT Login signature
# The ExpressLink module will present an “MQTT login string” formatted as follows (as a single line string):
# “?SDK=RTOS &SDKVersion=x.y.z &Platform=ExpressLink &Metadata=( Vendor=<vendor-name>;
# Model=<model-name>; FWversion=X.Y.Z; TechSpec=0.9.1; CustomName=<custom-product-name>)”
# This string is logged by AWS IoT Core and will allow the collection of meta data that will be used to
# assess the effective usage of ExpressLink modules, provide diagnostic information and measure the
# successful completion of the onboarding process.
# • SDK: is the RTOS used by the ExpressLink module (i.e., FreeRTOS)
# • SDKVersion: is the semantic version of the RTOS kernel used (i.e., v10.4.2)
# • Platform: must match the string “ExpressLink”
# • Metadata: provides further detail as a list of additional key-value pairs using the following
# grammar (<key>=<value>; *). The Metadata value string enclosed in parenthesis will be:
#
# 12.1.5.1  Keys and values are expressed using ASCII alphanumeric characters (0-9, A-Z, a-z),
# including the dash (-), period (.) and space
#
# 12.1.5.2  Leading/trailing spaces will be ignored and automatically trimmed from keys and values.
#
# 12.1.5.3  The following key/value pairs are required:
# 1. Vendor: manufacturer of the module
# 2. Model: uniquely identifies the specific model NOTE: Vendor and Model combine to
# form the persistent configuration parameter “About” (see Table 2) with a max length of
# 64 characters.
# 3. FWversion: semantic version of the manufacturer module firmware (i.e., 1.1.13) also
# see persistent configuration parameter “Version” in Table 2.
# 4. TechSpec: semantic version of the module technical specifications target (i.e., 0.9.1) also
# see persistent configuration parameter “TechSpec” in Table 2.
# 5. CustomName: custom field as configured by the host processor (see Table 2) also see
# persistent configuration parameter “CustomName” in Table 2.
#
# 12.1.5.4  The Metadata string (contained in parenthesis) will not exceed a maximum length of 256
# characters. Should the concatenation of the prescribed key/value pairs exceed this
# maximum value, it will be right-truncated at the expense of the CustomName value.
# Example of Metadata:
# (Vendor=ABC; Model= A-1234; FWversion = X.Y.Z; TechSpec =0.9.1; CustomName = Toaster 3000 )
# Note the uneven use of spaces in the example above is interpreted correctly by applying leading and
# trailing spaces trimming as per 12.1.5.2.
def test_12_1_5_LoginSignature():
    # TODO: Use Mosquitto to verify login signature?
    # TODO: Spec change to add key that matches login signature so this is easier to test?
    pass


# 12.2      ExpressLink Evaluation Kits Quick Connect Flow
# ExpressLink Evaluation Kits will be able to use the ExpressLink staging account to deliver a fast out-of-
# box experience. As soon as connected they will be able to publish data to an ExpressLink MQTT topic
# (i.e., ‘data’) and subscribed to any ExpressLink MQTT topic (i.e., ‘state’). A simple web application (Quick
# Connect) will be made available by AWS to all ExpressLink users to visualize (animated graphs) the data
# published by the Host processor and to send customizable commands back to their Host processors.
#
# Developers will be able to register their ExpressLink modules to their private AWS accounts and proceed
# to application development with a few simple manual steps documented in the Getting Started Guide
# (extracting the device certificate, uploading it to their private accounts and updating the ExpressLink
# endpoint).
# Untested - no Quick Connect integrated testing setup

# 12.2.1    Workshop Default Wi-Fi Credentials (Optional)
# To reduce the number of configuration steps (and time) required to establish a Wi-Fi connection, a
# default set of Wi-Fi credentials can be provided in the configuration dictionary at Factory Reset.
# Note how using default Wi-Fi credentials can be convenient in workshop, classroom or seminar
# environments avoiding a number (10+) of user to attempt simultaneously to use a CONFMODE
# (Bluetooth) connection and greatly simplifying the room set up.
# If implemented, the manufacturer will document such credentials in the module datasheet.
# TODO: Investigate if we can drop this spec requirement - we have AT+CONF for this situation

# 12.3      ExpressLink Production Onboarding Flow
# Onboarding is the process of creating a “Thing” corresponding to each physical device in the customer
# account registry in order to provide access to the account IoT core services. Each Thing requires the
# association with a valid certificate and access policy document.
# In a production flow, ExpressLink customers can use any of a number of automated onboarding
# techniques as required by the customer application, including:
# 1- Pre-registration, where modules certificates are obtained before assembly and uploaded to the
# customer account in advance.
# 2- End of (assembly) Line registration, where module certificates are collected after product
# assembly and individually uploaded to the customer AWS account.
# 3- End of Line batch registration, where module certificates are collected after product assembly
# and shipped in batches to the customer for upload into the AWS account.
# 4- Just in Time Registration, where the device onboards to the customer account at first
# connection (requires pre-registration of the module manufacturer CA to the customer account)
# 5- Late-binding, where the end product end-user is performing the product-onboarding (often
# simultaneously with the user own registration, although the two steps should not be here
# confused).
# Untested - Device flows besides Late Binding, as no EL interface is exercised


# 12.3.1 ExpressLink Late Binding (Onboarding by Claim) flow example
# A late binding onboarding flow can be initiated by the end-user after purchasing the finished product
# when connecting it for the first time and registering the product. The end-user can be directed to a web
# application devised by the OEM/customer, (i.e., a toaster manufacturer) that will guide the user through
# the following steps:
# 1. Wi-Fi credential entry (only for Wi-Fi modules), this is required to access the AWS cloud. It can
# be performed by means of the host activating a CONFMODE for credential entry or by the host
# manipulating directly the configuration dictionary (SSID, Passphrase).
# 2. ExpressLink staging account first access.
# 3. Claim of the ExpressLink module (identified by ThingName) from staging account.
# 4. Transfer of certificate to OEM account registry (Thing creation).
# 5. Update of the ExpressLink module Endpoint (to point to the OEM account).
# 6. ExpressLink Device disconnect and reconnect to OEM account.
# Steps 1 and 2 are facilitated by the staging account assigned to each manufacturer and managed by
# AWS. Steps 3 and 4 require the customer implementation of the claim mechanism interacting with the
# AWS managed staging account. Step 5 is facilitated by a specific device feature as described in section
# 12.3.2.
# Additional steps for the user registration, creation of an end-user (application) account, the collection of
# user identifiable information (i.e., user name and password) and its binding to the ExpressLink Thing are
# left to the OEM application.
#
# 12.3.2 ExpressLink Onboarding States and Transitions
# The configuration parameter Endpoint (see Table 2) controls the onboarding state of the device.
# The device is in the Staging state when the Endpoint parameter (string) matches the factory default
# value which corresponds to an AWS-managed staging account assigned to each manufacturer.
# The device is in the Onboarded state when the Endpoint parameter has been modified to point to a
# customer account (endpoint) by means of the host directly updating the configuration dictionary using a
# CONF command (see 6.2.1) or by means of the following remote update process:
#
# 12.3.2.1 When (and only when) in the Staging state, connected ExpressLink modules automatically
# subscribe ONLY to the endpoint-update topic:
# <ThingName>/expresslink_config
# Upon receiving a message on the update topic with the following format:
# {“Endpoint” : “value”}
# the module will update the Endpoint configuration parameter with the requested new
# value.
#
# 12.3.2.2 The MSG event produced, can be retrieved (GET0) and used by the host to implement
# additional optional features such as alerting the user of the device successful onboarding
# (registration).
#
# 12.3.2.3 The module will also automatically disconnect. The related CONLOST event will inform the
# host of the need to re-establish a new connection (this time to the newly assigned
# endpoint).
#
# 12.3.2.4 The host can query the state of the module using the CONNECT? command and inspecting
# the second numerical parameter provided in the response (see 4.7.1) without having to
# inspect the contents of the Endpoint configuration parameter (or knowing/assuming the
# default Endpoint value to compare against).
#
# 12.3.2.5 When (and only when) in the Onboarded state, connected ExpressLink modules will
# subscribe automatically to a number of AWS-reserved topics as required to support OTA
# and other core ExpressLink functionality. Features dependent on the AWS IoT Device
# Defender and AWS IoT Device Shadow services will similarly be supported only when in the
# Onboarded state.
#
# Figure 6 - ExpressLink onboarding states diagram
#                                               Host Update (AT+CONF)
#                                           /--------------------------\
#                                          /   Remote Endpoint Update   v
# [ endpoint factory default ] --> ( staging ) ----------------------> (Onboarded)
#                                         ^                             /
#                                          \---------------------------/
#                                                  Factory Reset
#
# Notice that, despite an ExpressLink module being considered in the onboarded state after changing the
# ExpressLink endpoint, this does not guarantee that it will be able to successfully connect to the target
# account. For the completion of the entire onboarding process to succeed, the target AWS IoT Core
# account needs to be correctly configured to enable Just in Time Provisioning or Registration (or the
# device certificate needs to be manually uploaded). Please refer to the “AWS IoT ExpressLink
# Onboarding-by-Claim Guide” for a detailed description.
# Only when the device successfully achieves a new connection to the target endpoint, it can be
# considered fully onboarded. Note that this can be tested using the CONNECT? command as described in
# section 4.7.1.3. Once fully onboarded, ExpressLink modules are connecting to the customer/OEM
# account where IoT Things will be created and managed within the chosen OEM account registry.
# It is the responsibility of the OEM to manage the product life cycle, use the OTA services to apply
# module updates (with images provided by the ExpressLink module vendor) and host processor
# application updates as needed.
def test_12_3_2_StagingEndpointMode():
    assert cmd("AT+CONNECT?\r\n") == "OK 0 0 DISCONNECTED STAGING\r\n"
    assert cmd("AT+CONF Endpoint=example.com\r\n") == "OK\r\n"
    assert cmd("AT+CONNECT?\r\n") == "OK 0 1 DISCONNECTED CUSTOMER\r\n"
    assert cmd(
        f"AT+CONF Endpoint={pytest.expresslink_info['staging_endpoint']}\r\n"
    ) == "OK\r\n"
    assert cmd("AT+CONNECT?\r\n") == "OK 0 0 DISCONNECTED STAGING\r\n"


def test_12_3_2_OnboardingByClaim(staging_mqtt_client: mqtt.Client):
    assert connect_with_retries()
    assert cmd("AT+CONNECT?\r\n") == "OK 1 0 CONNECTED STAGING\r\n"
    sleep(10)  # Give the module a chance to subscribe to the claim topic
    claim_topic = pytest.expresslink_info["thing_name"] + "/expresslink_config"
    claim_message = '{"Endpoint": "' + cf.test_config["personal_endpoint"].get(
        str) + '"}'
    publish(staging_mqtt_client, claim_topic, claim_message)
    # Get the next event - there should be a MSG and CONLOST in any order
    first_event = get_next_event(r'^OK (1 0 MSG|3 0 CONLOST)\r\n$')
    assert first_event
    second_event = get_next_event(r'^OK (1 0 MSG|3 0 CONLOST)\r\n$')
    assert second_event
    assert first_event != second_event
    assert cmd("AT+GET0\r\n") == f"OK1 {claim_topic}\r\n"
    assert cmd("") == f"{claim_message}\r\n"
    assert cmd("AT+CONF? Endpoint\r\n"
               ) == f"OK {cf.test_config['personal_endpoint']}\r\n"
    assert cmd("AT+CONNECT?\r\n") == "OK 0 1 DISCONNECTED CUSTOMER\r\n"
    assert connect_with_retries()


@pytest.mark.slow
def test_12_3_2_1_NoClaimOnCustomerAccount(mqtt_client: mqtt.Client):
    assert connect_with_retries(cf.test_config["personal_endpoint"].get(str))
    assert cmd("AT+CONNECT?\r\n") == "OK 1 1 CONNECTED CUSTOMER\r\n"
    sleep(10)  # Give the module a chance to subscribe to the claim topic
    claim_topic = pytest.expresslink_info["thing_name"] + "/expresslink_config"
    claim_message = '{"Endpoint": "example.com"}'
    publish(mqtt_client, claim_topic, claim_message)
    sleep(10)  # Give time for the publish to propagate
    # Get the next event - there should be a MSG and CONLOST in any order
    assert cmd("AT+EVENT?\r\n") == "OK\r\n"
    assert cmd("AT+CONF? Endpoint\r\n"
               )[3:-2] == cf.test_config["personal_endpoint"].get(str)
    assert cmd("AT+CONNECT?\r\n") == "OK 1 1 CONNECTED CUSTOMER\r\n"


def test_12_3_2_5_ShadowErrorInStaging():
    assert connect_with_retries()
    assert cmd("AT+CONF EnableShadow=1\r\n") == "OK\r\n"
    assert cmd("AT+SHADOW INIT\r\n") == "ERR24 SHADOW ERROR\r\n"
    assert cmd("AT+SHADOW DOC\r\n") == "ERR24 SHADOW ERROR\r\n"
    assert cmd(
        "AT+SHADOW UPDATE { \"state\": { \"desired\": { \"testkey\": \"testvalue\"}}}\r\n"
    ) == "ERR24 SHADOW ERROR\r\n"
    assert cmd("AT+SHADOW SUBSCRIBE\r\n") == "ERR24 SHADOW ERROR\r\n"
    assert cmd("AT+SHADOW DELETE\r\n") == "ERR24 SHADOW ERROR\r\n"


# 12.4      End-User change, product re-registration
# This is a normal occurrence in the life of many products upon their resale or disposal. If required,
# ExpressLink modules can be reset to factory settings to reactivate the onboarding process from the
# beginning and eliminating any previous owner association.
# Tested in test_12_3_2_OnboardingByClaim

# 12.5      Onboarding Failures Handling
# The onboarding process can fail at various points due to end-user, host application or network errors.
# We envision the following scenarios:
# 1. Onboarding process failure: the OEM might have misconfigured the account policies preventing
# the device certificate to be moved into the target account. The AWS IoT API will report such
# error to the OEM developers during testing.
# 2. Onboarding process failure: the ExpressLink claim and removal from the staging account fails
# leaving it in the staging account while a new Thing is created in the OEM account and the
# ExpressLink module is redirected to the new endpoint. The staging account periodic cleaning
# and fraud detection sweeps will clear the anomaly shortly.
# 3. Endpoint Update failure: the ExpressLink endpoint update message is not received by the
# device. The device remains in the staging account and fails to connect to the target OEM
# account within a given amount of time. The binding process (web application) can be designed
# to timeout and guide the user to repeat the procedure until successful.
# 4. Accidental product factory reset: the ExpressLink device will rejoin the staging account as soon
# as connectivity is regained. Onboarding process can be restarted at any time. The OEM
# application will be able to detect that an already registered device is re-applying to onboarding
# and possibly help to restore the product status and/or report the error to developers.
# Untested - failure states involve Quick Connect or user error
