# 0xC5_91_85_45_9C_3D --> 'C5:91:85:45:9C:3D'
def _hex_to_mac(addr: int) -> str:
    text: str = hex(addr)[2:].upper().zfill(12)
    pairs: list[str] = [text[i:i + 2] for i in range(0, len(text), 2)]
    return ':'.join(pairs)


def _hex_to_uuid(id: int) -> str:
    len: int = 0
    if id <= 0xFFFF:
        len = 2
    elif id <= 0xFFFFFFFF_FFFF_FFFF:
        len = 8
    elif id <= 0xFFFFFFFF_FFFF_FFFF_FFFF_FFFFFFFFFFFFFF:
        len = 16
    return hex(id)[2:].upper().zfill(len * 2)


def _mac_to_hex(mac: str) -> int:
    return int(''.join(mac.split(':')))


def _to_hex(num: int) -> str:
    return hex(num)[2:].upper()
