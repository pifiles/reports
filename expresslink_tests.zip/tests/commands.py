# Copyright of Amazon Web Services, Inc. (AWS) 2023
#
# This code is licensed under the AWS Intellectual Property License, which can
# be found here: https://aws.amazon.com/legal/aws-ip-license-terms/; provided
# that AWS grants you a limited, royalty-free, revocable, non-exclusive,
# non-sublicensable, non-transferrable license to modify the code for internal
# testing purposes. Your receipt of this code is subject to any non-disclosure
# (or similar) agreement between you and AWS.

import time
from typing import Optional
from tests.comms_importer import comms
from polling import poll, TimeoutException
import re


def cmd(input: str, print_output: bool = True, timeout: int = 120) -> str:
    """Send the input, then wait up to 120 seconds for a response"""
    if len(input) > 0:
        comms.write_device(input)

    response: str = ""
    if print_output:
        print(bytes(f"Command:  {input}", encoding='iso_8859_1'), end='')

    def check_response() -> bool:
        nonlocal response
        response += comms.read_device()
        if print_output:
            print('.', end='', flush=True)
        return len(response) > 0 and response[-1] == "\n"

    poll(check_response, step=0.01, timeout=timeout)
    if print_output:
        print()
        print(bytes(f"Response: {response}", encoding='iso_8859_1'),
              end='\n\n')
    return response


def connect_with_retries(endpoint: Optional[str] = None) -> bool:
    """Attempt to connect to IoT Core with retries over 30 seconds"""
    if endpoint:
        assert cmd(f"AT+CONF Endpoint={endpoint}\r\n") == "OK\r\n"
    try:
        poll(lambda: cmd("AT+CONNECT\r\n") == "OK 1 CONNECTED\r\n",
             step=5,
             timeout=30)
        return True
    except TimeoutException:
        return False


def get_next_event_match(event_regex: re.Pattern[str] | str,
                         print_dots: bool = True,
                         timeout=120) -> Optional[re.Match[str]]:
    """Polls the event queue with AT+EVENT? until a match is found

       When an event is not available, prints a dot if print_dots"""

    t1 = time.time()

    def device_has_event() -> bool:
        has_event: bool = comms.get_event_pin()
        if not has_event and print_dots:
            print('.', flush=True, end='')
        return has_event

    def check_if_next_event_matches() -> Optional[re.Match[str]]:
        poll(device_has_event, step=0.01, timeout=timeout - (time.time() - t1))
        if print_dots:
            print(end='\n\n')
        return re.match(event_regex, cmd("AT+EVENT?\r\n"))

    try:
        return poll(check_if_next_event_matches, step=0.1, timeout=timeout)
    except TimeoutException:
        print(f"Timed out while waiting for an event to match: {event_regex}")
        return None


def get_next_event(event_regex: re.Pattern[str] | str,
                   print_dots: bool = True,
                   timeout=120) -> Optional[str]:
    """Finds the next event which matches the input regex

       Returns the main capture group as string"""
    match = get_next_event_match(event_regex=event_regex,
                                 print_dots=print_dots,
                                 timeout=timeout)
    return None if match is None else match.group()
