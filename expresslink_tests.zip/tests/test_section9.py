# Copyright of Amazon Web Services, Inc. (AWS) 2023
#
# This code is licensed under the AWS Intellectual Property License, which can
# be found here: https://aws.amazon.com/legal/aws-ip-license-terms/; provided
# that AWS grants you a limited, royalty-free, revocable, non-exclusive,
# non-sublicensable, non-transferrable license to modify the code for internal
# testing purposes. Your receipt of this code is subject to any non-disclosure
# (or similar) agreement between you and AWS.
from datetime import datetime
import os
import random
import time
import warnings
import boto3
from dateutil import tz  # type: ignore
import re
from typing import IO, Any, Literal, Optional, Sequence, Tuple, get_args
from typing_extensions import Self
import pytest
from commands import cmd, comms, connect_with_retries, get_next_event
from enum import Enum, IntEnum, unique
import config_handler as cf

from mypy_boto3_iot.client import IoTClient
from mypy_boto3_s3 import S3Client
from mypy_boto3_iot.type_defs import OTAUpdateFileTypeDef, GetOTAUpdateResponseTypeDef, DescribeJobExecutionResponseTypeDef
from mypy_boto3_iot.literals import JobExecutionStatusType
from mypy_boto3_iot.paginator import ListJobExecutionsForThingPaginator

from polling import TimeoutException, poll

import hota_setup
from hota_setup import SignatureInfo

# 9         ExpressLink module Updates
# ExpressLink modules support natively firmware updates utilizing the AWS IoT OTA service (as currently
# implemented in the AWS Embedded C-SDK v.202103.00) and Over the Wire (OTW).
# To support the OTA feature, ExpressLink modules provide additional bulk storage space (non-volatile
# memory). The amount of non-volatile memory available will be sufficient to store two full copies of the
# ExpressLink own firmware image, a current known-good copy and a new copy. This is intended to
# provide a backup in case of a fatal failure during the update process.
# When an ExpressLink firmware update job is triggered (via the AWS IoT OTA console), the update
# process begins and takes place in five steps:
# 1- Without disrupting the Host processor communication, the module will start receiving chunks of
# the new firmware image
# 2- Each chunk will be checked for integrity and acknowledged, retried as necessary and stored in
# bulk memory.
# 3- When all chunks are reassembled in bulk memory, a final signature check will be performed
# 4- Only if successfully verified, the module will notify the Host processor
# 5- Upon receiving an explicit request, the ExpressLink module will initiate a reboot.
# This process provides two types of security/safety assurance to the user: 1) It makes sure that only valid
# memory images are accepted and 2) the potentially disruptive process of rebooting, is performed in
# agreement with the host processor to avoid impacting the overall product functionality and consequent
# potential safety hazards.
# The host processor will be notified of the module OTA ready/pending via an event. (see EVENT?
# command in section 8.2.1).
# The host processor will be able to poll the OTA process state at any time using the OTA? Command (see
# section 9.2.1).
# Note: The OTA service is supported only when the device is in the onboarded state (see section 12.3.2)
# that is only when the module is connected to the customer AWS account.

# 9.1       ExpressLink module support of Host Processor OTA
# ExpressLink modules are designed to support Host processor updates Over the Air (HOTA). This is done
# in a shared responsibility model in collaboration with the host processor. The Bulk Storage memory
# capacity of the module might be shared between module and host OTA images, so that only one of the
# two is guaranteed to be supported at any time. Although, manufacturers can choose to differentiate
# their products by offering a larger amount of non-volatile memory. Also, the HOTA feature is not limited
# to support only host processor firmware images but can be used to transport, stage and verify the
# delivery of any large payload including pictures, audio files, or any binary blobs containing potentially
# multiple files of different nature.
# The mechanism utilized for triggering and performing the transfer of host processor images makes use
# of the same underlying services as per the module OTA (namely AWS IoT Jobs and AWS IoT OTA). It
# utilizes a collaborative model based on the paradigm of a mailbox. ExpressLink devices act as the
# recipient of envelopes meant for the host. They can verify the envelope integrity (checksum) and the
# authenticity (signature) before notifying the host rising a flag (event). It is up to the host to periodically
# check for flags, and when ready, to retrieve the content of the mailbox. ExpressLink devices, much like
# mailboxes are not concerned with the nature of the content of the envelopes. Once the envelope is
# retrieved, and the flag lowered, they are (empty) ready to receive more mail. Successive attempts to
# deliver more updates to a host processor will be NACK-ed until the host either retrieves the update or
# rejects it, clearing the flag without retrieving the content.
# The communication between host processor and ExpressLink module required to deliver a OTA payload
# can be represented in the following diagram:
# 9.1.1.1       ExpressLink OTA/HOTA process
# ExpressLink module                                            Host Processor
#         |                                                          |
# Receives an event indicating an OTA request                        |
# and generates an event (also rising EVENT Pin)                     |
#         |                                                          |
#         |                                                          |
#         | <-------------------------------------- EVENT? polls the event queue
#         |                                                          |
# Returns OK 5 0 OTA indicating an OTA event ----------------------> |
#         |                                                          |
#         |                                                          |
#         |                                                          |
#         | <---------------------------------------- OTA? checks the OTA state
#         |                                                          |
# Returns OK OTA {code} {metadata} indicating a (H)OTA update with   |
# proposed metadata (e.g, "v2.5.7") is available                     |
# OTA code 1 and 2 indicates OTA oand HOTA respectively -----------> |
#         |                                                          |
#         |                                      Either OTA ACCEPT or OTA FLUSH
#         | <------------------------ Accept or reject update based on metadata
#         |                                                          |
# Start receiving an OTA payload                                     |
#         |                                 Host processor may abort OTA update
#         | <--------------------------------------- at any time with OTA FLUSH
#         |                                                          |
# When OTA download completes,                                       |
# generates an event (also rising EVENT Pin)                         |
#         |                                                          |
#         |                                                          |
#         | <-------------------------------------- EVENT? polls the event queue
#         |                                                          |
# Returns OK 5 0 OTA indicating an OTA event ----------------------> |
#         |                                                          |
#         | <---------------------------------------- OTA? checks the OTA state
#         |                                                          |
# Returns OK OTA {code} indicating (H)OTA update is ready            |
# OTA code 4 and 5 indicate OTA and HOTA respectively -------------> |
# #############################################################################
#         |                     if update is canceled                |
#         | <------------------ Host processor aborts OTA update with OTA FLUSH
#         |                                                          |
#         |                                                          |
# #############################################################################
#         |               else, if OTA accepted                      |
#         |                                    when safe, update with OTA APPLY
# ExpressLink module firmware                                        |
# is updated and module reboots                                      |
# Reset event is generated (also rising EVENT Pin)                   |
# #############################################################################
#         |              else, if HOTA accepted                      |
#         |                                                          |
#         |                                if HOTA, retrieve appropriate number
#         | <--------------------------- of bytes of data with OTA READ {bytes}
#         |                                                          |
# Delivers first chunk of payload data                               |
# and advances pointer --------------------------------------------> |
#         |                                                          |
#  This process repeats until entire payload is transferred to host processor
#  At any point, the host processor may request the pointer to be reset or moved.
#  Alternatively, the host processor may terminate the HOTA update entirely
#         |                                                          |
# Module returns a 0-sized chunk,                                    |
# indicating complete transfer ------------------------------------> |
#         |                                                          |
#         |                         OTA CLOSE to indicate to ExpressLink module
#         | <----- that HOTA update buffer may be freed and that HOTA succeeded
# #############################################################################
#         |            Finally, in all cases without error           |
# The ExpressLink module returns a Job complete                      |
# notification to the AWS IoT OTA service                            |
#         |                                                          |
#         x                                                          x


# Note that the Host processor is not required to retrieve the entire payload at once, nor to follow a
# strictly sequential process, the fetching pointer can be moved (seek) to allow random access to the
# payload content. Also, the size of the chunks retrieved by the Host processor is independent from the
# chunking performed during the image download by the module. This is instead intended to be the most
# convenient value depending on the host processor serial interface buffer size, the Host processor own
# (flash) memory page size, and/or binary format decoding needs (i.e. INTEL HEX...). Consequently, the
# host processor can choose the reboot directly from the ExpressLink module host OTA memory or can
# choose to transfer only parts of the payload to be consumed by other subsystems as necessary.
@unique
class _OtaType(IntEnum):
    ModuleFirmwareUpdate = 101
    ModuleOtaCertificateUpdate = 103
    ServerRootCertificateUpdate = 107
    HostUpdate = 202
    HostOtaCertificateUpdate = 204


@unique
class _OtaCode(Enum):
    NoOtaInProgress = 0
    OtaUpdateAvailable = 1
    HostOtaUpdateAvailable = 2
    OtaInProgress = 3
    OtaImageReady = 4
    HostOtaImageReady = 5


def _getOTAStatus() -> Tuple[_OtaCode, Optional[str]]:
    """Queries AT+OTA? and returns response as status code and detail string"""
    match = re.match(r'^OK (\d+)(?: (.+))?\r\n$', cmd('AT+OTA?\r\n'))
    assert match
    code, detail = match.groups()
    try:
        return _OtaCode(int(code)), detail
    except ValueError:
        pytest.fail(f'{code} is not a valid OTA code')


def test_9_2_1_OTAStatusQuery() -> None:
    code, detail = _getOTAStatus()
    print(code, detail)


def _CleanOtaJobs(iot_services_client: IoTClient) -> None:
    """Cancel all OTA executions for this Thing which are queued or in progress"""
    thingName: str = pytest.expresslink_info['thing_name']  # type: ignore
    statuses: list[JobExecutionStatusType] = ['IN_PROGRESS', 'QUEUED']
    paginator: ListJobExecutionsForThingPaginator = iot_services_client.get_paginator(
        'list_job_executions_for_thing')
    for status in statuses:
        for page in paginator.paginate(thingName=thingName, status=status):
            for execution in page['executionSummaries']:
                jobId = execution['jobId']
                print(
                    f'Deleting OTA job execution {jobId} requested for this Thing'
                )
                print(
                    iot_services_client.cancel_job_execution(
                        jobId=jobId, thingName=thingName, force=True))


class _IoTOtaJobDoc():
    iotClient: IoTClient
    otaType: _OtaType
    version: str
    imageName: str
    signature: Optional[SignatureInfo]
    thingArn: str

    def __init__(self, iotClient: IoTClient, otaType: _OtaType, version: str,
                 imageName: str, signature: Optional[SignatureInfo],
                 thingArn: str):
        self.iotClient = iotClient
        self.otaType = otaType
        self.version = version
        self.imageName = imageName
        self.signature = signature
        self.thingArn = thingArn

    def __enter__(self) -> Self:
        bucketName = cf.get('s3_bucket_name', str)
        fileTypedef: OTAUpdateFileTypeDef = {
            'attributes': {
                'force': 'YES' if cf.get('ota_forced_update', bool) else 'NO'
            },
            'fileName': self.imageName,
            'fileType': self.otaType,
            'fileVersion': self.version,
            'fileLocation': {
                's3Location': {
                    'bucket': bucketName,
                    'key': self.imageName,
                    'version': self.version
                }
            }
        }

        if self.signature is not None:
            fileTypedef['codeSigning'] = {
                'customCodeSigning': {
                    'signature': {
                        'inlineDocument': self.signature.signature
                    },
                    'certificateChain': {
                        'inlineDocument': self.signature.signingCertificate,
                        'certificateName': 'TheCertificate'
                    },
                    'hashAlgorithm': self.signature.hashAlgorithm,
                    'signatureAlgorithm': self.signature.signatureAlgorithm
                }
            }
        timestamp = datetime.now(tz=tz.tzlocal()).strftime("%Y-%m-%d_%H%M%S")
        if self.otaType == _OtaType.ModuleFirmwareUpdate:
            description = f'Creating an OTA job for testing. Job created by OTA setup script at {timestamp}'
            id = f'OTAUpdate_{timestamp}'
        elif self.otaType == _OtaType.HostUpdate:
            description = f'Creating an HOTA job for testing. Job created by OTA setup script at {timestamp}'
            id = f'HOTAUpdate_{timestamp}'
        else:
            # TODO: other types
            description = f'CertificateUpdate_{timestamp}'
            id = description

        # Create OTA job for device on IoT Core
        createResponse = self.iotClient.create_ota_update(
            otaUpdateId=id,
            description=description,
            files=(fileTypedef, ),
            targets=(self.thingArn, ),
            protocols=('MQTT', ),
            targetSelection='SNAPSHOT',
            roleArn=cf.get('service_role_arn', str))

        otaJobResponse = createResponse
        assert 'otaUpdateId' in otaJobResponse

        time.sleep(5)

        def validateResponse(response: GetOTAUpdateResponseTypeDef) -> bool:
            updateInfo = response.get('otaUpdateInfo')
            if updateInfo is None:
                return False
            assert updateInfo['otaUpdateStatus'] != 'CREATE_FAILED'
            return updateInfo.get('awsIotJobId') is not None

        self.otaJobResponse = poll(
            self.iotClient.get_ota_update,
            kwargs={'otaUpdateId': otaJobResponse['otaUpdateId']},
            step=5,
            timeout=120,
            check_success=validateResponse)['otaUpdateInfo']

        self.cleanup = True

        print(f'Created OTA Job. Job details:\n{self.otaJobResponse}')
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback) -> None:
        if self.cleanup:
            self.iotClient.cancel_job(
                jobId=self.otaJobResponse['awsIotJobId'],
                comment='Canceled by test after unsuccessful run',
                force=True)


def _pollDeviceOtaStatus(desiredCode: _OtaCode,
                         allowedCodes: Sequence[_OtaCode],
                         step: float = 0.5,
                         timeout: float = 300):

    def validateStep(step: Tuple[_OtaCode, Optional[str]]):
        if step[0] == desiredCode:
            return True
        assert step[0] in allowedCodes, "Unexpected OTA state change"

    try:
        return poll(_getOTAStatus,
                    step=step,
                    timeout=timeout,
                    check_success=validateStep)
    except TimeoutException:
        return None


def _ConfigureModuleOTA(iot_services_client: IoTClient) -> _IoTOtaJobDoc:
    thingArn: str = iot_services_client.describe_thing(
        thingName=pytest.expresslink_info['thing_name'])['thingArn']

    bucketName: str = cf.get('s3_bucket_name', str)
    imageName: str = cf.get('s3_image_name', str)
    signatureName: str = cf.get('s3_signature_path', str)

    s3Client: S3Client = boto3.client('s3')

    # Upload OTA binary onto S3 bucket
    imagePath = cf.get('ota_binary_path', str)
    signaturePath = cf.get('ota_signature_path', str)
    print(f'Uploading {imagePath=} to {bucketName=} with {imageName=}')
    s3Client.upload_file(Filename=imagePath, Bucket=bucketName, Key=imageName)
    print(f'Uploading {signaturePath=} to {bucketName=} with {signatureName=}')
    s3Client.upload_file(Filename=signaturePath,
                         Bucket=bucketName,
                         Key=signatureName)

    otaCertPath = cf.get('ota_certificate_path', str)

    # retrieve version of OTA binary
    version = s3Client.get_object(Bucket=bucketName,
                                  Key=imageName)['VersionId']
    del s3Client
    signature = SignatureInfo()
    signature.hashAlgorithm = cf.get('ota_hash_algorithm', str)
    signature.signatureAlgorithm = cf.get('ota_signature_algorithm', str)
    signature.signature = re.sub(r"\s+", "",
                                 open(signaturePath, 'rt').read()).encode()
    signature.signingCertificate = open(otaCertPath, 'rt').read()

    return _IoTOtaJobDoc(iot_services_client, _OtaType.ModuleFirmwareUpdate,
                         version, imageName, signature, thingArn)


def _ConfigureHostOTA(
        iot_services_client: IoTClient,
        sign: bool) -> tuple[bytes, _IoTOtaJobDoc, Optional[SignatureInfo]]:
    thingName: str
    thingName = pytest.expresslink_info['thing_name']  # typing: ignore
    thingArn: str = iot_services_client.describe_thing(
        thingName=thingName)['thingArn']

    bucket = cf.get('s3_bucket_name', str)
    key = 'HOTAImage.bin'
    s3: S3Client = boto3.client('s3')
    try:
        details = s3.get_object(Bucket=bucket, Key=key)
        with open(key, 'wb') as file:
            s3.download_fileobj(Bucket=bucket, Key=key, Fileobj=file)
        hotaUploaded: bytes = open(key, 'rb').read()
    # File doesn't exist yet
    except s3.exceptions.NoSuchKey:
        # Create and upload it
        print("Creating pseudorandom HOTA image binary.")
        random.seed(2222)
        hotaUploaded = random.randbytes(4096)
        with open(key, 'wb') as file:
            file.write(hotaUploaded)
        s3.upload_file(Filename=key, Bucket=bucket, Key=key)
        details = s3.get_object(Bucket=bucket, Key=key)
    finally:
        del s3

    signature: Optional[SignatureInfo]
    if sign:
        signatureAlgorithm = cf.get('ota_signature_algorithm', str)
        assert signatureAlgorithm in get_args(hota_setup.SIGNATURE_ALGORITHMS)
        hashingAlgorithm = cf.get('ota_hash_algorithm', str)
        keyWidth = cf.get('ota_key_width', int)
        assert hashingAlgorithm in get_args(hota_setup.HASH_ALGORITHMS)
        signature = hota_setup.GenerateSigningDetails(thingName, hotaUploaded,
                                                      signatureAlgorithm,
                                                      hashingAlgorithm,
                                                      keyWidth)
    else:
        signature = None

    return hotaUploaded, _IoTOtaJobDoc(iot_services_client,
                                       _OtaType.HostUpdate,
                                       details['VersionId'], key, signature,
                                       thingArn), signature


def _ReadWholeHostUpdate(hotaUploaded: bytes) -> bytes:
    hotaReceived: bytes = b''
    responsePattern = re.compile(
        r'^OK ([\dA-F]{1,6}) ([\dA-F]{2,8192}) ([\dA-F]{4})\r\n$')

    def processResponse(response: str) -> bool:
        if response == 'OK 0\r\n':
            return True
        match = responsePattern.match(response)
        assert match, response
        count, payload, checksum = match.groups()
        assert len(payload) % 2 == 0
        assert count == _toHex(len(payload) // 2)
        assert _toHex(sum(bytes.fromhex(payload)) % 2**16, width=4) == checksum
        nonlocal hotaReceived
        hotaReceived += bytes.fromhex(payload)
        return len(hotaReceived) >= len(hotaUploaded)

    def readSome() -> str:
        # Read as much from the HOTA as possible
        return cmd(f'AT+OTA READ {len(hotaUploaded) - len(hotaReceived)}\r\n')

    poll(readSome,
         max_tries=len(hotaUploaded),
         step=0.5,
         check_success=processResponse)

    return hotaReceived


def _WaitForJobCompletion(
        iot_services_client: IoTClient,
        awsIotJobId: str) -> DescribeJobExecutionResponseTypeDef:

    def verifyJobCompletion(
            jobExecution: DescribeJobExecutionResponseTypeDef) -> bool:
        print(jobExecution['execution'])
        return jobExecution['execution']['status'] not in {
            'IN_PROGRESS', 'QUEUED'
        }

    return poll(iot_services_client.describe_job_execution,
                kwargs={
                    'jobId': awsIotJobId,
                    'thingName': pytest.expresslink_info['thing_name']
                },
                step=10,
                timeout=120,
                check_success=verifyJobCompletion)


def _toHex(number: int, width: int = 0) -> str:
    """converts an int to hex str in
        the format the ExpressLink expects

        Examples:
            - `toHex(126)` == '7E'
            - `toHex(4444, width=4)` == '01BC'"""
    return hex(number)[2:].upper().zfill(width)


# The serial interface commands involved in the implementation of the OTA and Host OTA features are
# summarized here:
#
# 9.2       OTA commands
#
# 9.2.1     OTA? Fetches the current state of the OTA process
# Returns: OK {code} {detail}
#
# 9.2.2     OTA codes:
# 0 No OTA in progress
# 1 A new module OTA update is being proposed, the host can inspect the version
# number and decide to accept or reject it. The {detail} field provides the version
# (string) information
# 2 Host OTA update is being proposed, the host can inspect the version details and
# decide to accept or reject it. The {detail} field provides the metadata (string)
# that is entered by the operator.
# 3 OTA in progress, the download and signature verification steps are not
# completed yet
# 4 A new module firmware image has arrived, the signature has been verified and
# the ExpressLink module is ready to reboot. (Also, an event was generated)
# 5 A new host image has arrived, the signature has been verified and the
# ExpressLink module is ready to read its contents to the host. The size of the file
# is indicated in the response detail. (Also, an event was generated)


# Example 1:
# AT+OTA? check the OTA status
# OK 3 an OTA operation is in progress, the module OTA buffer is in use
# Example 2:
# AT+OTA? check the OTA status
# OK 1 v2.5.7 a module OTA firmware update is proposed
# NOTE: The host has the ultimate say to allow this update to proceed (downloading) by sending the OTA
# ACCEPT command or reject it immediately (if deemed incompatible with the host version) by sending
# the OTA FLUSH command.
#
# 9.2.3         OTA ACCEPT Allow the OTA operation to proceed
# The host allows the module to download a new image for the module or the host OTA.
# Tested by test_9_3_OtaUpdate, and test_9_9_HotaUpdate
#
# 9.2.3.1       Returns: OK
# A valid OTA request was pending, the host is allowing the OTA operation to commence
# Tested by test_9_3_OtaUpdate and test_9_9_HotaUpdate
#
# 9.2.3.2       Returns: ERR21 INVALID OTA UPDATE
# No OTA update was pending.
def test_9_2_3_2_OtaAcceptNoUpdate() -> None:
    assert cmd('AT+OTA ACCEPT\r\n') == 'ERR21 INVALID OTA UPDATE\r\n'


# Example:
# AT+OTA? Checking OTA state
# OK 0 No pending OTA request (host or module)
# AT+OTA ACCEPT Accept the OTA download
# ERR21 INVALID OTA UPDATE No OTA pending, nothing there for the host to “accept”

# 9.2.4         OTA READ #bytes Requests the next # bytes from the OTA buffer
# The read operation is designed to allow the host processor to retrieve the contents of the OTA
# buffer starting from the current position (initially starting from 0). The # bytes must be provided as
# a decimal value.
#
# 9.2.4.1       Returns: OK {count} ABABABAB... {checksum}
# The byte count is expressed in hex (from 1 to 6 digits), each byte is then presented as a pair of hex
# digits (no spaces) for a total of count*2 characters followed by a checksum (2 hex digits).
# The reading pointer is advanced by count bytes.
# Count can be less then requested or 0 if the end of payload was reached. If count is zero, the data
# and checksum portion will be omitted.
# The maximum #bytes a module can read is implementation specific and will be declared by the
# manufacturer in the device datasheet. If the requested value is greater than the maximum
# supported by the module, the module will return the maximum value possible.
# The checksum is provided as a 16-bit (4 digit hex value) computed as the sum of all data (byte)
# values returned (modulo 2^16).
# Tested by test_9_9_HotaUpdate


# 9.2.4.2       Return ERR19 HOST IMAGE NOT AVAILABLE
# An error is issued if the OTA buffer is empty or in use and the download/signature verification
# process is not completed. The host processor should first check the OTA status using the OTA?
# command.
def test_9_2_4_2_HotaReadNotReady():
    assert (cmd('AT+OTA READ 1\r\n')) == 'ERR19 HOST IMAGE NOT AVAILABLE\r\n'


# Example 1:
# AT+OTA READ 2 request 2 bytes of data from the OTA buffer
# OK 02 ABAB CK
# Example 2:
# AT+OTA READ 256 request 256 bytes of data from the OTA buffer
# OK 100 ABABAB....AB CK
# Example 3:
# AT+OTA READ 16 request 16 bytes of data from the OTA buffer
# OK 0C ABABAB.. CK reached the end of the OTA buffer, only 12 bytes were available
#
# 9.2.5         OTA SEEK {address} Moves the read pointer to an absolute address
# Moves the read pointer in the OTA buffer to the address specified within the OTA buffer. If no
# address is specified, the read pointer is moved back to the beginning (0). The # bytes must be
# provided as a decimal value.
# Returns:
# OK {address} if the pointer was successfully moved
# The address is returned in hex (from 1 to 6 digits),
@pytest.mark.slow
def test_9_2_5_HotaSeekRandomAccess(iot_services_client: IoTClient) -> None:
    assert cmd('AT+CONF HOTAcertificate=\r\n') == 'OK\r\n'
    # Ensure that OTA state is as clean as possible
    _CleanOtaJobs(iot_services_client)
    assert cmd('AT+OTA FLUSH\r\n') == 'OK\r\n'
    assert _getOTAStatus()[0] == _OtaCode.NoOtaInProgress

    hotaUploaded, otaJob, _ = _ConfigureHostOTA(iot_services_client,
                                                sign=False)

    # retrieve bytes from part of the payload in random order
    seed = int.from_bytes(os.urandom(8), byteorder='little')
    print(f'Random sampling with seed: {seed}')
    random.seed(seed)
    indices = list(range(len(hotaUploaded)))
    random.shuffle(indices)

    with otaJob:
        assert connect_with_retries(cf.get('personal_endpoint', str))
        # Wait for OTA event to arrive at device
        if get_next_event(r'^OK 5.*OTA\r\n$') is None:
            warnings.warn('OTA Event was not raised', RuntimeWarning)
        assert _getOTAStatus()[0] == _OtaCode.HostOtaUpdateAvailable

        assert cmd('AT+OTA ACCEPT\r\n') == 'OK\r\n'
        assert _pollDeviceOtaStatus(
            desiredCode=_OtaCode.OtaInProgress,
            allowedCodes=(_OtaCode.HostOtaUpdateAvailable, ),
            step=0.01,
            timeout=10)

        # Wait for OTA download to finish
        if get_next_event(r'^OK 5.*OTA\r\n$', timeout=600) is None:
            warnings.warn('OTA Event was not raised', RuntimeWarning)
        assert _pollDeviceOtaStatus(desiredCode=_OtaCode.HostOtaImageReady,
                                    allowedCodes=(_OtaCode.OtaInProgress, ),
                                    step=0.01,
                                    timeout=10)

        responsePattern = re.compile(
            r'^OK ([\dA-F]{1,6}) ([\dA-F]{2,8192}) ([\dA-F]{4})\r\n$')
        for i, index in enumerate(indices):
            assert cmd(f'AT+OTA SEEK {index}\r\n',
                       print_output=False) == f'OK {_toHex(index)}\r\n'
            match = re.match(responsePattern,
                             cmd('AT+OTA READ 1\r\n', print_output=False))
            assert match
            count, payload, checksum = match.groups()
            assert int(count) == 1
            assert len(payload) == 2
            assert payload == checksum[2:]
            assert _toHex(hotaUploaded[index], width=2) == payload
            if i % 16 == 0:
                print(end='.', flush=True)
        print()


@pytest.mark.slow
def test_9_2_5_HotaSeekBeginning(iot_services_client: IoTClient) -> None:
    """Retrieves the same HOTA image from device multiple times."""
    # Ensure that OTA state is as clean as possible
    assert cmd('AT+CONF HOTAcertificate=\r\n') == 'OK\r\n'
    _CleanOtaJobs(iot_services_client)
    assert cmd('AT+OTA FLUSH\r\n') == 'OK\r\n'
    assert _getOTAStatus()[0] == _OtaCode.NoOtaInProgress

    assert connect_with_retries(cf.get('personal_endpoint', str))

    hotaUploaded, otaJob, _ = _ConfigureHostOTA(iot_services_client,
                                                sign=False)

    with otaJob:
        # Wait for OTA event to arrive at device
        if get_next_event(r'^OK 5.*OTA\r\n$') is None:
            warnings.warn('OTA Event was not raised', RuntimeWarning)
        assert _getOTAStatus()[0] == _OtaCode.HostOtaUpdateAvailable

        assert cmd('AT+OTA ACCEPT\r\n') == 'OK\r\n'
        assert _pollDeviceOtaStatus(
            desiredCode=_OtaCode.OtaInProgress,
            allowedCodes=(_OtaCode.HostOtaUpdateAvailable, ),
            step=0.01,
            timeout=10)

        # Wait for OTA download to finish
        if get_next_event(r'^OK 5.*OTA\r\n$', timeout=600) is None:
            warnings.warn('OTA Event was not raised', RuntimeWarning)
        assert _pollDeviceOtaStatus(desiredCode=_OtaCode.HostOtaImageReady,
                                    allowedCodes=(_OtaCode.OtaInProgress, ),
                                    step=0.01,
                                    timeout=10)
        assert hotaUploaded == _ReadWholeHostUpdate(hotaUploaded)
        for command in ('AT+OTA SEEK\r\n', 'AT+OTA SEEK 0\r\n'):
            assert cmd(command) == 'OK 0\r\n'
            assert hotaUploaded == _ReadWholeHostUpdate(hotaUploaded)


# 9.2.5.1       Returns ERR20 INVALID ADDRESS
# if the address provided was out of bounds (> OTA buffer content size)
@pytest.mark.slow
def test_9_2_5_1_HotaSeekInvalidAddress(
        iot_services_client: IoTClient) -> None:
    _CleanOtaJobs(iot_services_client)
    assert cmd('AT+CONF HOTAcertificate=\r\n') == 'OK\r\n'
    assert cmd('AT+OTA FLUSH\r\n') == 'OK\r\n'
    assert _getOTAStatus()[0] == _OtaCode.NoOtaInProgress

    assert connect_with_retries(cf.get('personal_endpoint', str))

    hotaUploaded, otaJob, _ = _ConfigureHostOTA(iot_services_client,
                                                sign=False)

    with otaJob:
        # Wait for OTA event to arrive at device
        if get_next_event(r'^OK 5.*OTA\r\n$') is None:
            warnings.warn('OTA Event was not raised', RuntimeWarning)
        assert _getOTAStatus()[0] == _OtaCode.HostOtaUpdateAvailable

        assert cmd('AT+OTA ACCEPT\r\n') == 'OK\r\n'
        assert _pollDeviceOtaStatus(
            desiredCode=_OtaCode.OtaInProgress,
            allowedCodes=(_OtaCode.HostOtaUpdateAvailable, ),
            step=0.01,
            timeout=10)

        # Wait for OTA download to finish
        if get_next_event(r'^OK 5.*OTA\r\n$', timeout=600) is None:
            warnings.warn('OTA Event was not raised', RuntimeWarning)
        assert _pollDeviceOtaStatus(desiredCode=_OtaCode.HostOtaImageReady,
                                    allowedCodes=(_OtaCode.OtaInProgress, ),
                                    step=0.01,
                                    timeout=10)

        assert cmd(f'AT+OTA SEEK {len(hotaUploaded) + 1}\r\n'
                   ) == 'ERR20 INVALID ADDRESS\r\n'


# 9.2.5.2       Returns ERR19 HOST OTA IMAGE NOT AVAILABLE
# An error is issued if the OTA buffer is empty or in use and the download/signature
# verification process is not completed. The host processor should first check the OTA status
# using the OTA? command.
def test_9_2_5_2_HotaSeekNotReady():
    assert (cmd('AT+OTA SEEK 0\r\n')) == 'ERR19 HOST IMAGE NOT AVAILABLE\r\n'
    assert (cmd('AT+OTA SEEK\r\n')) == 'ERR19 HOST IMAGE NOT AVAILABLE\r\n'


#
# Example 1:
# AT+OTA SEEK 1024 move the read pointer to location 1024
# OK 400
# Example 2:
# AT+OTA SEEK move the read pointer back to location 0
# OK 0

# 9.2.6         OTA APPLY Authorize the ExpressLink module to apply the new image.
# When an ExpressLink module OTA image has been downloaded and is ready to be applied, the host
# processor is notified by an event. When appropriate (safe for the application) the host processor
# can issue the OTA APPLY command to initiate the module re-boot process to update the module
# firmware version. Upon completion, the OTA buffer is emptied making it available for additional
# OTA operations. The OTA status is cleared.
#
# 9.2.6.1       Return: OK The module has initiated a boot sequence
# tested by test_9_3_OtaUpdate since this requires exercising the entirety of ExpressLink OTA


# 9.2.6.2       Return: ERR19 HOST IMAGE NOT AVAILABLE
# An error is issued if the OTA buffer is empty or in use and the download/signature
# verification process is not completed. The host processor should first check the OTA status
# using the OTA? command.
def test_9_2_6_2_OtaApplyNotReady() -> None:
    assert cmd('AT+OTA APPLY\r\n') == 'ERR19 HOST IMAGE NOT AVAILABLE\r\n'


# 9.2.6.3 Return: ERR21 INVALID OTA UPDATE The module is unable to apply the new module
# images (integrity issue or version incompatibility).
# Untested:  The validity of an OTA image is implementation and platform-specific
#
# 9.2.6.4 Return: ERR23 INVALID SIGNATURE The new image signature check failed
# Untested: Such a test require generating an additional signing key...
#
# 9.2.6.5       Upon successful completion of the boot sequence the ExpressLink module will
# communicate to the AWS IoT OTA service the new status and fw revision number.
# Tested by test_9_3_OtaUpdate
#
# 9.2.6.6       Also, the event queue is emptied and a STARTUP event will be generated to inform the
# host processor of the process completion.
# Tested by test_9_3_OtaUpdate
#
# 9.2.6.7       All state and configuration parameters of the module should be expected to be reset
# similarly to a Reset command (although additional changes may apply implementation and
# firmware version dependent).
# Untestable due to implementation-specific behavior.
#
# 9.2.7         OTA CLOSE The host OTA operation is completed
# The host use of the OTA buffer is terminated and the buffer can be released. The OTA flag is cleared
# and the operation is reported to AWS IoT Core as successfully completed.
# Covered by test_9_9_HotaUpdate
#
# 9.2.7.1       Returns: OK
# Note The ExpressLink module OK return value will indicate the command was received correctly,
# but the actual execution sequence (requiring handshake with the AWS IoT OTA service) can still fail
# at a later time. In that case an event will be generated to inform the host and help diagnose the
# problem.
def test_9_2_7_1_OtaCloseReturnsOk() -> None:
    assert cmd('AT+OTA CLOSE\r\n') == 'OK\r\n'


# 9.2.8         OTA FLUSH The contents of the OTA buffer are emptied
# The OTA buffer is immediately released. The OTA flag is cleared. Any pending OTA operation is
# aborted. The OTA operation is reported as failed.
@pytest.mark.slow
# TODO: Support custom flows
@pytest.mark.skipif(cf.get('feature_custom_ota', bool),
                    reason='Custom OTA flow')
def test_9_2_8_OtaFlushAllStates(iot_services_client: IoTClient) -> None:
    _CleanOtaJobs(iot_services_client)
    assert cmd('AT+OTA FLUSH\r\n') == 'OK\r\n'
    assert _getOTAStatus()[0] == _OtaCode.NoOtaInProgress

    def checkedFlush(awsIotJobId: str):
        assert cmd('AT+OTA FLUSH\r\n') == 'OK\r\n'
        assert _WaitForJobCompletion(
            iot_services_client,
            awsIotJobId)['execution']['status'] not in ('QUEUED', 'SUCCEEDED',
                                                        'IN_PROGRESS')
        assert _getOTAStatus()[0] == _OtaCode.NoOtaInProgress

    connect_with_retries(cf.get('personal_endpoint', str))

    for testState in (_OtaCode.OtaUpdateAvailable, _OtaCode.OtaInProgress,
                      _OtaCode.OtaImageReady):
        with _ConfigureModuleOTA(iot_services_client) as otaJob:
            # Wait for OTA event to arrive at device
            if get_next_event(r'^OK 5 [^0]+ OTA\r\n$') is None:
                warnings.warn('OTA Event was not raised', RuntimeWarning)
            assert _getOTAStatus()[0] == _OtaCode.OtaUpdateAvailable

            if testState == _OtaCode.OtaUpdateAvailable:
                checkedFlush(otaJob.otaJobResponse['awsIotJobId'])
                otaJob.cleanup = False
                continue

            # Accept OTA, see that it starts
            assert cmd('AT+OTA ACCEPT\r\n') == 'OK\r\n', 'Fails '
            assert _pollDeviceOtaStatus(
                desiredCode=_OtaCode.OtaInProgress,
                allowedCodes=(_OtaCode.OtaUpdateAvailable, ),
                step=0.01,
                timeout=10)

            if testState == _OtaCode.OtaInProgress:
                time.sleep(5)
                checkedFlush(otaJob.otaJobResponse['awsIotJobId'])
                otaJob.cleanup = False
                continue

            # Wait for device to download binary and ready to apply
            if get_next_event(r'^OK 5.*OTA\r\n$', timeout=600) is None:
                warnings.warn('OTA Event was not raised', RuntimeWarning)
            assert _pollDeviceOtaStatus(
                desiredCode=_OtaCode.OtaImageReady,
                allowedCodes=(_OtaCode.OtaInProgress, ),
                step=0.01,
                timeout=10)

            checkedFlush(otaJob.otaJobResponse['awsIotJobId'])
            otaJob.cleanup = False


@pytest.mark.slow
def test_9_2_8_HotaUpdateFlushAllStates(
        iot_services_client: IoTClient) -> None:
    assert cmd('AT+CONF HOTAcertificate=\r\n') == 'OK\r\n'
    _CleanOtaJobs(iot_services_client)
    assert cmd('AT+OTA FLUSH\r\n') == 'OK\r\n'
    assert _getOTAStatus()[0] == _OtaCode.NoOtaInProgress

    def checkedFlush(awsIotJobId: str):
        assert cmd('AT+OTA FLUSH\r\n') == 'OK\r\n'
        assert _WaitForJobCompletion(
            iot_services_client,
            awsIotJobId)['execution']['status'] not in ('QUEUED', 'SUCCEEDED',
                                                        'IN_PROGRESS')
        assert _getOTAStatus()[0] == _OtaCode.NoOtaInProgress

    connect_with_retries(cf.get('personal_endpoint', str))

    for testState in (_OtaCode.HostOtaUpdateAvailable, _OtaCode.OtaInProgress,
                      _OtaCode.HostOtaImageReady):
        _, otaJob, _ = _ConfigureHostOTA(iot_services_client, sign=False)
        with otaJob:
            # Wait for OTA event to arrive at device
            if get_next_event(r'^OK 5 [^0]+ OTA\r\n$') is None:
                warnings.warn('OTA Event was not raised', RuntimeWarning)
            assert _getOTAStatus()[0] == _OtaCode.HostOtaUpdateAvailable

            if testState == _OtaCode.HostOtaUpdateAvailable:
                checkedFlush(otaJob.otaJobResponse['awsIotJobId'])
                otaJob.cleanup = False
                continue

            # Accept OTA, see that it starts
            assert cmd('AT+OTA ACCEPT\r\n') == 'OK\r\n', 'Fails '
            assert _pollDeviceOtaStatus(
                desiredCode=_OtaCode.OtaInProgress,
                allowedCodes=(_OtaCode.HostOtaUpdateAvailable, ),
                step=0.01,
                timeout=10)

            if testState == _OtaCode.OtaInProgress:
                checkedFlush(otaJob.otaJobResponse['awsIotJobId'])
                otaJob.cleanup = False
                continue

            # Wait for device to download binary and ready to apply
            if get_next_event(r'^OK 5.*OTA\r\n$', timeout=600) is None:
                warnings.warn('OTA Event was not raised', RuntimeWarning)
            assert _pollDeviceOtaStatus(
                desiredCode=_OtaCode.HostOtaImageReady,
                allowedCodes=(_OtaCode.OtaInProgress, ),
                step=0.01,
                timeout=10)

            checkedFlush(otaJob.otaJobResponse['awsIotJobId'])
            otaJob.cleanup = False


# 9.2.8.1       Returns: OK
# Note The ExpressLink module OK return value will indicate the command was received correctly,
# but the actual execution sequence (requiring handshake with the AWS IoT OTA service) can still fail
# at a later time. In that case an event will be generated to inform the host and help diagnose the
# problem.
def test_9_2_8_1_OtaFlushReturnsOk() -> None:
    assert cmd('AT+OTA FLUSH\r\n') == 'OK\r\n'


# 9.3       OTA Update Jobs
# OTA updates are meant to be issued by customers’ fleet managers through the AWS cloud console using
# the AWS IoT OTA Update Manager service. This is built upon the AWS IoT Jobs service and is designed to
# allow customers to send updates to selected groups of devices in a fleet. (see
# https://docs.aws.amazon.com/freertos/latest/userguide/ota-mqtt-freertos.html)
# The OTA service has the following basic requirements:
# 1. Each device must be associated with a policy allowing it to publish and subscribe to the AWS
# reserved topics for streams/* and jobs/*. Note how this policy will be automatically added to
# the thing created in the staging account (see JITP template) and later moved to customer
# account by means of the AWS IoT API.
# 2. An S3 bucket will be created by the customer to hold the firmware update file (downloaded
# from the manufacturer’s support web page)
# 3. An OTA update role will be created by the customer to allow the service to operate in the
# account
# 4. The operator initiating the update process must have an OTA User policy to authorize them to
# operate the service
# The OTA Job creation can then be instantiated from the AWS CLI or from the AWS IoT Console.
# OTA Jobs service is generic and can transfer (stream) any type of file to a selected group of devices.
# Meta-data is provided by the user and transferred to the ExpressLink module in the form a JSON string
# to communicate the nature of the incoming OTA payload, signing method (if used) and a number of
# additional options.
# Specifically, ExpressLink devices will require the fileType attribute to be set to values according to Table
# 5.
# Table 5 – Reserved OTA file type codes (0-255)
# fileType | Reserved for...                | Signed   | Certificate Req. | Host Permission?
#  101     | Module firmware update         | Required | Module OTA       | Y
#  103     | Module OTA certificate update  | Self¹    | Module OTA       | N
#  107     | Server Root certificate update | Self¹    | Server Root      | N
#  202     | Host update                    | Optional | Host OTA         | N
#  204     | Host OTA certificate update    | Self¹    | Host OTA         | N
# These codes will allow the receiving ExpressLink modules to discriminate and initiate the corresponding
# module or host update process as described in 9.2.2. Note how different signing rules apply to each type
# of update/file and how the certificates used for the validation of the signatures can themselves be
# updated.
# ¹ - Certificates are already hashed and signed. No additional signing is required.
@pytest.mark.destructive
@pytest.mark.slow
# TODO: Support custom flows
@pytest.mark.skipif(cf.get('feature_custom_ota', bool),
                    reason='Custom OTA flow')
@pytest.hookimpl(trylast=True)
def test_9_3_OtaUpdate(iot_services_client: IoTClient) -> None:
    """Overwrites existing firmware with a module firmware OTA update."""
    # Ensure that OTA state is as clean as possible
    _CleanOtaJobs(iot_services_client)
    assert cmd('AT+OTA FLUSH\r\n') == 'OK\r\n'
    assert _getOTAStatus()[0] == _OtaCode.NoOtaInProgress

    oldVersion: str = cmd('AT+CONF? Version\r\n')[3:-2]

    assert connect_with_retries(cf.get('personal_endpoint', str))
    with _ConfigureModuleOTA(iot_services_client) as otaJob:
        # Wait for OTA event to arrive at device
        if get_next_event(r'^OK 5.*OTA\r\n$') is None:
            warnings.warn('OTA Event was not raised', RuntimeWarning)
        assert _getOTAStatus()[0] == _OtaCode.OtaUpdateAvailable

        # Accept OTA, see that it starts
        assert cmd('AT+OTA ACCEPT\r\n') == 'OK\r\n'
        assert _pollDeviceOtaStatus(
            desiredCode=_OtaCode.OtaInProgress,
            allowedCodes=(_OtaCode.OtaUpdateAvailable, ),
            step=0.01,
            timeout=10)

        # Wait for device to download binary and ready to apply
        if get_next_event(r'^OK 5.*OTA\r\n$', timeout=600) is None:
            warnings.warn('OTA Event was not raised', RuntimeWarning)
        assert _pollDeviceOtaStatus(desiredCode=_OtaCode.OtaImageReady,
                                    allowedCodes=(_OtaCode.OtaInProgress, ),
                                    step=0.01,
                                    timeout=10)

        # Apply the update
        assert cmd('AT+OTA APPLY\r\n') == 'OK\r\n'

        # Wait for device startup
        if get_next_event(r'^OK.*STARTUP\r\n$') is None:
            warnings.warn(
                "Device did not generate startup event after OTA APPLY.",
                RuntimeWarning)

        assert _getOTAStatus()[0] == _OtaCode.NoOtaInProgress

        # TODO: not covered by this spec, but the device should be responsible
        # for completing the self-test with IoT Core after +OTA APPLY
        assert connect_with_retries(cf.get('personal_endpoint', str))

        otaStatus = _WaitForJobCompletion(iot_services_client,
                                          otaJob.otaJobResponse['awsIotJobId'])

        otaJob.cleanup = False
        assert otaStatus['execution']['status'] == 'SUCCEEDED'
        assert cmd('AT+CONF? Version\r\n') != f'OK {oldVersion}\r\n'


# 9.4       Module OTA Image Signing
# ExpressLink module manufacturers may create a new profile with the AWS Code Signing service
# (https://docs.aws.amazon.com/signer/latest/developerguide/Welcome.html) for each ExpressLink
# module model they qualify and introduce to production. This profile will then be used exclusively to sign
# images before distributing them to their customer base (publishing them on a dedicated manufacturer
# support web page).
# See the OTA update with AWS CLI guide for a complete workflow detailing all steps required for the
# generation of signed image at https://docs.aws.amazon.com/freertos/latest/userguide/ota-cli-
# workflow.html
# ExpressLink manufacturers are free to choose any signature and hashing algorithms compatible with
# AWS IoT Core specifications to best match the cryptographic capabilities of their modules.
#
# 9.5 Module OTA Signature Verification
# In order for ExpressLink modules to validate module OTA updates, they must be provided (at time of
# manufacturing) with an OTA certificate (containing the public key) corresponding to the private key that
# was used by the manufacturer to sign the update image files.
# Module OTA certificates are not secrets and therefore are not required to reside in the secure key
# storage of the module, but must be stored “independently” of the module binary image, in a separate
# non-volatile memory partition, or simply at a reserved address that is not overwritten during the OTA
# update process. If the module OTA certificate was statically linked in (part of) the binary module image,
# it would become impossible for customers to skip updates, forcing a strictly continuous sequence as
# each new signature might depend on a new certificate possibly included in one (or each) of the previous
# updates.
# Module OTA jobs will include additional meta-data to clearly identify the modules manufacturer, model,
# version major and minor to allow the ExpressLink executive to discard incorrect OTA images ahead of
# time, preventing the costly and lengthy download altogether.
# Note how this meta-data is input by customer’s dev-op at time of Job creation and could therefore be
# incorrectly associated with a firmware update file meant for an incompatible model from the same
# vendor. The use of a unique signature profile per model recommended in chapter 9.4 acts as an
# additional safeguard to ensure that incompatible binary images will be eventually rejected and the
# update aborted as a “signature check failure” preventing potentially disastrous consequences.
#
# 9.6           Module OTA certificate updates
# The certificates used for the module OTA signature validation (not to be confused with the module birth
# certificate used to authenticate with AWS cloud). Module OTA certificates may be updated via OTA mechanism
# or via the serial
# API:
# • Module OTA certificate updates performed via OTA will use the fileType code indicated in Table
# 5 (Module OTA cert update).
# • Module OTA certificate updates performed via the AT+CONF command using the key OTAcertificate
# Example: AT+CONF OTAcertificate=<x509.pem>²
# ² Some escaping required to accommodate newlines present in the certificate (.pem) file.
#
# 9.6.1.1       Return: OK if the new certificate was valid
def test_9_6_1_1_OtaCertificateSelfAssign() -> None:
    """Demonstrates that a self-signed certificate may be reflexively assigned"""
    certificate = open(cf.get('ota_certificate_path', str),
                       'rt').read().replace('\n', '\r\n')
    response = _SetCertificatePem('OTAcertificate', certificate)
    assert response == 'OK\r\n'


# 9.6.1.2       Return: ERR23 INVALID SIGNATURE the new certificate could not be verified
def test_9_6_1_2_OtaCertificateInvalidSignature() -> None:
    """Try setting OTA cert to a cert not self-signed for OTA
       May overwrite the OTA cert with the RootCA..."""
    certificate = open('AmazonRootCA1.pem', 'rt').read().replace('\n', '\r\n')
    response = _SetCertificatePem('OTAcertificate', certificate)
    assert response == 'ERR23 INVALID SIGNATURE\r\n'


# 9.6.1.3       The new certificate must be signed with the private key corresponding to the previous
# valid module OTA certificate.
# Testing requires a valid new certificate
#
# TODO: Verify these requirements with 3 certificates, including the provisioned certificate
# All three certificates shall be signed using the same private key
# Therefore, all three certificates shall be rotated using any other certificate
#
# 9.6.1.4       Module OTA certificates updates performed via the OTA mechanism do not require the
# host to accept the update nor to control its execution timing.
# Not tested by this suite.
#
# Verifiable by the following:
# Provision the device with Certificate A
# Initiate Module OTA Certificate update for Certificate B
# See success result externally from endpoint
#
# 9.6.1.5       Module OTA certificates are NOT affected upon a Factory Reset
# Not tested by this suite
#
# Verifiable by the following:
# Provision the device with Certificate A
# Factory Reset the device
# Update the module OTA certificate to Certificate B
# using the OTAcertificate CONF variable
#
# 9.6.1.6       Return: ERR26 INVALID CERTIFICATE
# the new certificate provided was invalid or corrupted.
def test_9_6_1_6_OtaCertificateSetInvalidCertificate() -> None:
    """This test may irreversibly destroy the OTA certificate if overwritten"""
    invalidCert = '-----BEGIN CERTIFICATE-----\r\n' + (
        'a' * 1024) + '\r\n-----END CERTIFICATE-----\r\n'
    response = _SetCertificatePem('OTAcertificate', invalidCert)
    assert response == 'ERR26 INVALID CERTIFICATE\r\n'


# 9.7           Module OTA override
# As described earlier in section 9.1.1.1, the host processor is given ultimate control over the ExpressLink
# module firmware update process, accepting or rejecting an incoming image, and controlling its
# execution start. While this mechanism is meant to prevent scenarios where host and module firmware
# versions could become incompatible or the module reboot could happen at an inconvenient time
# possibly affecting the device functional safety, we must consider cases where a poorly behaved (or too
# basic) host application might prevent indefinitely an ExpressLink module from being updated to fix a
# critical bug or identified security threat. To this end an additional piece of meta-data using the attribute
# <force:YES> will be provided to bypass the host control and to activate an immediate module firmware
# update.
# NOTE: A forced module OTA update will claim the module OTA buffer (bulk memory) erasing all its
# contents potentially including a host payload previously occupying this memory. This is an extremely
# invasive operation and as such should be used only when strictly necessary and with the customer full
# understanding of its implications for the host application.
#
# 9.8           Synchronized Module and Host update sequence
# When new capabilities or API changes be introduced by a new ExpressLink module firmware version
# with potentially backward compatibility (side-effects) affecting the host application, the following
# recommended update sequence should be applied:
# 1. The Manufacturer publishes the new module image (and documents the incompatibilities)
# 2. Customer evaluates opportunity to apply the update to their fleet and impact on host
# application
# 3. Customer develops a new host application with old and new ExpressLink module support
# 4. A host firmware OTA update is sent to (and accepted by) the host.
# 5. After rebooting, the host can verify the module current version.
# 6. An OTA module update must then be offered to the (new) host
# 7. The new host can validate the proposed new module version and “allow” the module update
# 8. The new host can then switch to the new module API or start using the new feature
# Should the host and module fail to stay in step with the above sequence, it can be terminated at any
# point without irreversible consequences and restarted.
#
# 9.9           Host OTA updates
# Host application updates can be sent to an ExpressLink module using the same OTA mechanisms used
# for the module own OTA updates. Thanks to the host OTA feature, ExpressLink modules provide two
# important services:
# 1. Transport and reconstruct a potentially large payload into the OTA buffer (bulk memory space
# inside the module) making it available for retrieval to the host in small increments optimizing
# the host memory resources. Note how the payload could be of any nature (i.e., pictures, sounds,
# video) and could in fact be a bundle itself, composed of multiple files concatenated.
# 2. Perform an authenticity check, relieving the host of the heavy cryptographical effort required to
# hash and verify a cryptographical signature.
# Note how the second feature is optional in this case as a host application might perform integrity
# and authenticity checks on its own, using secrets not accessible to the ExpressLink module or using
# any custom defined protocol.
@pytest.mark.slow
def test_9_9_HotaUpdate(iot_services_client: IoTClient) -> None:
    assert cmd('AT+CONF HOTAcertificate=\r\n') == 'OK\r\n'
    # Ensure that OTA state is as clean as possible
    _CleanOtaJobs(iot_services_client)
    assert cmd('AT+OTA FLUSH\r\n') == 'OK\r\n'
    assert _getOTAStatus()[0] == _OtaCode.NoOtaInProgress

    assert connect_with_retries(cf.get('personal_endpoint', str))

    hotaUploaded, otaJob, _ = _ConfigureHostOTA(iot_services_client,
                                                sign=False)
    with otaJob:
        # Wait for OTA event to arrive at device
        if get_next_event(r'^OK 5.*OTA\r\n$') is None:
            warnings.warn('OTA Event was not raised', RuntimeWarning)
        assert _getOTAStatus()[0] == _OtaCode.HostOtaUpdateAvailable

        assert cmd('AT+OTA ACCEPT\r\n') == 'OK\r\n'
        assert _pollDeviceOtaStatus(
            desiredCode=_OtaCode.OtaInProgress,
            allowedCodes=(_OtaCode.HostOtaUpdateAvailable, ),
            step=0.01,
            timeout=10)

        # Wait for OTA download to finish
        if get_next_event(r'^OK 5.*OTA\r\n$', timeout=600) is None:
            warnings.warn('OTA Event was not raised', RuntimeWarning)
        assert _pollDeviceOtaStatus(desiredCode=_OtaCode.HostOtaImageReady,
                                    allowedCodes=(_OtaCode.OtaInProgress, ),
                                    step=0.01,
                                    timeout=10)

        hotaReceived = _ReadWholeHostUpdate(hotaUploaded)

        assert cmd('AT+OTA CLOSE\r\n') == 'OK\r\n'

        otaStatus = _WaitForJobCompletion(iot_services_client,
                                          otaJob.otaJobResponse['awsIotJobId'])

        otaJob.cleanup = False
        assert otaStatus['execution']['status'] == 'SUCCEEDED'
        assert hotaUploaded == hotaReceived


# 9.10          Host OTA Signature Verification
# Meta-data provided during the OTA Job creation provides indication to the module of the optional
# signature verification requirement.
# A host OTA certificate containing the public key corresponding to the customer private host OTA signing
# key, may be provided by the customer.
# The certificates used for the host OTA signature validation are accessible for reading via the serial API
# (see CONF? command).
@pytest.mark.slow
def test_9_10_HostUpdateInvalidSigning(iot_services_client: IoTClient) -> None:
    # It is impossible for the OTA service account to sign an HOTA binary
    # with this Root CA
    root_certificate = open('AmazonRootCA1.pem',
                            'rt').read().replace('\n', '\r\n')
    assert cmd(
        f'AT+CONF HOTAcertificate=pem\r\n{root_certificate}\r\n') == 'OK\r\n'

    # Ensure that OTA state is as clean as possible
    _CleanOtaJobs(iot_services_client)
    assert cmd('AT+OTA FLUSH\r\n') == 'OK\r\n'
    assert _getOTAStatus()[0] == _OtaCode.NoOtaInProgress

    assert connect_with_retries(cf.get('personal_endpoint', str))

    hotaUploaded, otaJob, _ = _ConfigureHostOTA(iot_services_client, sign=True)
    with otaJob:
        # Wait for OTA event to arrive at device
        if get_next_event(r'^OK 5.*OTA\r\n$') is None:
            warnings.warn('OTA Event was not raised', RuntimeWarning)
        assert _getOTAStatus()[0] == _OtaCode.HostOtaUpdateAvailable

        assert cmd('AT+OTA ACCEPT\r\n') == 'OK\r\n'
        assert _pollDeviceOtaStatus(
            desiredCode=_OtaCode.OtaInProgress,
            allowedCodes=(_OtaCode.HostOtaUpdateAvailable, ),
            step=0.01,
            timeout=10)

        # Wait for OTA download to finish, and for signature to be rejected
        if get_next_event(r'^OK 5.*OTA\r\n$', timeout=600) is None:
            warnings.warn('OTA Event was not raised', RuntimeWarning)
        assert _pollDeviceOtaStatus(desiredCode=_OtaCode.NoOtaInProgress,
                                    allowedCodes=(_OtaCode.OtaInProgress, ),
                                    step=0.01,
                                    timeout=10)

        completion = _WaitForJobCompletion(
            iot_services_client, otaJob.otaJobResponse['awsIotJobId'])
        otaJob.cleanup = False
        assert completion['execution']['status'] != 'SUCCEEDED'

        assert cmd('AT+OTA READ 1\r\n') == 'ERR19 HOST IMAGE NOT AVAILABLE\r\n'
        assert cmd('AT+OTA SEEK\r\n') == 'ERR19 HOST IMAGE NOT AVAILABLE\r\n'


@pytest.mark.slow
@pytest.mark.skipif(cf.get_or_none('ota_signature_algorithm', str) != 'ECDSA',
                    reason='Test only supports ECDSA')
def test_9_10_HotaValidSigning(iot_services_client: IoTClient) -> None:
    # Ensure that OTA state is as clean as possible
    _CleanOtaJobs(iot_services_client)
    assert cmd('AT+OTA FLUSH\r\n') == 'OK\r\n'
    assert _getOTAStatus()[0] == _OtaCode.NoOtaInProgress

    assert connect_with_retries(cf.get('personal_endpoint', str))

    hotaUploaded, otaJob, signingInfo = _ConfigureHostOTA(iot_services_client,
                                                          sign=True)
    assert signingInfo is not None
    hotaCert = signingInfo.signingCertificate.replace('\n', '\r\n')
    assert cmd(f'AT+CONF HOTAcertificate=pem\r\n{hotaCert}') == 'OK\r\n'
    with otaJob:
        # Wait for OTA event to arrive at device
        if get_next_event(r'^OK 5.*OTA\r\n$') is None:
            warnings.warn('OTA Event was not raised', RuntimeWarning)
        assert _getOTAStatus()[0] == _OtaCode.HostOtaUpdateAvailable

        assert cmd('AT+OTA ACCEPT\r\n') == 'OK\r\n'
        assert _pollDeviceOtaStatus(
            desiredCode=_OtaCode.OtaInProgress,
            allowedCodes=(_OtaCode.HostOtaUpdateAvailable, ),
            step=0.01,
            timeout=10)

        # Wait for OTA download to finish, and for signature to be rejected
        if get_next_event(r'^OK 5.*OTA\r\n$', timeout=600) is None:
            warnings.warn('OTA Event was not raised', RuntimeWarning)
        assert _pollDeviceOtaStatus(desiredCode=_OtaCode.HostOtaImageReady,
                                    allowedCodes=(_OtaCode.OtaInProgress, ),
                                    step=0.01,
                                    timeout=10)

        hotaReceived = _ReadWholeHostUpdate(hotaUploaded)

        assert cmd('AT+OTA CLOSE\r\n') == 'OK\r\n'

        completion = _WaitForJobCompletion(
            iot_services_client, otaJob.otaJobResponse['awsIotJobId'])
        otaJob.cleanup = False
        assert completion['execution']['status'] == 'SUCCEEDED'

        assert hotaReceived == hotaUploaded


# 9.11          Host OTA certificate update
# The host OTA certificate can be updated via AT+CONF command by
# the customer (OEM) at the end of the product assembly line or later via the OTA mechanism using the
# code indicated in Table 5 (host OTA certificate update).
# Host OTA certificates updates performed via the OTA mechanism do not require the host to accept the
# update nor to control its execution timing.
# The host OTA certificate is a configuration parameter initially undefined (empty) and cleared at factory
# reset.
# When the host OTA certificate is undefined, the signature verification of an incoming (first) host OTA
# certificate payload cannot and will NOT be verified.
#
# 9.11.1        CONF? {certificate} pem Special certificate output formatting option
# The special qualifier pem can be appended to read a certificate configuration dictionary key (i.e.,
# Certificate, OTAcertificate, HOTAcertificate, RootCA) producing an output format that allows the
# developer to cut and paste directly the output into a standard .pem file for later upload to the AWS IoT
# dashboard.
# Note: the response to this command is an exception to the general format described in 4.6.1 by
# producing more than one output line.
# Example: AT+CONF? HOTAcertificate pem{eol}
_CertificateKey = Literal['HOTAcertificate', 'OTAcertificate', 'Certificate',
                          'RootCA']


def _GetCertificatePem(key: _CertificateKey, pem: str = 'pem') -> str:
    match = re.match(r'^OK(\d+) pem\r\n$', cmd(f'AT+CONF? {key} {pem}\r\n'))
    assert match, 'Unexpected response format'
    lineCount = int(match.groups()[0])
    if lineCount == 0:
        return ''

    response: str = ''

    def checkResponse(part: str) -> bool:
        nonlocal response
        nonlocal lineCount
        response += part
        print(end=part, flush=True)
        lineCount -= part.count('\n')
        return lineCount <= 0

    try:
        poll(comms.read_device,
             check_success=checkResponse,
             timeout=120,
             step=0)
    except TimeoutException:
        pytest.fail('Too few lines received')

    assert lineCount == 0, 'Too many lines received'

    return response


# 9.11.1.1      Return: OK# pem{eol} return a number (#) of additional lines composing the certificate
def test_9_11_1_1_OtaCertificateGetPem() -> None:
    # Field empty after factory reset, so provision device...
    assert _GetCertificatePem('HOTAcertificate') == ''
    certificate = open(cf.get('ota_certificate_path', str)).read()
    if '\r\n' not in certificate:
        certificate = certificate.replace('\n', '\r\n').replace(r'\A', '\r\n')
    assert cmd(f'AT+CONF HOTAcertificate=pem\r\n{certificate}') == 'OK\r\n'

    # For all certs, check that they cleanly return a certificate
    # Compare output against the escaped format
    keys: list[_CertificateKey] = ['HOTAcertificate', 'Certificate', 'RootCA']
    for key in keys:
        # Test that getting certificate is clean
        pem: str = _GetCertificatePem(key)
        linesPem: list[str] = pem.split('\r\n')
        # test that each line of the output is identical to the default, escaped format
        linesEscaped: list[str] = cmd(f'AT+CONF? {key}\r\n')[3:-2].split(r'\A')
        assert linesPem == linesEscaped, f'Output mismatch for {key} pem and non-pem'


# -----BEGIN CERTIFICATE-----{eol}
# MIIDWTCCAkGgAwIBAgIUeKvfYpklvnnattQF09ug9UULjZwwDQYJKoZIhvcNAQEL{eol}
# BQAwTTFLMEkGA1UECwxCQW1hem9uIFdlYiBTZXJ2aWNlcyBPPUFtYXpvbi5jb20g{eol}
# ...
# KHiN1yooauYJKaKr5eJilRAhdYsV2t9X3EFD60/eKmZyD+NE68jAwK/OvokhIGms{eol}
# cZAj8m0QwqvPkZ0Y2Yc+hPSipQl/hLsg4W/GtbA2MPkTGcvkCBHLYgLBBGpe{eol}
# -----END CERTIFICATE-----{eol}
#
# 9.11.2        CONF {certificate}=pem Special certificate input formatting option
# The special value pem (case insensitive)
# can be used to input a certificate (i.e., OTAcertificate, HOTAcertificate, RootCA) as
# a multi-line string to allow the developer to cut and paste directly the content of a standard .pem file.
# Example: AT+CONF HOTAcertificate=pem{eol}
# -----BEGIN CERTIFICATE-----{eol}
# MIIDWTCCAkGgAwIBAgIUeKvfYpklvnnattQF09ug9UULjZwwDQYJKoZIhvcNAQEL{eol}
# BQAwTTFLMEkGA1UECwxCQW1hem9uIFdlYiBTZXJ2aWNlcyBPPUFtYXpvbi5jb20g{eol}
# ...
# KHiN1yooauYJKaKr5eJilRAhdYsV2t9X3EFD60/eKmZyD+NE68jAwK/OvokhIGms{eol}
# cZAj8m0QwqvPkZ0Y2Yc+hPSipQl/hLsg4W/GtbA2MPkTGcvkCBHLYgLBBGpe{eol}
# -----END CERTIFICATE-----{eol}
def _SetCertificatePem(key: _CertificateKey,
                       certificate: str,
                       pem: str = 'pem') -> str:
    return cmd(f'AT+CONF {key}={pem}\r\n{certificate}\r\n')


# 9.11.2.1 Return: OK{eol}
def test_9_11_2_1_OtaCertificateSetPem() -> None:
    certificate = open(cf.get('ota_certificate_path', str), 'rt').read()
    # Host certificate cleared on boot. Succeeds without error
    assert _SetCertificatePem('HOTAcertificate', certificate) == 'OK\r\n'
    # For all certs, check that reflexive assignment succeeds
    keys: list[_CertificateKey] = ['HOTAcertificate', 'RootCA']
    # 9.
    pemCases: list[str] = ['pem', 'PEM']
    for key in keys:
        for pem in pemCases:
            assert _SetCertificatePem(key,
                                      _GetCertificatePem(key, pem=pem),
                                      pem=pem) == 'OK\r\n'


# Note how these command extensions are meant for the developer to use manually to facilitate the
# input/output of certificates from a terminal application without worrying about escaping the many
# newline characters contained in a typical .pem file. When a host processor is reading or writing to the
# same certificates, the developer can easily implement the necessary escaping programmatically,
# resulting in single line (long) strings.

# 9.12          Server Root Certificate Update
# All ExpressLink modules are pre-provisioned with a long-lived AWS server root certificate that is used to
# validate the endpoint (server) during the TLS connection setup. A new certificate can be provided via
# the AT command interface or via the OTA mechanism using the code indicated in Table 5 (Server Root
# certificate update).
#
# 9.12.1.1      Server root certificates updates performed via the OTA mechanism do not require the host
# to accept the update nor to control its execution timing.
#
# 9.12.1.2      Server Root certificates are NOT deleted upon a Factory Reset
#
# 9.13          Over the Wire Module (OTW) Firmware Update Command
# A direct module firmware update mechanism is offered as a convenient alternative for customers that
# intend to update module firmware during or immediately after the assembly/testing line.
# The OTW command allows the host to act as the conduit for a new firmware image to the module
# through the same interface used for the AT commands. Alternatively, customer Automated Testing
# Equipment can seize control of the interface and take over the communication with the module (i.e.,
# holding the host processor in RESET).
# This section is untested because the OTW protocol is implementation-defined...
#
# 9.13.1        OTW Enter Firmware Update mode
# Upon receiving this command, the module will enter a custom bootloader interface that will allow the
# transfer of a complete image to the reserved bulk storage memory.
#
# 9.13.1.1      Return: OK {eol} The module is in OTW mode and ready to receive the
# new firmware image
#
# 9.13.1.2      The actual protocol used to negotiate the transfer of the file is implementation dependent
# (i.e., XMODEM) and must be documented by each vendor in the module datasheet.
#
# 9.13.1.3      The OTW process can be terminated at any point by issuing a hardware reset (pulling the
# RST pin low).
# When the transfer is completed, the same firmware integrity, version compatibility and signature
# verification process described for the module OTA will be applied.
# If successful:
#
# 9.13.1.4      Return: OK Successful image download.
# The module will now reboot from the new image in bulk storage.
#
# 9.13.1.5 The process will erase all volatile configuration parameters (i.e., Topics, PATHs) and re-
# initialize some of the non-volatile as per a Reset command (actual details can be
# implementation and firmware version dependent).
#
# 9.13.1.6      Upon successful completion of the boot process, the event queue is emptied and a new
# STARTUP event is generated.
# Alternatively, should the integrity checks and signature verification fail, the update process is aborted
# freeing up any OTA memory used and the following error codes will be reported:
#
# 9.13.1.7      Return: ERR21 INVALID OTA UPDATE The module is unable to apply the new module
# images (version incompatibility or integrity check failure)
#
# 9.13.1.8      Return: ERR23 INVALID SIGNATURE The new image signature check failed
