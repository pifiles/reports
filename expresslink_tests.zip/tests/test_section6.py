# Copyright of Amazon Web Services, Inc. (AWS) 2023
#
# This code is licensed under the AWS Intellectual Property License, which can
# be found here: https://aws.amazon.com/legal/aws-ip-license-terms/; provided
# that AWS grants you a limited, royalty-free, revocable, non-exclusive,
# non-sublicensable, non-transferrable license to modify the code for internal
# testing purposes. Your receipt of this code is subject to any non-disclosure
# (or similar) agreement between you and AWS.

from typing import Literal
from commands import cmd, comms, poll
import config_handler as cf
import re
import pytest

# test_section6.py
# Section 6 - Configuration Dictionary
# The configuration dictionary is a key-value store containing all the options
# necessary for the proper functioning of ExpressLink modules. All keys are
# case sensitive.

# 6.1       Data values referenced


# 6.1.1.1   A parameter name (key) can be from 1 to 16 characters in length
#
# 6.1.1.2   Return: ERR9 INVALID KEY LENGTH
# If a parameter name (key) exceeds 16 characters.
def test_6_1_1_2_InvalidKeyLength() -> None:
    long_key = 'a' * 17
    assert cmd(
        f"AT+CONF {long_key}=testvalue\r\n") == "ERR9 INVALID KEY LENGTH\r\n"
    assert cmd(f"AT+CONF? {long_key}\r\n") == "ERR9 INVALID KEY LENGTH\r\n"


# 6.1.1.3	Valid Key Characters are 0-9, A-Z, a-z
# A parameter name (key) may only contain alphanumeric characters.
#
# 6.1.1.4   Return: ERR10 INVALID KEY NAME
# If a non-alphanumeric character is used in a parameter (key) name.
def test_6_1_1_4_InvalidKeyName() -> None:
    misnamed_key = "bad%key"
    assert cmd(f"AT+CONF {misnamed_key}=testvalue\r\n"
               ) == "ERR10 INVALID KEY NAME\r\n"
    assert cmd(f"AT+CONF? {misnamed_key}\r\n") == "ERR10 INVALID KEY NAME\r\n"


# 6.1.1.5	Return: ERR11 UNKNOWN KEY
# If the parameter name (key) is not found in Table 2 or Table 3
def test_6_1_1_5_UnknownKey() -> None:
    unknown_key = "unknownkey"
    assert cmd(
        f"AT+CONF {unknown_key}=testvalue\r\n") == "ERR11 UNKNOWN KEY\r\n"
    assert cmd(f"AT+CONF? {unknown_key}\r\n") == "ERR11 UNKNOWN KEY\r\n"


# 6.1.1.6	Return: ERR4 PARAMETER ERROR
# If the parameter (value) length exceeds the buffer size as defined in
# Table 2 or Table 3
# Test: In table2 and table3 tests


# 6.2       Data access through CONF command
#
# 6.2.1     CONF KEY={value}
# Assignment
# Assign a value to a configuration parameter present in the configuration
# dictionary. (Also see 9.11.1)
#
# 6.2.1.1   Return: OK{EOL}
# On successful write
def test_6_2_1_ConfWrite() -> None:
    assert cmd("AT+CONF Topic1=testwrite\r\n") == "OK\r\n"


# 6.2.1.2   Return: ERR9 INVALID KEY LENGTH
# If the key is too long
# Test: 6.1.1.2

# 6.2.1.3   Return: ERR10 INVALID KEY NAME
# If the key uses the incorrect characters
# Test: 6.1.1.4

# 6.2.1.4   Return: ERR11 UNKNOWN KEY
# If the key is not present in the dictionary
# Test: 6.1.1.5


# 6.2.1.5   Return: ERR12 KEY READONLY
# If the key cannot be written to
# Some keys are read-only and cannot be written to. (i.e., ThingName,
# Certificate, About)
def test_6_2_1_5_KeyReadOnly() -> None:
    assert cmd("AT+CONF ThingName=testvalue\r\n") == "ERR12 KEY READONLY\r\n"


# 6.2.1.6	Return: ERR23 INVALID SIGNATURE
# When updating a certificate (i.e., Certificate, OTAcertificate,
# HOTAcertificate) if a required signature verification failed
# (see 9.11 for more detail on the signature verification rules
# that apply to different types of certificates)
#
# See 9.6 for tests involving certificate keys
#
# 6.2.2	    CONF? {key}
# Read the value of a configuration parameter
#
# 6.2.2.1	Return: OK {value}
# on successful read
def test_6_2_2_1_ConfRead() -> None:
    re_hasresponse = r'^OK .+\r\n$'
    assert re.match(re_hasresponse, cmd("AT+CONF? ThingName\r\n"))


# 6.2.2.2   Return: ERR9 INVALID KEY LENGTH
# if the key is too long
# Test: 6.1.1.2

# 6.2.2.3   Return: ERR10 INVALID KEY NAME
# if the key uses the incorrect characters
# Test: 6.1.1.4

# 6.2.2.4   Return: ERR11 UNKNOWN KEY
# if the key is not present in the system
# Test: 6.1.1.5

# 6.2.2.5   Return: ERR13 KEY WRITEONLY
# if the key cannot be read
# Some keys are write-only and cannot be read.
# Test: Only tested in wifi modules using Passphrase

# Table 2 - Configuration Dictionary Persistent Keys
# Configuration key-value pairs listed in Table 2 are meant to be long lived
# (persist) throughout the application life and are therefore stored in
# non-volatile memory. Note that these key-value pairs have factory preset
# value, can be read only or write only.

_ReadOnlyKeys = Literal['About', 'Version', 'Certificate', 'TechSpec',
                        'ThingName', 'APN']


def _CheckNonVolatileKeyIsReadonly(key: _ReadOnlyKeys,
                                   initial_value: str) -> None:
    """Checks that a persistent, readonly key is readonly.
       Attempts to restore the key on failure"""
    try:
        assert cmd(f"AT+CONF {key}=testwrite\r\n"
                   ) == "ERR12 KEY READONLY\r\n", 'Key must be readonly'
        assert cmd(f"AT+CONF? {key}\r\n"
                   ) == initial_value, 'Readonly key was modified'
    finally:
        if cmd(f'AT+CONF? {key}\r\n') != initial_value:
            # if the key can be overwritten, then we can set it back to the initial value
            cmd(f'AT+CONF {key}={initial_value[3:-2]}\r\n')


# About
# Type: R
# Initial Value: Vendor - Model
# Factory Reset: N
# Buff Size: 64
# Concatenation of Vendor name and Model name (also see 12.1.5.3)
def test_6_table2_ConfAbout() -> None:
    re_key = r'^OK .+ - .+\r\n$'
    initial_value = cmd("AT+CONF? About\r\n")

    assert re.match(re_key, initial_value)
    assert len(initial_value[3:-2]) <= 64

    _CheckNonVolatileKeyIsReadonly('About', initial_value)

    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? About\r\n") == initial_value

    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? About\r\n") == initial_value


# Version
# Type: R
# Initial Value: X.Y.Z [Suffix]
# Suffix (optional) is alphanumeric
# Factory Reset: N
# Buff Size: 32
# The specific module FW version (also see 12.1.5.3)
# TODO: This will be relaxed in spec to any non-empty string
def test_6_table2_ConfVersion() -> None:
    re_key = r'^OK [^ ].*\r\n$'
    initial_value = cmd("AT+CONF? Version\r\n")

    assert re.match(re_key, initial_value)
    assert len(initial_value[3:-2]) <= 32

    _CheckNonVolatileKeyIsReadonly('Version', initial_value)

    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? Version\r\n") == initial_value

    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? Version\r\n") == initial_value


# TechSpec
# Type: R
# Initial Value: TechSpec version
# Factory Reset: N
# Buff Size: 16
# The technical specification version this module implements (i.e., “v0.6”, “v1.0”)
def test_6_table2_ConfTechSpec() -> None:
    expected_techspec = f"OK {pytest.expresslink_info['test_techspec']}\r\n"  # type: ignore
    initial_value = cmd("AT+CONF? TechSpec\r\n")

    assert initial_value == expected_techspec
    assert len(initial_value[3:-2]) <= 16

    _CheckNonVolatileKeyIsReadonly('TechSpec', initial_value)

    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? TechSpec\r\n") == initial_value

    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? TechSpec\r\n") == initial_value


# ThingName
# Type: R
# Initial Value: UID
# Factory Reset: N
# Buff Size: 64
# The UID provided by the HW root of trust and present in the device
# certificate. (also see 12.1.3.1)
def test_6_table2_ConfThingName() -> None:
    re_key = r'^OK .+\r\n$'
    initial_value = cmd("AT+CONF? ThingName\r\n")

    assert re.match(re_key, initial_value)
    assert len(initial_value[3:-2]) <= 64
    assert len(initial_value[3:-2]) >= 16

    _CheckNonVolatileKeyIsReadonly('ThingName', initial_value)

    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? ThingName\r\n") == initial_value

    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? ThingName\r\n") == initial_value


# Certificate
# Type: R
# Initial Value: Device birth certificate
# Factory Reset: N
# Buff Size: >=4KB
# Device certificate used to authenticate with AWS cloud, signed by the
# manufacturer CA (also see 12.1.3).
def test_6_table2_ConfCertificate() -> None:
    re_key = r'^OK -----BEGIN CERTIFICATE-----\\A.+\\A-----END CERTIFICATE-----\\A\r\n$'
    initial_value = cmd("AT+CONF? Certificate\r\n")

    assert re.match(re_key, initial_value)

    _CheckNonVolatileKeyIsReadonly('Certificate', initial_value)

    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? Certificate\r\n") == initial_value

    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? Certificate\r\n") == initial_value


# CustomName
# Type: R/W
# Initial Value: {Empty}
# Factory Reset: Y
# Buff Size: >=128
# Custom Product Name, can be set by the host
def test_6_table2_ConfCustomName() -> None:
    re_key = r'^OK \r\n$'
    initial_value = cmd("AT+CONF? CustomName\r\n")

    assert re.match(re_key, initial_value)
    test_value = 'a' * 128

    assert cmd(f"AT+CONF CustomName={test_value}\r\n") == "OK\r\n"
    assert cmd("AT+CONF? CustomName\r\n")[3:-2] == test_value

    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? CustomName\r\n")[3:-2] == test_value

    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? CustomName\r\n") == initial_value


# Endpoint
# Type: R/W
# Initial Value: Staging Account Endpoint
# Factory Reset: Y
# Buff Size: >=128
# The endpoint of the AWS account the ExpressLink module will connect to.
def test_6_table2_ConfEndpoint() -> None:
    re_key = r'^OK .+\r\n$'
    initial_value = cmd("AT+CONF? Endpoint\r\n")

    assert re.match(re_key, initial_value)
    test_value = 'a' * 128

    assert cmd(f"AT+CONF Endpoint={test_value}\r\n") == "OK\r\n"
    assert cmd("AT+CONF? Endpoint\r\n")[3:-2] == test_value

    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? Endpoint\r\n")[3:-2] == test_value

    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? Endpoint\r\n") == initial_value


# RootCA
# Type: R/W
# Initial Value: AWS Root CA
# Factory Reset: N
# Buff Size: >=4KB
# The server root certificate that will be used to authenticate the cloud Endpoint.
def test_6_table2_ConfRootCA() -> None:
    re_key = r'^OK -----BEGIN CERTIFICATE-----\\A.+\\A-----END CERTIFICATE-----\\A\r\n$'
    initial_value = cmd("AT+CONF? RootCA\r\n")

    assert re.match(re_key, initial_value)
    test_value = 'a' * 4000

    try:
        assert cmd(f"AT+CONF RootCA={test_value}\r\n") == "OK\r\n"
        assert cmd("AT+CONF? RootCA\r\n")[3:-2] == test_value

        assert cmd("AT+RESET\r\n") == "OK\r\n"
        poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
        assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
        assert cmd("AT+CONF? RootCA\r\n")[3:-2] == test_value

        assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
        poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
        assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
        assert cmd("AT+CONF? RootCA\r\n")[3:-2] == test_value
    finally:
        assert cmd(f"AT+CONF RootCA={initial_value[3:-2]}\r\n") == "OK\r\n"

    assert cmd("AT+CONF? RootCA\r\n") == initial_value


# ShadowToken
# Type: R/W
# Initial Value: ExpressLink
# Factory Reset: Y
# Buff Size: 64
# The default client-token that will be used to mark Device Shadow updates
def test_6_table2_ConfShadowToken() -> None:
    expected_shadowtoken = "OK ExpressLink\r\n"
    initial_value = cmd("AT+CONF? ShadowToken\r\n")

    assert initial_value == expected_shadowtoken
    test_value = 'a' * 64

    assert cmd(f"AT+CONF ShadowToken={test_value}\r\n") == "OK\r\n"
    assert cmd(f"AT+CONF ShadowToken={test_value + 'a'}\r\n"
               ) == "ERR4 PARAMETER ERROR\r\n"
    assert cmd("AT+CONF? ShadowToken\r\n")[3:-2] == test_value

    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? ShadowToken\r\n")[3:-2] == test_value

    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? ShadowToken\r\n") == initial_value


# DefenderPeriod
# Type: R/W
# Initial Value: 0
# Factory Reset: Y
# Buff Size: >=8
# The Device Defender upload period in seconds. (0 indicates the service is disabled)
def test_6_table2_ConfDefenderPeriod() -> None:
    expected_defenderperiod = "OK 0\r\n"
    initial_value = cmd("AT+CONF? DefenderPeriod\r\n")

    assert initial_value == expected_defenderperiod
    test_value = '1' * 8

    assert cmd(f"AT+CONF DefenderPeriod={test_value}\r\n") == "OK\r\n"
    assert cmd("AT+CONF? DefenderPeriod\r\n")[3:-2] == test_value

    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? DefenderPeriod\r\n")[3:-2] == test_value

    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? DefenderPeriod\r\n") == initial_value


# HOTAcertificate
# Type: R/W
# Initial Value: {empty}
# Factory Reset: Y
# Buff Size: >=4KB
# Host OTA certificate (see chapter 9.10)
def test_6_table2_ConfHOTAcertificate() -> None:
    re_key = r'^OK \r\n$'
    initial_value = cmd("AT+CONF? HOTAcertificate\r\n")

    assert re.match(re_key, initial_value)
    test_value = 'a' * 4000

    assert cmd(f"AT+CONF HOTAcertificate={test_value}\r\n") == "OK\r\n"
    assert cmd("AT+CONF? HOTAcertificate\r\n")[3:-2] == test_value

    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? HOTAcertificate\r\n")[3:-2] == test_value

    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? HOTAcertificate\r\n") == initial_value


# OTAcertificate
# Type: W
# Initial Value: Vendor OTA Certificate
# Factory Reset: N
# Buff Size: >=4KB
# Module OTA certificate. Vendor and Model specific. (see chapter 9.5) (Wi-Fi modules only)
@pytest.mark.skipif(cf.test_config['feature_custom_ota'].get(bool),
                    reason='custom OTA testing enabled')
def test_6_table2_ConfOTAcertificate() -> None:
    # We cannot test writing a cert to this key, as new certs must be signed by the previous cert
    assert cmd("AT+CONF OTAcertificate=\r\n") != 'ERR11 UNKNOWN KEY\r\n'
    assert cmd("AT+CONF? OTAcertificate\r\n") == 'ERR13 KEY WRITEONLY\r\n'


# SSID
# Type: R/W
# Initial Value: {Empty}
# Factory Reset: Y
# Buff Size: 32
# SSID of local router (Wi-Fi modules only)
@pytest.mark.skipif(not cf.get('feature_wifi', bool),
                    reason='wifi testing disabled')
@pytest.mark.prod
def test_6_table2_ConfSSID() -> None:
    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"

    re_key = r'^OK \r\n$'
    initial_value = cmd("AT+CONF? SSID\r\n")

    assert re.match(re_key, initial_value)
    test_value = 'a' * 32

    assert cmd(f"AT+CONF SSID={test_value}\r\n") == "OK\r\n"
    assert cmd(
        f"AT+CONF SSID={test_value + 'a'}\r\n") == "ERR4 PARAMETER ERROR\r\n"
    assert cmd("AT+CONF? SSID\r\n")[3:-2] == test_value

    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? SSID\r\n")[3:-2] == test_value

    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? SSID\r\n") == "OK \r\n"


@pytest.mark.skipif(cf.get('feature_wifi', bool),
                    reason='wifi testing enabled')
def test_6_table2_NoConfSSID() -> None:
    assert cmd("AT+CONF? SSID\r\n") == "ERR11 UNKNOWN KEY\r\n"
    assert cmd("AT+CONF SSID=testwrite\r\n") == "ERR11 UNKNOWN KEY\r\n"


# Passphrase
# Type: W
# Initial Value: {Empty}
# Factory Reset: Y
# Buff Size: 64
# Passphrase of local router (Wi-Fi modules only)
@pytest.mark.skipif(not cf.get('feature_wifi', bool),
                    reason='wifi testing disabled')
def test_6_table2_ConfPassphrase() -> None:
    test_value = 'a' * 64
    assert cmd(f"AT+CONF Passphrase={test_value}\r\n") == "OK\r\n"
    assert cmd(f"AT+CONF Passphrase={test_value + 'a'}\r\n"
               ) == "ERR4 PARAMETER ERROR\r\n"
    assert cmd("AT+CONF? Passphrase\r\n") == "ERR13 KEY WRITEONLY\r\n"


@pytest.mark.skipif(cf.get('feature_wifi', bool),
                    reason='wifi testing enabled')
def test_6_table2_NoConfPassphrase() -> None:
    assert cmd("AT+CONF? Passphrase\r\n") == "ERR11 UNKNOWN KEY\r\n"
    assert cmd("AT+CONF Passphrase=testwrite\r\n") == "ERR11 UNKNOWN KEY\r\n"


# APN
# Type: R/W
# Initial Value: Vendor - Model
# Factory Reset: N
# Buff Size: 128
# Access Point Name (Cellular modules only)
@pytest.mark.skipif(not cf.get('feature_cellular', bool),
                    reason='cellular testing disabled')
def test_6_table2_ConfAPN() -> None:
    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"

    re_key = r'^OK .*\r\n$'
    initial_value = cmd("AT+CONF? APN\r\n")

    assert re.match(re_key, initial_value)
    assert len(initial_value[3:-2]) <= 128

    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? APN\r\n") == initial_value

    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? APN\r\n") == initial_value
    try:
        assert cmd(f'AT+CONF APN=testwrite\r\n') == 'OK\r\n'
        assert cmd('AT+CONF? APN\r\n') == 'OK testwrite\r\n'
    finally:
        # restore key
        cmd(f'AT+CONF APN={initial_value[3:-2]}\r\n')


@pytest.mark.skipif(cf.get('feature_cellular', bool),
                    reason='cellular testing enabled')
def test_6_table2_NoConfAPN() -> None:
    assert cmd("AT+CONF? APN\r\n") == "ERR11 UNKNOWN KEY\r\n"
    assert cmd("AT+CONF APN=testwrite\r\n") == "ERR11 UNKNOWN KEY\r\n"


# Table 3 - Configuration Dictionary Non-persistent Keys
# Additional configuration parameters in Table 3 are non-persistent. They are
# re-initialized at power up, and following any reset event. The host
# processor might have to re-configure them following a reset and possibly
# a deep sleep awakening (implementation dependent).


# QoS
# Type: R/W
# Initial Value: 0
# Buff Size: 1
# QoS level selected for SEND commands
def test_6_table3_ConfQoS() -> None:
    re_key = r'^OK 0\r\n$'
    initial_value = cmd("AT+CONF? QoS\r\n")

    assert re.match(re_key, initial_value)
    test_value = '1'

    assert cmd(f"AT+CONF QoS={test_value}\r\n") == "OK\r\n"
    assert cmd("AT+CONF? QoS\r\n")[3:-2] == test_value

    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? QoS\r\n") == initial_value

    assert cmd(f"AT+CONF QoS={test_value}\r\n") == "OK\r\n"

    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? QoS\r\n") == initial_value


# Topic1
# Type: R/W
# Initial Value: {Empty}
# Buff Size: 128
# Custom defined topic 1
def test_6_table3_ConfTopic1() -> None:
    re_key = r'^OK \r\n$'
    initial_value = cmd("AT+CONF? Topic1\r\n")

    assert re.match(re_key, initial_value)
    test_value = 'a' * 128

    assert cmd(f"AT+CONF Topic1={test_value}\r\n") == "OK\r\n"
    assert cmd("AT+CONF? Topic1\r\n")[3:-2] == test_value

    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? Topic1\r\n") == initial_value

    assert cmd(f"AT+CONF Topic1={test_value}\r\n") == "OK\r\n"

    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? Topic1\r\n") == initial_value


# Topic2
# Type: R/W
# Initial Value: {Empty}
# Buff Size: 128
# Custom defined topic 2
def test_6_table3_ConfTopic2() -> None:
    re_key = r'^OK \r\n$'
    initial_value = cmd("AT+CONF? Topic2\r\n")

    assert re.match(re_key, initial_value)
    test_value = 'a' * 128

    assert cmd(f"AT+CONF Topic2={test_value}\r\n") == "OK\r\n"
    assert cmd("AT+CONF? Topic2\r\n")[3:-2] == test_value

    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? Topic2\r\n") == initial_value

    assert cmd(f"AT+CONF Topic2={test_value}\r\n") == "OK\r\n"

    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? Topic2\r\n") == initial_value


# EnableShadow
# Type: R/W
# Initial Value: 0
# Buff Size: 1
# 0 – disabled or 1 - enabled
def test_6_table3_ConfEnableShadow() -> None:
    re_key = r'^OK 0\r\n$'
    initial_value = cmd("AT+CONF? EnableShadow\r\n")

    assert re.match(re_key, initial_value)
    test_value = '1'

    assert cmd(f"AT+CONF EnableShadow={test_value}\r\n") == "OK\r\n"
    assert cmd("AT+CONF? EnableShadow\r\n")[3:-2] == test_value

    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? EnableShadow\r\n") == initial_value

    assert cmd(f"AT+CONF EnableShadow={test_value}\r\n") == "OK\r\n"

    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? EnableShadow\r\n") == initial_value


# Shadow1
# Type: R/W
# Initial Value: {Empty}
# Buff Size: 64
# Custom defined named shadow
def test_6_table3_ConfShadow1() -> None:
    re_key = r'^OK \r\n$'
    initial_value = cmd("AT+CONF? Shadow1\r\n")

    assert re.match(re_key, initial_value)
    test_value = 'a' * 64

    assert cmd(f"AT+CONF Shadow1={test_value}\r\n") == "OK\r\n"
    assert cmd("AT+CONF? Shadow1\r\n")[3:-2] == test_value

    assert cmd("AT+RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? Shadow1\r\n") == initial_value

    assert cmd(f"AT+CONF Shadow1={test_value}\r\n") == "OK\r\n"

    assert cmd("AT+FACTORY_RESET\r\n") == "OK\r\n"
    poll(lambda: comms.get_event_pin(), step=0.1, timeout=120)
    assert cmd("AT+EVENT?\n", False) == "OK 2 0 STARTUP\r\n"
    assert cmd("AT+CONF? Shadow1\r\n") == initial_value
