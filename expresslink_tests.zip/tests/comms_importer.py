import config_handler as cf
from sys import path

_platform = cf.test_config['platform'].get(str)
if not isinstance(_platform, str):
    raise KeyError('platform not specified in YAML config')
_platform_dir: str = f"tests/device_pal/{_platform}"
if _platform_dir not in path:
    path.insert(0, _platform_dir)
import comms
