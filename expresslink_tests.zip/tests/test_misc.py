# Copyright of Amazon Web Services, Inc. (AWS) 2023
#
# This code is licensed under the AWS Intellectual Property License, which can
# be found here: https://aws.amazon.com/legal/aws-ip-license-terms/; provided
# that AWS grants you a limited, royalty-free, revocable, non-exclusive,
# non-sublicensable, non-transferrable license to modify the code for internal
# testing purposes. Your receipt of this code is subject to any non-disclosure
# (or similar) agreement between you and AWS.

import pytest
import config_handler as cf
import paho.mqtt.client as mqtt
import re
from commands import cmd, connect_with_retries, get_next_event

# test_misc.py
# Tests for properties about the ExpressLink device not listed in the spec


@pytest.mark.prod
def test_misc_removed_democonf() -> None:
    """Ensure that the DEMOCONF diag command has been removed"""
    assert cmd("AT+CONF Endpoint=default\r\n") == "OK\r\n"
    cmd("AT+DIAG DEMOCONF Endpoint=DEMOCONF\r\n")
    assert cmd("AT+CONF? Endpoint\r\n") == "OK default\r\n"


@pytest.mark.prod
def test_misc_removed_example_staging_endpoint() -> None:
    """Ensure that the example staging endpoints are not still configured"""
    assert cmd("AT+CONF? Endpoint\r\n"
               ) != "OK example-remove.expresslink.iot.us-west-2.on.aws\r\n"
    assert cmd("AT+CONF? Endpoint\r\n"
               ) != "OK abf5598rk566j-ats.iot.us-west-2.amazonaws.com\r\n"


@pytest.mark.prod
def test_misc_changed_about() -> None:
    """Ensure that the about string has been configured"""
    about_str = cmd("AT+CONF? About\r\n")
    assert not re.match(r'.*AWS IoT ExpressLink.*', about_str)
    assert not re.match(r'.*Reference.*', about_str)


@pytest.mark.prod
def test_misc_changed_version() -> None:
    """Platforms must have implemented a versioning strategy"""
    assert cmd("AT+CONF? Version\r\n") != "OK 0.0.0\r\n"


def test_misc_unassigned_topic_event(get_topic_prefix: str,
                                     mqtt_client: mqtt.Client) -> None:
    """Messages received on an unassigned topic create a message event.
       The unassigned topic has an index of 0"""
    assert cmd(f'AT+CONF Topic1={get_topic_prefix}\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SUBSCRIBE1\r\n') == 'OK\r\n'
    event = get_next_event(r'^OK.*SUBN?ACK.*\r\n$')
    assert event
    if 'SUBNACK' in event:
        pytest.fail('Failed to subscribe to topic')
    assert cmd('AT+CONF Topic1=\r\n') == 'OK\r\n'
    mqtt_client.publish(topic=get_topic_prefix, payload='Hello World!')
    assert get_next_event(r'^OK \d+ \d+ MSG\r\n$') == 'OK 1 0 MSG\r\n'
