# Copyright of Amazon Web Services, Inc. (AWS) 2023
#
# This code is licensed under the AWS Intellectual Property License, which can
# be found here: https://aws.amazon.com/legal/aws-ip-license-terms/; provided
# that AWS grants you a limited, royalty-free, revocable, non-exclusive,
# non-sublicensable, non-transferrable license to modify the code for internal
# testing purposes. Your receipt of this code is subject to any non-disclosure
# (or similar) agreement between you and AWS.

from multiprocessing import shared_memory
import subprocess
from time import sleep
import os
import config_handler as cf

PIN_EVENT = 0
PIN_WAKE = 1
PIN_RESET = 2


def initialize_device():
    """Perform any required initialization for a device."""
    linuxsim_config_folder = cf.get('linuxsim_config_folder', str)
    linuxsim_binary_path = cf.get('linuxsim_binary_path', str)
    global process
    process = subprocess.Popen(linuxsim_binary_path,
                               cwd=linuxsim_config_folder,
                               stdin=subprocess.PIPE,
                               stdout=subprocess.PIPE,
                               stderr=subprocess.DEVNULL)
    os.set_blocking(process.stdout.fileno(), False)
    sleep(1)
    global shm
    shm = shared_memory.SharedMemory(name="linuxsim", create=False)


def cleanup():
    """Perform any required cleanup and teardown on program termination"""
    process.kill()
    shm.close()
    shm.unlink()


def write_device(input: str):
    """Send the string data in input to the device, encoded in iso_8859_1."""
    process.stdin.write(input.encode('iso_8859_1', 'replace'))
    process.stdin.flush()


def read_device() -> str:
    """Read the data that is currently available in the buffer."""
    received = process.stdout.readline()
    return received.decode('iso_8859_1')


def flush_comms():
    process.stdin.flush()
    process.stdout.flush()


def get_event_pin() -> bool:
    """Return the current voltage state of the Event Pin.

    Return 1 if the pin is high voltage/1/on/powered.
    Return 0 if the pin is low voltage/0/off/unpowered.
    """
    return shm.buf[PIN_EVENT] == 1


def set_wake_pin():
    """Set the Wake Pin to high voltage/1/on/powered."""
    shm.buf[PIN_WAKE] = 0


def clear_wake_pin():
    """Set the Wake Pin to low/0/off/unpowered."""
    shm.buf[PIN_WAKE] = 1


def set_reset_pin():
    """Set the Reset Pin to high voltage/1/on/powered."""
    shm.buf[PIN_RESET] = 0


def clear_reset_pin():
    """Set the Reset Pin to low voltage/0/off/unpowered."""
    shm.buf[PIN_RESET] = 1
