# Copyright of Amazon Web Services, Inc. (AWS) 2023
#
# This code is licensed under the AWS Intellectual Property License, which can
# be found here: https://aws.amazon.com/legal/aws-ip-license-terms/; provided
# that AWS grants you a limited, royalty-free, revocable, non-exclusive,
# non-sublicensable, non-transferrable license to modify the code for internal
# testing purposes. Your receipt of this code is subject to any non-disclosure
# (or similar) agreement between you and AWS.
#
from datetime import datetime
import time
from dateutil import tz  # type: ignore
from typing import Any, List, Optional
import pytest
from commands import cmd, comms, connect_with_retries, get_next_event, get_next_event_match
from polling import poll, TimeoutException
import config_handler as cf
import re
import pytest
import paho.mqtt.client as mqtt
from mypy_boto3_iot_data import IoTDataPlaneClient
from mypy_boto3_iot import IoTClient
import json

from tests.mqtt_client import publish, subscribe, wait_for_message


class IoTShadowDocument:
    """Creates and manages the lifetime of a Shadow document on IoT Core."""
    shadow: str
    iot_client: IoTDataPlaneClient | mqtt.Client
    createDocument: bool

    def __init__(self,
                 shadow: str,
                 iot_client: IoTDataPlaneClient | mqtt.Client,
                 createDocument: bool = True) -> None:
        self.shadow = shadow
        self.iot_client = iot_client
        self.createDocument = createDocument

    def __enter__(self) -> None:
        if self.createDocument:
            update: str = json.dumps({'state': {}})
            self.iot_client.publish(topic=f'{self.shadow}/update',
                                    payload=update)

    def __exit__(self, exc_type, exc_value, exc_tb) -> None:
        self.iot_client.publish(topic=f'{self.shadow}/delete', payload=b'')


# 10        AWS IoT Services
#
# 10.1      AWS IoT Device Defender (featured required/tested as of v1.1)
# Link: (https://aws.amazon.com/iot-device-defender/)
# ExpressLink devices support the AWS IoT Device Defender service,
# providing basic set of ExpressLink metrics published to IoT Core at a configurable interval, including:
#
# Table 6 - ExpressLink Defender metrics
# ExpressLink Custom Metric             | Type  | Description
# --------------------------------------+-------+------------
# Bytes Out                             | Count | Number of bytes sent since last update
# Messages Sent                         | Count | Number of messages sent since last update
# Messages Received                     | Count | Number of messages received since last update
# Hard Reset Event                      | Flag  | Set to 1 if a hardware reset occurred since last update
# Reconnect Events                      | Flag  | Set to 1 if a reconnect occurred since last update
# Flash Memory Writes                   | Count | Number of writes to flash memory since last update
# <Module-Name Prefix> Custom Metric(s) |       | One or more manufacturer / module specific custom metrics
#
# All ExpressLink metrics are volatile in nature, as their value is reset to 0 after each periodic update (or
# set to 1 following a device reset/reboot as per the corresponding events).
# The Device Defender feature is activated by setting the DefenderPeriod configuration parameter (see
# Table 2) to a value >0 in the configuration dictionary (using the AT+CONF command).
# The DefenderPeriod configuration parameter value indicates the number of seconds between successive
# updates of the Device Defender metrics. The maximum period value is an implementation detail that
# must be documented by the module manufacturer in the device data sheet. Note that the Device
# Defender service may choose to throttle down (reject) metric updates if too frequent.
# The latest metrics collected are sent to the Device Defender service as soon as the device connects and
# at any successive interval. The internal timer continues counting even when the device is disconnected.
# The internal timer is reset when the Device Defender feature is turned off (Defender configuration
# parameter set to 0).
# The DefenderPeriod parameter is non-volatile so that an ExpressLink device will resume automatically
# sending Device Defender metrics after a reset (RESET command, power cycle or RST pin).
# Module manufacturers can offer additional Custom Metrics specific to the model. They will need to
# prefix the Metric with the distinctive Model name (see About Configuration parameter in Table 2 and
# Module name in 12.1.5.3) and document the feature in the device datasheet.
# Note: Access to the AWS IoT Device Defender service is available only when the device is in the
# onboarded state (see 12.3.2) and requires proper configuration of the customer/OEM AWS IoT account.
#
# Examples:
# AT+CONF DefenderPeriod=0      Device Defender metrics are disabled
# NOTE: this is the initialized value after a factory reset (see Table 2).
# AT+CONF DefenderPeriod=60     Device Defender metrics will be updated every minute
# AT+CONF DefenderPeriod=3600   Device Defender metrics will be updated every hour
@pytest.mark.slow
def test_10_1_DefenderCustomMetrics(iot_services_client: IoTClient):
    startTime = datetime.now(tz=tz.tzlocal())
    assert cmd('AT+CONF DefenderPeriod=30\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))

    thingName: str = pytest.expresslink_info['thing_name']  # type: ignore

    print('Sleeping 5 minutes to allow Device Defender metrics to populate')
    for _ in range(6):
        print(end='.', flush=True)
        time.sleep(30)
    print('\nPolling Device Defender for custom metrics...')

    def checkMetricValue(metricName):
        endTime = datetime.now(tz=tz.tzlocal())
        response = iot_services_client.list_metric_values(
            thingName=thingName,
            metricName=metricName,
            startTime=startTime,
            endTime=endTime)
        if len(response['metricDatumList']) == 0:
            print(f'{endTime}: No metrics yet received')
        return response['metricDatumList']

    customMetrics: list[str] = [
        'expresslinkBytesOut', 'expresslinkMessagesSent',
        'expresslinkMessagesReceived', 'expresslinkResets',
        'expresslinkReconnects', 'expresslinkFlashWrites'
    ]
    for metric in customMetrics:
        metricList = poll(checkMetricValue,
                          args=(metric, ),
                          timeout=600,
                          step=10)
        assert 'number' in metricList[0][
            'value'], 'custom metric must be configured as a number'
        print('{}: {}'.format(metric,
                              [x['value']['number'] for x in metricList]))


def test_10_1_DefenderInterval():
    assert cmd('AT+CONF DefenderPeriod=60\r\n') == 'OK\r\n'
    assert cmd('AT+CONF? DefenderPeriod\r\n') == 'OK 60\r\n'
    assert cmd('AT+CONF DefenderPeriod=3600\r\n') == 'OK\r\n'
    assert cmd('AT+CONF? DefenderPeriod\r\n') == 'OK 3600\r\n'

    assert cmd('AT+CONF DefenderPeriod=-10\r\n') == 'ERR4 PARAMETER ERROR\r\n'
    assert cmd('AT+CONF? DefenderPeriod\r\n') == 'OK 3600\r\n'
    assert cmd(
        'AT+CONF DefenderPeriod=abcdef\r\n') == 'ERR4 PARAMETER ERROR\r\n'
    assert cmd('AT+CONF? DefenderPeriod\r\n') == 'OK 3600\r\n'


def test_10_1_DefenderDisabled():
    assert cmd('AT+CONF DefenderPeriod=0\r\n') == 'OK\r\n'
    assert cmd('AT+CONF? DefenderPeriod\r\n') == 'OK 0\r\n'


# 10.2          AWS IoT Device Shadow (featured required/tested as of v1.1)
# SHADOW commands are provided to facilitate the use of the AWS IoT Device Shadow service [link].
# Their support is enabled by setting the EnableShadow configuration parameter to 1 (see Table 3).
# Shadow support is achieved by automating the handling of subscriptions to the many Device Shadow
# MQTT topics, parsing and reporting the responses provided by the service to the device in the form of
# (SHADOW) events.
# NOTE: Access to the AWS IoT Device Shadow service is allowed only when the module is in the
# onboarded state (see 12.3.2), that is when the module is connected to the customer AWS account.
# Subscriptions to Shadow topics are managed by the SHADOW INIT# command which must be invoked
# and completed, before any of the following SHADOW commands.
# As the interaction with the Device Shadow service requires often a potentially long round trip, an
# asynchronous API is implemented to avoid blocking the host. SHADOW commands generate requests to
# the Device Shadow service and return immediately, while SHADOW GET commands can be used (later)
# to poll and eventually retrieve the service responses.
#
# 10.2.1.1      Each ExpressLink manufacturer can choose to support simultaneously a max number
# (MaxShadow ≥ 1) of named shadow documents. The chosen MaxShadow value will be
# documented in the manufacturer’s module datasheet.
# The corresponding list of non-persistent parameters, Shadow1 .. Shadow{MaxShadow}, will be
# prepopulated in the Configuration Dictionary (see Table 3) and initialized to empty strings.
# The device shadow support requires a continuous connection with the AWS IoT Core Service. Such
# connection must be established before any of the SHADOW commands is issued and must be
# maintained un-interrupted until completion of any of the requests.
# Should the connection be lost at any point, the host is responsible for re-initializing the SHADOW
# interface, re-issuing any interrupted commands and eventually re-subscribe to shadows for which delta
# updates notifications are expected.
def test_10_2_1_1_MaxShadow() -> None:
    max_shadow = cf.get('device_max_shadow', int)
    if not isinstance(max_shadow, int):
        pytest.fail(
            reason='device_max_shadow is unconfigured. Must be at least 1.')
    elif max_shadow < 1:
        pytest.fail(reason='device must support at least one named shadow')
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd(f'AT+CONF Shadow{max_shadow}=myShadow\r\n')
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd(f'AT+SHADOW{max_shadow} INIT\r\n') == 'OK\r\n'


# 10.2.1.2      All SHADOW commands use a client-token defined by the non-volatile configuration
# parameter ShadowToken (factory default: “ExpressLink”) to identify and manage
# requests/responses received on the relevant Device Shadow service topics. Any
# notifications received that do not match the client-token used in the request, not
# generated by the SHADOW commands, are discarded.
#
# 10.2.1.3      If the ShadowToken configuration parameter is instead set to an empty string, ALL
# following notifications received from the Shadow service will NOT be managed by the
# module and will be added to the messaging queue for the host to handle by using the
# GET0 command (see 5.1.6).


# 10.2.2        SHADOW[#] INIT Initialize communication with the Device Shadow service
# Initialize the Device Shadow service to communication interface for the selected shadow. This involves
# the subscription to a prescribed number of topics that will be managed by SHADOW commands such as
# SHADOW DOC, SHADOW UPDATE and SHADOW DELETE. Note that subscriptions to Shadow Deltas are
# controlled separately by the SHADOW SUBSCRIBE and SHADOW UNSUBSCRIBE commands (see 10.2.8).
#
# 10.2.2.1      When the INIT process is completed successfully, a SHADOW INIT event is generated (see
# 10.2.13) and further SHADOW commands can be issued.
def test_10_2_2_1_ShadowInitEvent() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW INIT\r\n') == 'OK\r\n'
    assert get_next_event(r'^OK 20 \d+ SHADOW INIT\r\n$')


# 10.2.2.2      If no numerical parameter (#) is provided, the Unnamed Shadow interface is initialized.
def test_10_2_2_2_ShadowInitUnnamed() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW INIT\r\n') == 'OK\r\n'
    assert get_next_event(r'^OK 20 0 SHADOW INIT\r\n$')


# 10.2.2.3      Otherwise, the corresponding Shadow# entry in the Configuration Dictionary is used to
# specify one of the object’s Named Shadows.
def test_10_2_2_2_ShadowInitNamed() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+CONF Shadow1=myShadow\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW1 INIT\r\n') == 'OK\r\n'
    assert get_next_event(r'^OK 20 1 SHADOW INIT\r\n$')


# 10.2.2.4      If a Shadow# entry is modified (AT+CONF) before the corresponding SHADOW# INIT
# process is completed, the initialization is aborted and no Shadow INIT event will be
# generated.
# TODO: This test needs to avoid race conditions...


# 10.2.2.5      Returns: OK{EOL}
# The Device Shadow service initialization process has started.
def test_10_2_2_6_ShadowServiceStarts() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW INIT\r\n') == 'OK\r\n'


# 10.2.2.6      Returns: ERR7 OUT OF RANGE {EOL}
# The requested parameter (#) exceeds the maximum number of shadows supported by this
# module.
def test_10_2_2_6_ShadowNamedShadowOutOfRange() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    max_shadow = cf.get('device_max_shadow', int)
    assert cmd(
        f'AT+SHADOW{max_shadow + 1} INIT\r\n') == 'ERR7 OUT OF RANGE\r\n'


# 10.2.2.7      Returns: ERR8 PARAMETER UNDEFINED{EOL}
# The requested shadow (#) entry in the configuration dictionary is empty.
def test_10_2_2_7_ShadowNamedShadowConfigured() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW1 INIT\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 10.2.2.8      Returns: ERR6 NO CONNECTION{EOL}
# The device is currently not connected and the request cannot be performed.
def test_10_2_2_8_ShadowRequiresConnection() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW INIT\r\n') == 'ERR6 NO CONNECTION\r\n'


# 10.2.2.9      Returns: ERR24 SHADOW ERROR{EOL}
# The EnableShadow configuration parameter is set to 0 (disabled) or the device is not in the
# Onboarded state (see 12.3.2).
def test_10_2_2_9_ShadowDisabledError() -> None:
    assert cmd('AT+CONF EnableShadow=0\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW INIT\r\n') == 'ERR24 SHADOW ERROR\r\n'


# 10.2.4        SHADOW[#] DOC Request a device shadow document
# Send a request to the Device Shadow service to retrieve an entire shadow document for the device.
#
# 10.2.4.1      A SHADOW DOC event is generated when the request is accepted (or rejected).
def _validateShadowDocEvent(expectedIndex: int):
    match = get_next_event_match(r'^OK (\d+) (\d+) SHADOW DOC\r\n$')
    assert match
    eventId, index = match.groups()
    assert int(eventId) == 22 and int(index) == expectedIndex


# 10.2.4.2      If no numerical parameter (#) is provided, the Unnamed Shadow document is requested.
#
# 10.2.4.3      Otherwise, the corresponding Shadow# entry in the Configuration Dictionary is used to
# specify one of the object’s Named Shadows.
#
# 10.2.4.4      Returns: OK{EOL}
# A shadow document request was sent to the Device Shadow service.
def test_10_2_4_ShadowDocEventUnnamed() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))

    assert cmd('AT+SHADOW INIT\r\n') == 'OK\r\n'
    assert get_next_event(r'^OK.*SHADOW INIT\r\n$')
    assert cmd('AT+SHADOW DOC\r\n') == 'OK\r\n'
    _validateShadowDocEvent(expectedIndex=0)


def test_10_2_4_ShadowDocEventNamed(get_topic_prefix: str,
                                    get_shadow_prefix: str,
                                    iot_client: IoTDataPlaneClient) -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    shadow: str = get_topic_prefix.replace('.', ':')
    assert cmd(f'AT+CONF Shadow1={shadow}\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    # rejected (doc doesn't exist on endpoint)
    assert cmd('AT+SHADOW1 INIT\r\n') == 'OK\r\n'
    assert get_next_event(r'^OK.*SHADOW INIT\r\n$')
    assert cmd('AT+SHADOW1 DOC\r\n') == 'OK\r\n'
    _validateShadowDocEvent(expectedIndex=1)

    # accepted (doc created by test)
    with IoTShadowDocument(shadow=f'{get_shadow_prefix}/name/{shadow}',
                           iot_client=iot_client):
        assert cmd('AT+SHADOW1 DOC\r\n') == 'OK\r\n'
        _validateShadowDocEvent(expectedIndex=1)


# 10.2.4.5      Returns: ERR7 OUT OF RANGE {EOL}
# The requested parameter (#) exceeds the maximum number of shadows supported by this
# module.
def test_10_2_4_5_ShadowDocOutOfRange() -> None:
    max_shadow: int = cf.get('device_max_shadow', int)
    assert cmd(f'AT+SHADOW{max_shadow + 1} DOC\r\n') == 'ERR7 OUT OF RANGE\r\n'


# 10.2.4.6      Returns: ERR8 PARAMETER UNDEFINED{EOL}
# The requested shadow (#) entry in the configuration dictionary is empty.
def test_10_2_4_6_ShadowDocNamedUndefined() -> None:
    assert cmd('AT+SHADOW1 DOC\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 10.2.4.7      Returns: ERR6 NO CONNECTION{EOL}
# The device is currently not connected and the request cannot be performed.
def test_10_2_4_7_ShadowDocRequiresConnection() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW DOC\r\n') == 'ERR6 NO CONNECTION\r\n'


# 10.2.4.8      Returns: ERR24 SHADOW ERROR{EOL}
# The EnableShadow configuration parameter is set to 0 (disabled), the maximum number of
# simultaneous asynchronous requests was exceeded or the device is not in the Onboarded
# state (see 12.3.2).
def test_10_2_4_8_ShadowDocShadowEnabled() -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW DOC\r\n') == 'ERR24 SHADOW ERROR\r\n'
    # TODO: Test in onboarded state
    # TODO: Test against slow server for max async requests


# 10.2.5        SHADOW[#] GET DOC Retrieve a device shadow document
# Check if a (requested) Device Shadow document has arrived and retrieve its contents.
#
# 10.2.5.1      If no numerical parameter (#) is provided, the Unnamed Shadow document is requested.
def test_10_2_5_1_ShadowGetDocUnnamed() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+CONF Endpoint=endpoint\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW GET DOC\r\n') == 'OK\r\n'


# 10.2.5.2      Otherwise, the corresponding Shadow# entry in the Configuration Dictionary is used to
# specify one of the object’s Named Shadows.
def test_10_2_5_2_ShadowGetDocNamed(get_topic_prefix: str) -> None:
    shadow: str = get_topic_prefix[-64:].replace('.', ':')
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+CONF Endpoint=endpoint\r\n') == 'OK\r\n'
    assert cmd(f'AT+CONF Shadow1={shadow}\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW1 GET DOC\r\n') == 'OK\r\n'


# 10.2.5.3      Returns: OK{EOL}
# The shadow document requested has not arrived yet.
def test_10_2_5_3_ShadowGetDocNotArrived() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))

    assert cmd('AT+SHADOW INIT\r\n') == 'OK\r\n'
    match = get_next_event_match(r'^OK 20 (\d+) SHADOW INIT\r\n$')
    assert match and int(match.groups()[0]) == 0

    assert cmd('AT+SHADOW GET DOC\r\n') == 'OK\r\n'


# 10.2.5.4      Returns: OK 1 {document}{EOL}
# The shadow document requested has arrived.
def test_10_2_5_4_ShadowGetDocArrived(get_topic_prefix: str,
                                      get_shadow_prefix: str,
                                      iot_client: IoTDataPlaneClient) -> None:
    documentPattern = re.compile(r'^OK (0|1) (.+)\r\n$')

    def validateResponse(response: str) -> None:
        match = documentPattern.match(response)
        assert match
        success, documentStr = match.groups()
        if int(success) == 0:
            # For identifying error messages received from IoT Core Device Shadow:
            # https://docs.aws.amazon.com/iot/latest/developerguide/device-shadow-error-messages.html
            pytest.fail(
                f'Shadow document retrieval was rejected.\nDetail: {documentStr}'
            )

        try:
            json.loads(documentStr)
        except json.decoder.JSONDecodeError:
            pytest.fail('Shadow document was not valid JSON')

    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))

    # Request unnamed document
    with IoTShadowDocument(shadow=f'{get_shadow_prefix}',
                           iot_client=iot_client):
        assert cmd('AT+SHADOW INIT\r\n') == 'OK\r\n'
        match = get_next_event_match(r'^OK 20 (\d+) SHADOW INIT\r\n$')
        assert match and int(match.groups()[0]) == 0

        assert 'OK' in cmd('AT+SHADOW DOC\r\n')
        assert get_next_event(r'^OK 22 0 SHADOW DOC\r\n$')

        validateResponse(cmd('AT+SHADOW GET DOC\r\n'))

    # Request named document
    topic: str = get_topic_prefix[-64:].replace('.', ':')
    with IoTShadowDocument(shadow=f'{get_shadow_prefix}/name/{topic}',
                           iot_client=iot_client):
        assert cmd(f'AT+CONF Shadow1={topic}\r\n') == 'OK\r\n'
        assert cmd('AT+SHADOW1 INIT\r\n') == 'OK\r\n'
        match = get_next_event_match(r'^OK 20 (\d+) SHADOW INIT\r\n$')
        assert match and int(match.groups()[0]) == 1

        assert 'OK' in cmd('AT+SHADOW1 DOC\r\n')
        assert get_next_event(r'^OK 22 1 SHADOW DOC\r\n$')

        validateResponse(cmd('AT+SHADOW1 GET DOC\r\n'))


# 10.2.5.5      Returns: OK 0 {detail}{EOL}
# The shadow document request was rejected (0), additional detail is provided.
def test_10_2_5_5_ShadowGetDocRejected(get_topic_prefix: str) -> None:
    """Retrieves a shadow document which has not been created yet"""
    shadow: str = get_topic_prefix[-64:].replace('.', ':')
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd(f'AT+CONF Shadow1={shadow}\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))

    assert cmd('AT+SHADOW1 INIT\r\n') == 'OK\r\n'
    match = get_next_event_match(r'^OK 20 (\d+) SHADOW INIT\r\n$')
    assert match and int(match.groups()[0]) == 1

    assert 'OK' in cmd('AT+SHADOW1 DOC\r\n')
    assert get_next_event(r'^OK 22 1 SHADOW DOC\r\n$')
    rejectedPattern = re.compile(r'^OK (0|1) .+\r\n$')
    match = rejectedPattern.match(cmd('AT+SHADOW1 GET DOC\r\n'))
    assert match
    assert int(match.groups()[0]) == 0


# 10.2.5.6      Returns: ERR7 OUT OF RANGE {EOL}
# The requested parameter (#) exceeds the maximum number of shadows supported by this
# module.
def test_10_2_5_6_ShadowGetDocOutOfRange() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+CONF Endpoint=endpoint\r\n') == 'OK\r\n'
    outOfRange: int = cf.get('device_max_shadow', int) + 1
    assert cmd(f'AT+SHADOW{outOfRange} GET DOC\r\n') == 'ERR7 OUT OF RANGE\r\n'


# 10.2.5.7      Returns: ERR8 PARAMETER UNDEFINED{EOL}
# The requested shadow (#) entry in the configuration dictionary is empty.
def test_10_2_5_7_ShadowGetDocNamedUndefined() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+CONF Endpoint=endpoint\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW1 GET DOC\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 10.2.5.8      Returns: ERR24 SHADOW ERROR{EOL}
# The EnableShadow configuration parameter is set to 0 (disabled) or the device is not in the
# Onboarded state (see 12.3.2).
def test_10_2_5_8_ShadowGetDocNamedShadowDisabled() -> None:
    # Shadow enabled, but on staging
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW GET DOC\r\n') == 'ERR24 SHADOW ERROR\r\n'
    # Onboarded, but shadow disabled
    assert cmd('AT+CONF Endpoint=endpoint\r\n') == 'OK\r\n'
    assert cmd('AT+CONF EnableShadow=0\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW GET DOC\r\n') == 'ERR24 SHADOW ERROR\r\n'


# Example:
# AT+SHADOW DOC{EOL} Request the entire (unnamed) device shadow document.
# OK{EOL} Request submitted.
# AT+SHADOW GET DOC{EOL} Attempt to retrieve the entire device shadow document.
# OK{EOL} No document has arrived yet.
# (later):
# OK 1 {"state": { "lamp": { "switch": "ON" } }, "version": 11, "timestamp": 1234 }{EOL}
# The Device Shadow service response has arrived!
# Or:
# OK 0 {...} {EOL} The Device Shadow document request was rejected!


# 10.2.6        SHADOW[#] UPDATE {new state} Request a device shadow document update
# Send a request to the Device Shadow service to update a device shadow. The {new state}, a JSON
# document, should NOT contain a “client-token” unless the ShadowToken configuration parameter (see
# Table 2) is set to empty, in which case all shadow notifications are left for the host to manage.
#
# 10.2.6.1      If no numerical parameter (#) is provided, the Unnamed Shadow document is assumed.
def test_10_2_6_1_ShadowUpdateUnnamed(mqtt_client: mqtt.Client,
                                      get_shadow_prefix: str,
                                      get_topic_prefix: str) -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW INIT\r\n') == 'OK\r\n'
    assert poll(comms.get_event_pin, timeout=120, step=0.01)
    assert cmd('AT+EVENT?\r\n') == 'OK 20 0 SHADOW INIT\r\n'
    update: str = json.dumps(
        {'state': {
            'desired': {
                'testkey': get_topic_prefix
            }
        }})
    with IoTShadowDocument(shadow=get_shadow_prefix, iot_client=mqtt_client):
        assert subscribe(mqtt_client, f'{get_shadow_prefix}/update')
        assert cmd(f'AT+SHADOW UPDATE {update}\r\n') == 'OK\r\n'
        _, payload = wait_for_message(mqtt_client, timeout=120, step=0.01)
        response: dict = json.loads(payload)
        assert response['state']['desired']['testkey'] == get_topic_prefix


# 10.2.6.2      Otherwise, the corresponding Shadow# entry in the Configuration Dictionary is used to
# specify one of the object’s Named Shadows.
def test_10_2_6_2_ShadowUpdateNamed(mqtt_client: mqtt.Client,
                                    get_shadow_prefix: str,
                                    get_topic_prefix: str) -> None:
    # The shadow service restricts named Shadows to the following pattern: [a-zA-Z0-9:_-]{1,64}
    topic: str = get_topic_prefix[-64:].replace('.', ':')
    fullShadow: str = f'{get_shadow_prefix}/name/{topic}'
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd(f'AT+CONF Shadow1={topic}\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW1 INIT\r\n') == 'OK\r\n'
    assert poll(comms.get_event_pin, timeout=120, step=0.01)
    assert cmd('AT+EVENT?\r\n') == 'OK 20 1 SHADOW INIT\r\n'
    update: str = json.dumps({'state': {'desired': {'testkey': 42}}})
    with IoTShadowDocument(shadow=fullShadow, iot_client=mqtt_client):
        assert subscribe(mqtt_client, f'{fullShadow}/update')
        assert cmd(f'AT+SHADOW1 UPDATE {update}\r\n') == 'OK\r\n'
        _, payload = wait_for_message(mqtt_client, timeout=120, step=0.01)
        response: dict = json.loads(payload)
        assert response['state']['desired']['testkey'] == 42


# 10.2.6.3      A SHADOW UPDATE event is generated when the request is accepted (or rejected).
def test_10_2_6_3_ShadowUpdateEvent(get_shadow_prefix: str,
                                    mqtt_client: mqtt.Client) -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW INIT\r\n') == 'OK\r\n'
    assert poll(comms.get_event_pin, timeout=120, step=0.01)

    shadowUpdatePattern: re.Pattern = re.compile(
        r'^OK (\d+) (\d+) SHADOW UPDATE.*\r\n$')

    # Accepted request
    goodUpdate: str = json.dumps(
        {'state': {
            'desired': {
                'lightswitch': 'off'
            }
        }})
    with IoTShadowDocument(shadow=get_shadow_prefix, iot_client=mqtt_client):
        cmd(f'AT+SHADOW UPDATE {goodUpdate}\r\n')

        match = get_next_event_match(shadowUpdatePattern)
        assert match is not None
        eventId, shadowIndex = match.groups()
        assert int(eventId) == 23
        assert int(shadowIndex) == 0

        # Rejected request
        badUpdate: str = json.dumps({'bad': {'bad': {'bad': 'bad'}}})
        cmd(f'AT+SHADOW UPDATE {badUpdate}\r\n')
        match = get_next_event_match(shadowUpdatePattern)
        assert match is not None
        eventId, shadowIndex = match.groups()
        assert int(eventId) == 23
        assert int(shadowIndex) == 0


# 10.2.6.4      Returns: OK{EOL}
# A shadow document update request was sent to the Device Shadow service.
def test_10_2_6_4_ShadowUpdateReturn(get_shadow_prefix: str,
                                     mqtt_client: mqtt.Client) -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW INIT\r\n') == 'OK\r\n'
    assert poll(comms.get_event_pin, timeout=120, step=0.01)
    goodUpdate: str = json.dumps({'state': {'desired': {'lightswitch': 'on'}}})
    print(goodUpdate)
    with IoTShadowDocument(shadow=get_shadow_prefix, iot_client=mqtt_client):
        assert subscribe(mqtt_client, f'{get_shadow_prefix}/update')
        assert cmd(f'AT+SHADOW UPDATE {goodUpdate}\r\n') == 'OK\r\n'
        # Not testing whether update actually arrives (covered by other tests)
        # But, we must try waiting for arrival before sending shadow delete request
        try:
            wait_for_message(mqtt_client, timeout=20, step=0.01)
        except TimeoutError:
            pass


def test_10_2_6_ShadowUpdateErrors() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    update: str = json.dumps({'state': {'desired': {'RPM': 325.5}}})

    # 10.2.6.8      Returns: ERR6 NO CONNECTION{EOL}
    # The device is currently not connected and the request cannot be performed.
    assert cmd(f'AT+SHADOW UPDATE {update}\r\n') == 'ERR6 NO CONNECTION\r\n'

    assert connect_with_retries(cf.get('personal_endpoint', str))

    # 10.2.6.5      Returns: ERR4 PARAMETER ERROR{EOL}
    # The {new state} parameter provided is not a valid JSON document.
    yaml: str = r'---\Astate:\A    desired:\A        lightswitch: on'
    assert cmd(f'AT+SHADOW UPDATE {yaml}\r\n') == 'ERR4 PARAMETER ERROR\r\n'

    # 10.2.6.6      Returns: ERR7 OUT OF RANGE {EOL}
    # The requested parameter (#) exceeds the maximum number of shadows supported by this
    # module.
    max_shadow = cf.get('device_max_shadow', int)
    assert cmd(f'AT+SHADOW{max_shadow + 1} UPDATE {update}\r\n'
               ) == 'ERR7 OUT OF RANGE\r\n'

    # 10.2.6.7      Returns: ERR8 PARAMETER UNDEFINED{EOL}
    # The requested shadow (#) entry in the configuration dictionary is empty.
    assert cmd(
        f'AT+SHADOW1 UPDATE {update}\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'

    # 10.2.6.10     Returns: ERR24 SHADOW ERROR{EOL}
    # If a client-token was present in the update document while ShadowToken is NOT empty
    # (SHADOW notifications are managed) or the device is not in the Onboarded state (see
    # 12.3.2).
    cmd('AT+CONF ShadowToken=myToken\r\n')
    includesClientToken: str = json.dumps({
        'clientToken': 'myToken',
        'state': {
            'desired': {
                'lightswitch': 'middle'
            }
        }
    })
    assert cmd(f'AT+SHADOW UPDATE {includesClientToken}\r\n'
               ) == 'ERR24 SHADOW ERROR\r\n'

    # 10.2.6.9      Returns: ERR24 SHADOW ERROR{EOL}
    # If Shadow support is disabled (EnableShadow configuration parameter set to 0).
    assert cmd('AT+CONF EnableShadow=0\r\n') == 'OK\r\n'
    assert cmd(f'AT+SHADOW UPDATE {update}\r\n') == 'ERR24 SHADOW ERROR\r\n'


# 10.2.7        SHADOW[#] GET UPDATE Retrieve a device shadow update response
# Check if a response to a (requested) Device Shadow update has arrived and retrieve the returned value.
#
# 10.2.7.1      If no numerical parameter (#) is provided, the Unnamed Shadow document is assumed.
#
# 10.2.7.2      Otherwise, the corresponding Shadow# entry in the Configuration Dictionary is used to
# specify one of the object’s Named Shadows.
#
# 10.2.7.3      Returns: OK{EOL}
# A shadow document update response has not arrived yet.
def test_10_2_7_ShadowGetUpdateUnnamed() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+CONF Endpoint=endpoint\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW GET UPDATE\r\n') == 'OK\r\n'


def test_10_2_7_ShadowGetUpdateNamed() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+CONF Shadow1=customShadow\r\n') == 'OK\r\n'
    assert cmd('AT+CONF Endpoint=endpoint\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW1 GET UPDATE\r\n') == 'OK\r\n'


# 10.2.7.4      Returns: OK {0/1} {document}{EOL}
# A response to the shadow document update requested has arrived. A Boolean value
# indicates if it was accepted (1) or rejected (0). An additional document containing the
# update details is appended.
def _verifyShadowUpdateResponse(fullShadow: str,
                                mqtt_client: mqtt.Client,
                                updateValue: Any = 'testval',
                                shadowIndex: Optional[int] = None) -> None:
    assert connect_with_retries(cf.get('personal_endpoint', str))
    param: str = '' if shadowIndex is None else str(shadowIndex)
    if shadowIndex is None:
        shadowIndex = 0
    assert cmd(f'AT+SHADOW{param} INIT\r\n') == 'OK\r\n'
    assert get_next_event('^OK.*SHADOW INIT\r\n$')

    def pollForShadowUpdate() -> tuple[str | Any, ...]:
        try:
            eventMatch = get_next_event_match(
                r'^OK (\d+) (\d+) SHADOW UPDATE\r\n$')
            assert eventMatch
            eventId, eventParam = (int(group) for group in eventMatch.groups())
            assert eventId == 23 and eventParam == shadowIndex
        except TimeoutError:
            pytest.fail('No SHADOW UPDATE event raised by device')

        result = cmd(f'AT+SHADOW{param} GET UPDATE\r\n')

        pattern = r'^OK (0|1) (.+)\r\n'
        match = re.match(pattern, result)
        if not match:
            pytest.fail(
                'Update pattern was not matched.\nPattern: {!r}\nUpdate: {!r}'.
                format(pattern, result))
        return match.groups()

    with IoTShadowDocument(shadow=fullShadow,
                           iot_client=mqtt_client,
                           createDocument=False):
        goodUpdate: str = json.dumps({
            'clientToken': 'ExpressLink',
            'state': {
                'desired': {
                    'testkey': updateValue
                }
            }
        })
        publish(mqtt_client, f'{fullShadow}/update', goodUpdate)
        accepted, document = pollForShadowUpdate()
        assert int(accepted) == 1
        try:
            documentJson = json.loads(document)
            assert documentJson['state']['desired']['testkey'] == updateValue
        except json.JSONDecodeError:
            pytest.fail('Failed to load JSON document')
        except KeyError:
            pytest.fail(
                'Update document did not contain test key\nDocument:\n{}'.
                format(json.dumps(documentJson, indent=2)))

        # missing required state object
        badUpdate: str = json.dumps({'clientToken': 'ExpressLink'})
        publish(mqtt_client, f'{fullShadow}/update', badUpdate)
        accepted, document = pollForShadowUpdate()
        assert int(accepted) == 0


def test_10_2_7_4_ShadowGetUpdateArrivedUnnamed(
        get_topic_prefix: str, get_shadow_prefix: str,
        mqtt_client: mqtt.Client) -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n')
    _verifyShadowUpdateResponse(get_shadow_prefix,
                                mqtt_client,
                                updateValue=get_topic_prefix)


def test_10_2_7_4_ShadowGetUpdateArrivedNamed(
        get_topic_prefix: str, get_shadow_prefix: str,
        mqtt_client: mqtt.Client) -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n')
    shadow: str = get_topic_prefix[-64:].replace('.', ':')
    fullShadow: str = f'{get_shadow_prefix}/name/{shadow}'
    assert cmd(f'AT+CONF Shadow1={shadow}\r\n') == 'OK\r\n'
    _verifyShadowUpdateResponse(fullShadow, mqtt_client, shadowIndex=1)


# 10.2.7.5      Returns: ERR7 OUT OF RANGE {EOL}
# The requested parameter (#) exceeds the maximum number of shadows supported by this
# module.
def test_10_2_7_5_ShadowGetUpdateOutOfRange() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+CONF Endpoint=endpoint\r\n') == 'OK\r\n'
    outOfRange: int = cf.get('device_max_shadow', int) + 1
    assert cmd(
        f'AT+SHADOW{outOfRange} GET UPDATE\r\n') == 'ERR7 OUT OF RANGE\r\n'


# 10.2.7.6      Returns: ERR8 PARAMETER UNDEFINED{EOL}
# The requested shadow (#) entry in the configuration dictionary is empty.
def test_10_2_7_6_ShadowGetUpdateUndefined() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+CONF Endpoint=endpoint\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW1 GET UPDATE\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 10.2.7.7      Returns: ERR24 SHADOW ERROR{EOL}
# The EnableShadow configuration parameter is set to 0 (disabled) or the device is not in the
# Onboarded state (see 12.3.2).
def test_10_2_7_7_ShadowGetUpdateDisabled() -> None:
    assert cmd('AT+CONF EnableShadow=0\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW GET UPDATE\r\n') == 'ERR24 SHADOW ERROR\r\n'
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW GET UPDATE\r\n') == 'ERR24 SHADOW ERROR\r\n'
    assert cmd('AT+CONF EnableShadow=0\r\n') == 'OK\r\n'
    assert cmd('AT+CONF Endpoint=endpoint\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW GET UPDATE\r\n') == 'ERR24 SHADOW ERROR\r\n'


# Example:
# AT+SHADOW1 UPDATE {"state":{"desired":{"switch": "off" } } }{EOL}
# OK{EOL} The request was sent.
# AT+SHADOW1 GET UPDATE{EOL} Check if the update was accepted/rejected.
# OK{EOL} No response received yet.
# Later:
# AT+SHADOW1 GET UPDATE(EOL} Check if the update was accepted/rejected.
# OK 1 {“switch”: “off”){EOL} The update was accepted.
# Or:
# OK 0 {..}{EOL} The update was rejected.


# 10.2.8        SHADOW[#] SUBSCRIBE Subscribe to a device shadow document
# Send a request to the Device Shadow service to receive Delta updates for a shadow document.
#
# 10.2.8.1      If no numerical parameter (#) is provided, the Unnamed Shadow document is requested.
#
# 10.2.8.2      Otherwise, the corresponding Shadow# entry in the Configuration Dictionary is used to
# specify one of the object’s Named Shadows.
#
# 10.2.8.3      A SHADOW SUBACK or SHADOW SUBNACK event are generated when the subscription is
# accepted/rejected. Note that if a Shadow# (configuration string) is modified before the
# subscription confirmation (or rejection) is received, the corresponding event will not be
# generated.
#
# 10.2.8.4      Returns: OK{EOL}
# A shadow subscribe request was sent to the Device Shadow service.
#
# Note: with Device Shadow,
# it isn't possible for the client to cause a SUBNACK
# So, we leave this potentially untested
def _verifySubackEvent(expectedIndex: int) -> None:
    match = get_next_event_match(r'^OK (\d+) (\d+) SHADOW (SUBN?ACK)\r\n$')
    assert match
    eventId, shadowIndex, ack = match.groups()
    assert int(shadowIndex) == expectedIndex
    if ack == 'SUBACK':
        assert int(eventId) == 26
    else:  # ack == 'SUBNACK'
        assert int(eventId) == 27


def test_10_2_8_3_ShadowSubscribeSubackUnnamed() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW SUBSCRIBE\r\n') == 'OK\r\n'
    _verifySubackEvent(expectedIndex=0)


def test_10_2_8_3_ShadowSubscribeSubackNamed(get_topic_prefix: str) -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    shadow = get_topic_prefix[-64:].replace('.', ':')
    assert cmd(f'AT+CONF Shadow1={shadow}\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW1 SUBSCRIBE\r\n') == 'OK\r\n'
    _verifySubackEvent(expectedIndex=1)


# 10.2.8.5      Returns: ERR7 OUT OF RANGE {EOL}
# The requested parameter (#) exceeds the maximum number of shadows supported by this
# module.
def test_10_2_8_5_ShadowSubscribeOutOfRange() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    maxShadow: int = cf.get('device_max_shadow', int)
    assert cmd(
        f'AT+SHADOW{maxShadow + 1} SUBSCRIBE\r\n') == 'ERR7 OUT OF RANGE\r\n'


# 10.2.8.6      Returns: ERR8 PARAMETER UNDEFINED{EOL}
# The requested shadow (#) entry in the configuration dictionary is empty.
def test_10_2_8_6_ShadowSubscribeUndefined() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd(f'AT+SHADOW1 SUBSCRIBE\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 10.2.8.7      Returns: ERR6 NO CONNECTION{EOL}
# The device is currently not connected and the request cannot be performed.
def test_10_2_8_7_ShadowSubscribeRequiresConnection() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW SUBSCRIBE\r\n') == 'ERR6 NO CONNECTION\r\n'
    assert cmd('AT+CONF Shadow1=customShadow\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW1 SUBSCRIBE\r\n') == 'ERR6 NO CONNECTION\r\n'


# 10.2.8.8      Returns: ERR24 SHADOW ERROR{EOL}
# If Shadow support is disabled (EnableShadow configuration parameter set to 0) or the
# device is not in the Onboarded state (see 12.3.2).
def test_10_2_8_8_ShadowSubscribeShadowError():
    # TODO: Test on staging
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+CONF EnableShadow=0\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW SUBSCRIBE\r\n') == 'ERR24 SHADOW ERROR\r\n'


# Example:
# AT+SHADOW2 SUBSCRIBE{EOL} Request subscription to the device Shadow2.
# OK{EOL} Request submitted.
# Later:
# AT+EVENT?{EOL} Check if the subscription was accepted.
# OK{EOL} No response has arrived yet.
# Or:
# OK 26 2{EOL} SHADOW SUBACK The subscription to Shadow2 was accepted.
# Or:
# OK 27 2{EOL} SHADOW SUBNACK The subscription to Shadow2 was rejected.


# 10.2.9        SHADOW[#] UNSUBSCRIBE Unsubscribe to a device shadow document
# Send a request to the Device Shadow service to stop receiving Delta updates for a shadow document.
# Note: No SHADOW event is generated following this request.
#
# 10.2.9.1      If no numerical parameter (#) is provided, the Unnamed Shadow document is requested.
#
# 10.2.9.2 Otherwise, the corresponding Shadow# entry in the Configuration Dictionary is used to
# specify one of the object’s Named Shadows.
#
# 10.2.9.3      Returns: OK{EOL}
# A shadow document request was sent to the Device Shadow service.
def test_10_2_9_3_ShadowUnsubscribeReturnsOK() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+CONF Shadow1=myShadow\r\n')
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW UNSUBSCRIBE\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW1 UNSUBSCRIBE\r\n') == 'OK\r\n'


# 10.2.9.4      Returns: ERR7 OUT OF RANGE {EOL}
# The requested parameter (#) exceeds the maximum number of shadows supported by this
# module.
def test_10_2_9_4_ShadowUnsubscribeOutOfRange() -> None:
    maxShadow: int = cf.get('device_max_shadow', int)
    assert cmd(
        f'AT+SHADOW{maxShadow + 1} UNSUBSCRIBE\r\n') == 'ERR7 OUT OF RANGE\r\n'


# 10.2.9.5      Returns: ERR8 PARAMETER UNDEFINED{EOL}
# The requested shadow (#) entry in the configuration dictionary is empty.
def test_10_2_9_5_ShadowUnsubscribeUndefined() -> None:
    assert cmd('AT+SHADOW1 UNSUBSCRIBE\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 10.2.9.6 Returns: ERR6 NO CONNECTION{EOL}
# The device is currently not connected and the request cannot be performed.
def test_10_2_9_6_ShadowUnsubscribeRequiresConnection() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW UNSUBSCRIBE\r\n') == 'ERR6 NO CONNECTION\r\n'
    assert cmd('AT+CONF Shadow1=shadow\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW1 UNSUBSCRIBE\r\n') == 'ERR6 NO CONNECTION\r\n'


# 10.2.9.7      Returns: ERR24 SHADOW ERROR{EOL}
# If Shadow support is disabled (EnableShadow configuration parameter set to 0) or the
# device is not in the Onboarded state (see 12.3.2).
def test_10_2_9_7_ShadowUnsubscribeShadowError() -> None:
    # TODO: test against staging endpoint
    assert cmd('AT+CONF EnableShadow=0\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW UNSUBSCRIBE\r\n') == 'ERR24 SHADOW ERROR\r\n'
    assert cmd('AT+CONF Shadow1=shadow\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW1 UNSUBSCRIBE\r\n') == 'ERR24 SHADOW ERROR\r\n'


# Example:
# AT+SHADOW3 UNSUBSCRIBE{EOL} Request subscription to the device Shadow2.
# OK{EOL} Request submitted.


@pytest.mark.slow
@pytest.mark.prod
def test_misc_NoDeltasAfterShadowUnsubscribe(get_topic_prefix: str,
                                             get_shadow_prefix: str,
                                             mqtt_client: mqtt.Client) -> None:
    """Integration test for SHADOW SUBSCRIBE, SHADOW GET DELTA, and SHADOW UNSUBSCRIBE.

    Delta events are generated only while subscribed.
    Subscriptions and unsubscriptions arrive at the broker."""

    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    shadow: str = get_topic_prefix[-64:].replace('.', ':')
    assert cmd(f'AT+CONF Shadow1={shadow}\r\n') == 'OK\r\n'
    thingName: str = pytest.expresslink_info['thing_name']
    poll(subscribe,
         args=(mqtt_client, f'$aws/events/subscriptions/+/{thingName}'),
         timeout=30,
         step=0)
    assert connect_with_retries(cf.get('personal_endpoint', str))
    # ignore autosubscribes on connect
    wait_for_message(mqtt_client, timeout=120, step=0.01)
    wait_for_message(mqtt_client, timeout=120, step=0.01)

    fullShadow: str = f'{get_shadow_prefix}/name/{shadow}'
    with IoTShadowDocument(fullShadow, mqtt_client):
        assert cmd('AT+SHADOW1 SUBSCRIBE\r\n') == 'OK\r\n'
        suback = get_next_event(r'^OK.*SHADOW SUBN?ACK\r\n$')
        assert suback and 'SUBACK' in suback
        _, message = wait_for_message(mqtt_client, timeout=120, step=0.01)
        assert message
        messageJson = json.loads(message)
        assert messageJson['eventType'] == 'subscribed'
        assert f'{fullShadow}/update/delta' in messageJson['topics']

        document: dict = {
            'clientToken': 'ExpressLink',
            'state': {
                'desired': {
                    'lightswitch': 'on'
                }
            }
        }
        publish(mqtt_client, f'{fullShadow}/update', json.dumps(document))
        assert get_next_event(r'^OK.*SHADOW DELTA\r\n')
        assert re.match(r'OK .+\r\n', cmd('AT+SHADOW1 GET DELTA\r\n'))

        assert cmd('AT+SHADOW1 UNSUBSCRIBE\r\n') == 'OK\r\n'
        _, message = wait_for_message(mqtt_client, timeout=120, step=0.01)
        assert message
        messageJson = json.loads(message)
        assert messageJson['eventType'] == 'unsubscribed'
        assert f'{fullShadow}/update/delta' in messageJson['topics']

        document['state']['desired']['lightswitch'] = 'off'
        publish(mqtt_client, f'{fullShadow}/update', json.dumps(document))
        # SHADOW DELTA event not generated
        print(
            'Ensuring a SHADOW DELTA event is not generated. Polling for 2 minutes'
        )
        assert get_next_event(
            r'^OK.*SHADOW DELTA\r\n', print_dots=False
        ) is None, 'Raised a SHADOW DELTA event after unsubscribe'


# 10.2.10       SHADOW[#] GET DELTA Retrieve a Shadow Delta message
# Query for the next pending shadow update message. This command can be used after receiving a DELTA
# event, or to poll the delta queue (the queue depth is implementation specific).
#
# 10.2.10.1     If no numerical parameter (#) is provided, the Unnamed Shadow document is requested.
#
# 10.2.10.2 Otherwise, the corresponding Shadow# entry in the Configuration Dictionary is used to
# specify one of the object’s Named Shadows.
#
# 10.2.10.3     Returns: OK{EOL} An empty string indicates no delta pending.
def test_10_2_10_3_ShadowGetDeltaNonPending():
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+CONF Endpoint=endpoint\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW GET DELTA\r\n') == 'OK\r\n'

    assert cmd('AT+CONF Shadow1=shadow\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW1 GET DELTA\r\n') == 'OK\r\n'


# 10.2.10.4     Returns: OK {delta document}{EOL} A delta update was ready to be retrieved.
def _validateDeltaDocument(response: str) -> None:
    match = re.match(r'^OK (.+)\r\n$', response)
    assert match

    try:
        json.loads(match.groups()[0])
    except json.JSONDecodeError:
        pytest.fail('Delta doc was not valid JSON')


def test_10_2_10_3_ShadowGetDeltaRetrievedUnnamed(
        get_topic_prefix: str, get_shadow_prefix: str,
        mqtt_client: mqtt.Client) -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW SUBSCRIBE\r\n') == 'OK\r\n'
    event = get_next_event('^OK.*SHADOW SUBN?ACK\r\n$')
    assert event is not None and 'SUBACK' in event

    with IoTShadowDocument(get_shadow_prefix, mqtt_client):
        delta = json.dumps(
            {'state': {
                'desired': {
                    'test_key': get_topic_prefix
                }
            }})
        assert cmd(f'AT+SHADOW UPDATE {delta}\r\n') == 'OK\r\n'
        eventMatch = get_next_event_match(r'^OK (\d+) (\d+) SHADOW DELTA\r\n$')
        assert eventMatch
        eventId, eventParam = (int(group) for group in eventMatch.groups())
        assert eventId == 24 and eventParam == 0
        _validateDeltaDocument(cmd('AT+SHADOW GET DELTA\r\n'))


def test_10_2_10_3_ShadowGetDeltaRetrievedNamed(
        get_topic_prefix: str, get_shadow_prefix: str,
        mqtt_client: mqtt.Client) -> None:
    shadow = get_topic_prefix[-64:].replace('.', ':')
    fullShadow = f'{get_shadow_prefix}/name/{shadow}'
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd(f'AT+CONF Shadow1={shadow}\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW1 SUBSCRIBE\r\n') == 'OK\r\n'
    event = get_next_event('^OK.*SHADOW SUBN?ACK\r\n$')
    assert event is not None and 'SUBACK' in event

    with IoTShadowDocument(fullShadow, mqtt_client):
        delta = json.dumps({'state': {'desired': {'test_key': 'test_val'}}})
        assert cmd(f'AT+SHADOW1 UPDATE {delta}\r\n') == 'OK\r\n'
        eventMatch = get_next_event_match(r'^OK (\d+) (\d+) SHADOW DELTA\r\n$')
        assert eventMatch
        eventId, eventParam = (int(group) for group in eventMatch.groups())
        assert eventId == 24 and eventParam == 1
        _validateDeltaDocument(cmd('AT+SHADOW1 GET DELTA\r\n'))


# 10.2.10.5     Returns: ERR7 OUT OF RANGE {EOL}
# The requested parameter (#) exceeds the maximum number of shadows supported by this
# module.
def test_10_2_10_5_ShadowGetDeltaOutOfRange() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    maxShadow: int = cf.get('device_max_shadow', int)
    assert cmd(
        f'AT+SHADOW{maxShadow + 1} GET DELTA\r\n') == 'ERR7 OUT OF RANGE\r\n'


# 10.2.10.6     Returns: ERR8 PARAMETER UNDEFINED{EOL}
# The requested shadow (#) entry in the configuration dictionary is empty.
#
# 10.2.10.7     Returns: ERR24 SHADOW ERROR{EOL}
# The EnableShadow configuration parameter is set to 0 (disabled) or the device is not in the
# Onboarded state (see 12.3.2).


# 10.2.11       SHADOW[#] DELETE Request the deletion of a Shadow document
# Request that the Device Shadow Service delete a device shadow document.
#
# 10.2.11.1     If no numerical parameter (#) is provided, the Unnamed Shadow document is requested.
#
# 10.2.11.2     Otherwise, the corresponding Shadow# entry in the Configuration Dictionary is used to
# specify one of the object’s Named Shadows.
#
# 10.2.11.3     A SHADOW DELETE event is generated when the request is accepted/rejected.
#
# 10.2.11.4     Returns: OK{EOL} The request was sent to the Device Shadow service.
def test_10_2_11_3_ShadowDeleteRequestEventUnnamed() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW INIT\r\n') == 'OK\r\n'
    assert get_next_event(r'^OK.*SHADOW INIT\r\n$')
    assert cmd('AT+SHADOW DELETE\r\n') == 'OK\r\n'
    match = get_next_event_match(r'^OK (\d+) (\d+) SHADOW DELETE\r\n')
    assert match
    eventId, shadowIndex = (int(group) for group in match.groups())
    assert eventId == 25
    assert shadowIndex == 0


def test_10_2_11_3_ShadowDeleteRequestEventNamed(
        get_topic_prefix: str) -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    shadow: str = get_topic_prefix[-64:].replace('.', ':')
    assert cmd(f'AT+CONF Shadow1={shadow}\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW1 INIT\r\n') == 'OK\r\n'
    assert get_next_event(r'^OK.*SHADOW INIT\r\n$')
    assert cmd('AT+SHADOW1 DELETE\r\n') == 'OK\r\n'
    match = get_next_event_match(r'^OK (\d+) (\d+) SHADOW DELETE\r\n')
    assert match
    eventId, shadowIndex = (int(group) for group in match.groups())
    assert eventId == 25
    assert shadowIndex == 1


# 10.2.11.5     Returns: ERR7 OUT OF RANGE {EOL}
# The requested parameter (#) exceeds the maximum number of shadows supported by this
# module.
def test_10_2_11_5_ShadowDeleteOutOfRange() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    maxShadow = cf.get('device_max_shadow', int)
    assert cmd(
        f'AT+SHADOW{maxShadow + 1} DELETE\r\n') == 'ERR7 OUT OF RANGE\r\n'


# 10.2.11.6     Returns: ERR8 PARAMETER UNDEFINED{EOL}
# The requested shadow (#) entry in the configuration dictionary is empty.
def test_10_2_11_6_ShadowDeleteUndefined() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW1 DELETE\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 10.2.11.7     Returns: ERR6 NO CONNECTION{EOL}
# The device is currently not connected and the request cannot be performed.
def test_10_2_11_7_ShadowDeleteRequiresConnection() -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW DELETE\r\n') == 'ERR6 NO CONNECTION\r\n'
    assert cmd('AT+CONF Shadow1=shadow\r\n')
    assert cmd('AT+SHADOW1 DELETE\r\n') == 'ERR6 NO CONNECTION\r\n'


# 10.2.11.8     Returns: ERR24 SHADOW ERROR{EOL}
# The EnableShadow configuration parameter is set to 0 (disabled), the maximum number of
# simultaneous asynchronous requests was exceeded or the device is not in the Onboarded
# state (see 12.3.2).
def test_10_2_11_8_ShadowDeleteShadowError() -> None:
    # TODO: test against staging

    assert cmd('AT+CONF EnableShadow=0\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW DELETE\r\n') == 'ERR24 SHADOW ERROR\r\n'

    # TODO: Test against slow server for max async requests


# 10.2.12       SHADOW[#] GET DELETE Retrieve a Shadow delete response
# Check if a Device Shadow Delete request was accepted.
#
# 10.2.12.1     If no numerical parameter (#) is provided, the Unnamed Shadow document is requested.
#
# 10.2.12.2     Otherwise, the corresponding Shadow# entry in the Configuration Dictionary is used to
# specify one of the object’s Named Shadows.
#
# 10.2.12.3     Returns: OK{EOL} The request was sent to the Device Shadow service.
def test_10_2_12_ShadowGetDeleteUnnamed():
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+CONF Endpoint=endpoint\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW GET DELETE\r\n') == 'OK\r\n'


def test_10_2_12_ShadowGetDeleteNamed():
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+CONF Endpoint=endpoint\r\n') == 'OK\r\n'
    assert cmd('AT+CONF Shadow1=shadow\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW1 GET DELETE\r\n') == 'OK\r\n'


# 10.2.12.4     Returns: OK 0/1 {payload}{EOL}
# The shadow delete request was accepted (1) or rejected (0). Additional detail may be
# present in the {payload}
def _pollDeletion(index: int = 0) -> bool:
    """Polls AT+SHADOW GET DELETE.
       returns whether a delete request was accepted"""
    match = get_next_event_match(r'^OK (\d+) (\d+) SHADOW DELETE\r\n$')
    assert match
    eventId, eventIdx = (int(x) for x in match.groups())
    assert eventId == 25 and eventIdx == index

    param: str = '' if index == 0 else str(index)
    match = re.match(r'^OK (0|1) .+\r\n$',
                     cmd(f'AT+SHADOW{param} GET DELETE\r\n'))
    assert match
    return int(match.groups()[0]) == 1


def test_10_2_12_4_ShadowGetDeleteArrivedUnnamed(
        get_shadow_prefix: str, mqtt_client: mqtt.Client) -> None:
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))

    requestPayload = json.dumps({'clientToken': 'ExpressLink'})

    assert cmd('AT+SHADOW INIT\r\n') == 'OK\r\n'
    assert get_next_event(r'^OK.*SHADOW INIT\r\n$')

    # Accepted: Create, then delete unnamed document
    publish(mqtt_client, f'{get_shadow_prefix}/update',
            json.dumps({'state': {}}))
    publish(mqtt_client, f'{get_shadow_prefix}/delete', requestPayload)
    assert _pollDeletion()

    # Rejected: Unnamed document already deleted
    publish(mqtt_client, f'{get_shadow_prefix}/delete', requestPayload)
    assert not _pollDeletion()


def test_10_2_12_4_ShadowGetDeleteArrivedNamed(
        get_topic_prefix: str, get_shadow_prefix: str,
        mqtt_client: mqtt.Client) -> None:
    shadow = get_topic_prefix[-64:].replace('.', ':')
    fullShadow = f'{get_shadow_prefix}/name/{shadow}'
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd(f'AT+CONF Shadow1={shadow}\r\n') == 'OK\r\n'
    assert connect_with_retries(cf.get('personal_endpoint', str))
    assert cmd('AT+SHADOW1 INIT\r\n') == 'OK\r\n'
    assert get_next_event(r'^OK.*SHADOW INIT\r\n$')

    requestPayload = json.dumps({'clientToken': 'ExpressLink'})

    # Accepted: Create, then delete named document
    publish(mqtt_client, f'{fullShadow}/update', json.dumps({'state': {}}))
    publish(mqtt_client, f'{fullShadow}/delete', requestPayload)
    assert _pollDeletion(index=1)

    # Rejected: Named document already deleted
    publish(mqtt_client, f'{fullShadow}/delete', requestPayload)
    assert not _pollDeletion(index=1)


# 10.2.12.5     Returns: ERR7 OUT OF RANGE {EOL}
# The requested parameter (#) exceeds the maximum number of shadows supported by this
# module.
def test_10_2_12_5_ShadowGetDeleteOutOfRange():
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+CONF Endpoint=endpoint\r\n')
    outOfRange = cf.get('device_max_shadow', int) + 1
    assert cmd(
        f'AT+SHADOW{outOfRange} GET DELETE\r\n') == 'ERR7 OUT OF RANGE\r\n'


# 10.2.12.6     Returns: ERR8 PARAMETER UNDEFINED{EOL}
# The requested shadow (#) entry in the configuration dictionary is empty.
def test_10_2_12_6_ShadowGetDeleteUndefined():
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+CONF Endpoint=endpoint\r\n')
    assert cmd(f'AT+SHADOW1 GET DELETE\r\n') == 'ERR8 PARAMETER UNDEFINED\r\n'


# 10.2.12.7     Returns: ERR24 SHADOW ERROR{EOL}
# the EnableShadow configuration parameter is set to 0 (disabled) or the device is not in the
# Onboarded state (see 12.3.2).
def test_10_2_12_7_ShadowGetDeleteDisabled():
    # Shadow enabled, but on staging
    assert cmd('AT+CONF EnableShadow=1\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW GET DELETE\r\n') == 'ERR24 SHADOW ERROR\r\n'
    # Onboarded, but shadow disabled
    assert cmd('AT+CONF Endpoint=endpoint\r\n') == 'OK\r\n'
    assert cmd('AT+CONF EnableShadow=0\r\n') == 'OK\r\n'
    assert cmd('AT+SHADOW GET DELETE\r\n') == 'ERR24 SHADOW ERROR\r\n'


# 10.2.13       SHADOW EVENTS
# When retrieving a shadow document, subscribing to it, or requesting updates, the module
# communicates with the Device Shadow service via a number of topics. Responses to all requests and
# Delta changes to subscribed shadow documents are reported to the host asynchronously by generating
# Shadow events (See Event Table 4). Each Shadow event carries the Shadow-Index parameter:
# - Shadow-Index value:
# ▪ 0 indicates the unnamed Shadow
# ▪ 1 .. MaxShadow the corresponding Shadow# entry in the Configuration table

# Example1:
# AT+EVENT?{EOL} Query events pending.
# OK 24 1{EOL} A SHADOW DELTA event was received for the Shadow1.
# AT+SHADOW1 GET DELTA{EOL} Fetch the delta message.
# OK {delta document}{EOL} Returns the delta document received.
# Example2:
# AT+SHADOW SUBSCRIBE{EOL}
# Request a subscription to DELTA updates for the unnamed Shadow
# OK{EOL} Request sent successfully.
# Later:
# AT+EVENT?{EOL}
# OK 26 0{EOL} SHADOW SUBACK The subscription request was accepted.
# Or :
# OK 27 0{EOL} SHADOW SUBNACK The subscription request was rejected.


# 10.3      AWS IoT JOBS
#
# 10.3.1    JOB {not implemented in this version}
# The JOB command is reserved for the support of the AWS IoT Jobs service.
def test_10_3_1_JobCommandReserved() -> None:
    assert cmd('AT+JOB\r\n') == 'ERR3 COMMAND NOT FOUND\r\n'
